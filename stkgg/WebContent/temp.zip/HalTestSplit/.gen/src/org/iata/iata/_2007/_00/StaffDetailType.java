
package org.iata.iata._2007._00;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * Staff detail information for a ticket.
 * 
 * <p>Java class for StaffDetailType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="StaffDetailType">
 *   &lt;complexContent>
 *     &lt;extension base="{http://www.iata.org/IATA/2007/00}UniqueID_Type">
 *       &lt;attribute name="JoinDate" type="{http://www.w3.org/2001/XMLSchema}date" />
 *       &lt;attribute name="ResEntitledInd" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *       &lt;attribute name="Status" type="{http://www.iata.org/IATA/2007/00}IATA_CodeType" />
 *       &lt;attribute name="TravelPurpose" type="{http://www.iata.org/IATA/2007/00}IATA_CodeType" />
 *       &lt;attribute name="TicketCondition" type="{http://www.iata.org/IATA/2007/00}IATA_CodeType" />
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "StaffDetailType")
public class StaffDetailType
    extends UniqueIDType
{

    @XmlAttribute(name = "JoinDate")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar joinDate;
    @XmlAttribute(name = "ResEntitledInd")
    protected Boolean resEntitledInd;
    @XmlAttribute(name = "Status")
    protected String status;
    @XmlAttribute(name = "TravelPurpose")
    protected String travelPurpose;
    @XmlAttribute(name = "TicketCondition")
    protected String ticketCondition;

    /**
     * Gets the value of the joinDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getJoinDate() {
        return joinDate;
    }

    /**
     * Sets the value of the joinDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setJoinDate(XMLGregorianCalendar value) {
        this.joinDate = value;
    }

    /**
     * Gets the value of the resEntitledInd property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isResEntitledInd() {
        return resEntitledInd;
    }

    /**
     * Sets the value of the resEntitledInd property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setResEntitledInd(Boolean value) {
        this.resEntitledInd = value;
    }

    /**
     * Gets the value of the status property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatus(String value) {
        this.status = value;
    }

    /**
     * Gets the value of the travelPurpose property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTravelPurpose() {
        return travelPurpose;
    }

    /**
     * Sets the value of the travelPurpose property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTravelPurpose(String value) {
        this.travelPurpose = value;
    }

    /**
     * Gets the value of the ticketCondition property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTicketCondition() {
        return ticketCondition;
    }

    /**
     * Sets the value of the ticketCondition property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTicketCondition(String value) {
        this.ticketCondition = value;
    }

}


package org.iata.iata._2007._00;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the org.iata.iata._2007._00 package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: org.iata.iata._2007._00
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link FlightSegmentBaseTypeIATA }
     * 
     */
    public FlightSegmentBaseTypeIATA createFlightSegmentBaseTypeIATA() {
        return new FlightSegmentBaseTypeIATA();
    }

    /**
     * Create an instance of {@link UniqueIDType }
     * 
     */
    public UniqueIDType createUniqueIDType() {
        return new UniqueIDType();
    }

    /**
     * Create an instance of {@link AddressInfoType }
     * 
     */
    public AddressInfoType createAddressInfoType() {
        return new AddressInfoType();
    }

    /**
     * Create an instance of {@link FareTransactionType.Fare }
     * 
     */
    public FareTransactionType.Fare createFareTransactionTypeFare() {
        return new FareTransactionType.Fare();
    }

    /**
     * Create an instance of {@link FareComponentType.PriceableUnit.FareComponentDetail }
     * 
     */
    public FareComponentType.PriceableUnit.FareComponentDetail createFareComponentTypePriceableUnitFareComponentDetail() {
        return new FareComponentType.PriceableUnit.FareComponentDetail();
    }

    /**
     * Create an instance of {@link VoluntaryChangesType }
     * 
     */
    public VoluntaryChangesType createVoluntaryChangesType() {
        return new VoluntaryChangesType();
    }

    /**
     * Create an instance of {@link TaxCouponType.TicketDocument.CouponNumber }
     * 
     */
    public TaxCouponType.TicketDocument.CouponNumber createTaxCouponTypeTicketDocumentCouponNumber() {
        return new TaxCouponType.TicketDocument.CouponNumber();
    }

    /**
     * Create an instance of {@link PaymentCardTypeIATA.CardIssuerName }
     * 
     */
    public PaymentCardTypeIATA.CardIssuerName createPaymentCardTypeIATACardIssuerName() {
        return new PaymentCardTypeIATA.CardIssuerName();
    }

    /**
     * Create an instance of {@link FareComponentType.PriceableUnit.FareComponentDetail.CouponSequence }
     * 
     */
    public FareComponentType.PriceableUnit.FareComponentDetail.CouponSequence createFareComponentTypePriceableUnitFareComponentDetailCouponSequence() {
        return new FareComponentType.PriceableUnit.FareComponentDetail.CouponSequence();
    }

    /**
     * Create an instance of {@link SourceType.Position }
     * 
     */
    public SourceType.Position createSourceTypePosition() {
        return new SourceType.Position();
    }

    /**
     * Create an instance of {@link SourceType.BookingChannel }
     * 
     */
    public SourceType.BookingChannel createSourceTypeBookingChannel() {
        return new SourceType.BookingChannel();
    }

    /**
     * Create an instance of {@link FlightSegmentBaseTypeIATA.DepartureAirport }
     * 
     */
    public FlightSegmentBaseTypeIATA.DepartureAirport createFlightSegmentBaseTypeIATADepartureAirport() {
        return new FlightSegmentBaseTypeIATA.DepartureAirport();
    }

    /**
     * Create an instance of {@link ErrorsType }
     * 
     */
    public ErrorsType createErrorsType() {
        return new ErrorsType();
    }

    /**
     * Create an instance of {@link FlightSegmentTypeIATA }
     * 
     */
    public FlightSegmentTypeIATA createFlightSegmentTypeIATA() {
        return new FlightSegmentTypeIATA();
    }

    /**
     * Create an instance of {@link ReissuedFlownType.FlightCouponData.IntermediateStop }
     * 
     */
    public ReissuedFlownType.FlightCouponData.IntermediateStop createReissuedFlownTypeFlightCouponDataIntermediateStop() {
        return new ReissuedFlownType.FlightCouponData.IntermediateStop();
    }

    /**
     * Create an instance of {@link CompanyNameType }
     * 
     */
    public CompanyNameType createCompanyNameType() {
        return new CompanyNameType();
    }

    /**
     * Create an instance of {@link CountryNameType }
     * 
     */
    public CountryNameType createCountryNameType() {
        return new CountryNameType();
    }

    /**
     * Create an instance of {@link PaymentFormTypeIATA.LoyaltyRedemption }
     * 
     */
    public PaymentFormTypeIATA.LoyaltyRedemption createPaymentFormTypeIATALoyaltyRedemption() {
        return new PaymentFormTypeIATA.LoyaltyRedemption();
    }

    /**
     * Create an instance of {@link VoluntaryChangesType.Penalty }
     * 
     */
    public VoluntaryChangesType.Penalty createVoluntaryChangesTypePenalty() {
        return new VoluntaryChangesType.Penalty();
    }

    /**
     * Create an instance of {@link SourceType }
     * 
     */
    public SourceType createSourceType() {
        return new SourceType();
    }

    /**
     * Create an instance of {@link FareComponentType.TotalConstructionAmount }
     * 
     */
    public FareComponentType.TotalConstructionAmount createFareComponentTypeTotalConstructionAmount() {
        return new FareComponentType.TotalConstructionAmount();
    }

    /**
     * Create an instance of {@link PaymentCardTypeIATA.Address }
     * 
     */
    public PaymentCardTypeIATA.Address createPaymentCardTypeIATAAddress() {
        return new PaymentCardTypeIATA.Address();
    }

    /**
     * Create an instance of {@link PaymentFormTypeIATA.Voucher }
     * 
     */
    public PaymentFormTypeIATA.Voucher createPaymentFormTypeIATAVoucher() {
        return new PaymentFormTypeIATA.Voucher();
    }

    /**
     * Create an instance of {@link CarrierFeeInfoType.CarrierFee.FeeAmount }
     * 
     */
    public CarrierFeeInfoType.CarrierFee.FeeAmount createCarrierFeeInfoTypeCarrierFeeFeeAmount() {
        return new CarrierFeeInfoType.CarrierFee.FeeAmount();
    }

    /**
     * Create an instance of {@link PaymentFormTypeIATA }
     * 
     */
    public PaymentFormTypeIATA createPaymentFormTypeIATA() {
        return new PaymentFormTypeIATA();
    }

    /**
     * Create an instance of {@link PaymentDetailTypeIATA }
     * 
     */
    public PaymentDetailTypeIATA createPaymentDetailTypeIATA() {
        return new PaymentDetailTypeIATA();
    }

    /**
     * Create an instance of {@link ETFareInfo }
     * 
     */
    public ETFareInfo createETFareInfo() {
        return new ETFareInfo();
    }

    /**
     * Create an instance of {@link TaxCouponType }
     * 
     */
    public TaxCouponType createTaxCouponType() {
        return new TaxCouponType();
    }

    /**
     * Create an instance of {@link FareTransactionType }
     * 
     */
    public FareTransactionType createFareTransactionType() {
        return new FareTransactionType();
    }

    /**
     * Create an instance of {@link CarrierFeeInfoType.Taxes }
     * 
     */
    public CarrierFeeInfoType.Taxes createCarrierFeeInfoTypeTaxes() {
        return new CarrierFeeInfoType.Taxes();
    }

    /**
     * Create an instance of {@link FareComponentType.PriceableUnit.FareComponentDetail.BaseAmount }
     * 
     */
    public FareComponentType.PriceableUnit.FareComponentDetail.BaseAmount createFareComponentTypePriceableUnitFareComponentDetailBaseAmount() {
        return new FareComponentType.PriceableUnit.FareComponentDetail.BaseAmount();
    }

    /**
     * Create an instance of {@link FlightSegmentBaseTypeIATA.OperatingAirline }
     * 
     */
    public FlightSegmentBaseTypeIATA.OperatingAirline createFlightSegmentBaseTypeIATAOperatingAirline() {
        return new FlightSegmentBaseTypeIATA.OperatingAirline();
    }

    /**
     * Create an instance of {@link ErrorType }
     * 
     */
    public ErrorType createErrorType() {
        return new ErrorType();
    }

    /**
     * Create an instance of {@link CarrierFeeInfoType }
     * 
     */
    public CarrierFeeInfoType createCarrierFeeInfoType() {
        return new CarrierFeeInfoType();
    }

    /**
     * Create an instance of {@link PaymentFormTypeIATA.Other }
     * 
     */
    public PaymentFormTypeIATA.Other createPaymentFormTypeIATAOther() {
        return new PaymentFormTypeIATA.Other();
    }

    /**
     * Create an instance of {@link FareComponentType }
     * 
     */
    public FareComponentType createFareComponentType() {
        return new FareComponentType();
    }

    /**
     * Create an instance of {@link PaymentCardTypeIATA }
     * 
     */
    public PaymentCardTypeIATA createPaymentCardTypeIATA() {
        return new PaymentCardTypeIATA();
    }

    /**
     * Create an instance of {@link StreetNmbrType }
     * 
     */
    public StreetNmbrType createStreetNmbrType() {
        return new StreetNmbrType();
    }

    /**
     * Create an instance of {@link PaymentDetailTypeIATA.PaymentAmount }
     * 
     */
    public PaymentDetailTypeIATA.PaymentAmount createPaymentDetailTypeIATAPaymentAmount() {
        return new PaymentDetailTypeIATA.PaymentAmount();
    }

    /**
     * Create an instance of {@link FareComponentType.PriceableUnit }
     * 
     */
    public FareComponentType.PriceableUnit createFareComponentTypePriceableUnit() {
        return new FareComponentType.PriceableUnit();
    }

    /**
     * Create an instance of {@link CouponInfoType.SoldAirlineInfo }
     * 
     */
    public CouponInfoType.SoldAirlineInfo createCouponInfoTypeSoldAirlineInfo() {
        return new CouponInfoType.SoldAirlineInfo();
    }

    /**
     * Create an instance of {@link SourceType.RequestorID }
     * 
     */
    public SourceType.RequestorID createSourceTypeRequestorID() {
        return new SourceType.RequestorID();
    }

    /**
     * Create an instance of {@link AddressType }
     * 
     */
    public AddressType createAddressType() {
        return new AddressType();
    }

    /**
     * Create an instance of {@link FareComponentType.PriceableUnit.FareComponentDetail.ConstructionPrinciple }
     * 
     */
    public FareComponentType.PriceableUnit.FareComponentDetail.ConstructionPrinciple createFareComponentTypePriceableUnitFareComponentDetailConstructionPrinciple() {
        return new FareComponentType.PriceableUnit.FareComponentDetail.ConstructionPrinciple();
    }

    /**
     * Create an instance of {@link ETFareInfo.Waiver }
     * 
     */
    public ETFareInfo.Waiver createETFareInfoWaiver() {
        return new ETFareInfo.Waiver();
    }

    /**
     * Create an instance of {@link CarrierFeeInfoType.PaymentDetail }
     * 
     */
    public CarrierFeeInfoType.PaymentDetail createCarrierFeeInfoTypePaymentDetail() {
        return new CarrierFeeInfoType.PaymentDetail();
    }

    /**
     * Create an instance of {@link PaymentFormTypeIATA.Cash }
     * 
     */
    public PaymentFormTypeIATA.Cash createPaymentFormTypeIATACash() {
        return new PaymentFormTypeIATA.Cash();
    }

    /**
     * Create an instance of {@link ReissuedFlownType.FlightCouponData }
     * 
     */
    public ReissuedFlownType.FlightCouponData createReissuedFlownTypeFlightCouponData() {
        return new ReissuedFlownType.FlightCouponData();
    }

    /**
     * Create an instance of {@link AddressType.StreetNmbr }
     * 
     */
    public AddressType.StreetNmbr createAddressTypeStreetNmbr() {
        return new AddressType.StreetNmbr();
    }

    /**
     * Create an instance of {@link TaxCouponType.TicketDocument.CouponNumber.UnticketedPointInfo }
     * 
     */
    public TaxCouponType.TicketDocument.CouponNumber.UnticketedPointInfo createTaxCouponTypeTicketDocumentCouponNumberUnticketedPointInfo() {
        return new TaxCouponType.TicketDocument.CouponNumber.UnticketedPointInfo();
    }

    /**
     * Create an instance of {@link DirectBillType.CompanyName }
     * 
     */
    public DirectBillType.CompanyName createDirectBillTypeCompanyName() {
        return new DirectBillType.CompanyName();
    }

    /**
     * Create an instance of {@link TaxCouponType.TicketDocument.CouponNumber.Tax }
     * 
     */
    public TaxCouponType.TicketDocument.CouponNumber.Tax createTaxCouponTypeTicketDocumentCouponNumberTax() {
        return new TaxCouponType.TicketDocument.CouponNumber.Tax();
    }

    /**
     * Create an instance of {@link StaffDetailType }
     * 
     */
    public StaffDetailType createStaffDetailType() {
        return new StaffDetailType();
    }

    /**
     * Create an instance of {@link FareComponentType.PriceableUnit.FareComponentDetail.TicketDesignator }
     * 
     */
    public FareComponentType.PriceableUnit.FareComponentDetail.TicketDesignator createFareComponentTypePriceableUnitFareComponentDetailTicketDesignator() {
        return new FareComponentType.PriceableUnit.FareComponentDetail.TicketDesignator();
    }

    /**
     * Create an instance of {@link FlightSegmentTypeIATA.MarketingAirline }
     * 
     */
    public FlightSegmentTypeIATA.MarketingAirline createFlightSegmentTypeIATAMarketingAirline() {
        return new FlightSegmentTypeIATA.MarketingAirline();
    }

    /**
     * Create an instance of {@link PersonNameType }
     * 
     */
    public PersonNameType createPersonNameType() {
        return new PersonNameType();
    }

    /**
     * Create an instance of {@link CouponInfoType }
     * 
     */
    public CouponInfoType createCouponInfoType() {
        return new CouponInfoType();
    }

    /**
     * Create an instance of {@link TaxCouponType.TicketDocument }
     * 
     */
    public TaxCouponType.TicketDocument createTaxCouponTypeTicketDocument() {
        return new TaxCouponType.TicketDocument();
    }

    /**
     * Create an instance of {@link ReissuedFlownType }
     * 
     */
    public ReissuedFlownType createReissuedFlownType() {
        return new ReissuedFlownType();
    }

    /**
     * Create an instance of {@link TaxCouponType.TicketDocument.CouponNumber.TaxCouponInfo }
     * 
     */
    public TaxCouponType.TicketDocument.CouponNumber.TaxCouponInfo createTaxCouponTypeTicketDocumentCouponNumberTaxCouponInfo() {
        return new TaxCouponType.TicketDocument.CouponNumber.TaxCouponInfo();
    }

    /**
     * Create an instance of {@link SuccessType }
     * 
     */
    public SuccessType createSuccessType() {
        return new SuccessType();
    }

    /**
     * Create an instance of {@link FreeTextType }
     * 
     */
    public FreeTextType createFreeTextType() {
        return new FreeTextType();
    }

    /**
     * Create an instance of {@link ETFareInfo.RuleIndicator }
     * 
     */
    public ETFareInfo.RuleIndicator createETFareInfoRuleIndicator() {
        return new ETFareInfo.RuleIndicator();
    }

    /**
     * Create an instance of {@link StateProvType }
     * 
     */
    public StateProvType createStateProvType() {
        return new StateProvType();
    }

    /**
     * Create an instance of {@link CarrierFeeInfoType.Taxes.Tax }
     * 
     */
    public CarrierFeeInfoType.Taxes.Tax createCarrierFeeInfoTypeTaxesTax() {
        return new CarrierFeeInfoType.Taxes.Tax();
    }

    /**
     * Create an instance of {@link BankAcctType }
     * 
     */
    public BankAcctType createBankAcctType() {
        return new BankAcctType();
    }

    /**
     * Create an instance of {@link OperatingAirlineTypeIATA }
     * 
     */
    public OperatingAirlineTypeIATA createOperatingAirlineTypeIATA() {
        return new OperatingAirlineTypeIATA();
    }

    /**
     * Create an instance of {@link FlightSegmentBaseTypeIATA.ArrivalAirport }
     * 
     */
    public FlightSegmentBaseTypeIATA.ArrivalAirport createFlightSegmentBaseTypeIATAArrivalAirport() {
        return new FlightSegmentBaseTypeIATA.ArrivalAirport();
    }

    /**
     * Create an instance of {@link POSType }
     * 
     */
    public POSType createPOSType() {
        return new POSType();
    }

    /**
     * Create an instance of {@link CarrierFeeInfoType.CarrierFee }
     * 
     */
    public CarrierFeeInfoType.CarrierFee createCarrierFeeInfoTypeCarrierFee() {
        return new CarrierFeeInfoType.CarrierFee();
    }

    /**
     * Create an instance of {@link PaymentCardTypeIATA.CustomerFileRef }
     * 
     */
    public PaymentCardTypeIATA.CustomerFileRef createPaymentCardTypeIATACustomerFileRef() {
        return new PaymentCardTypeIATA.CustomerFileRef();
    }

    /**
     * Create an instance of {@link DirectBillType }
     * 
     */
    public DirectBillType createDirectBillType() {
        return new DirectBillType();
    }

    /**
     * Create an instance of {@link WarningType }
     * 
     */
    public WarningType createWarningType() {
        return new WarningType();
    }

    /**
     * Create an instance of {@link EquipmentType }
     * 
     */
    public EquipmentType createEquipmentType() {
        return new EquipmentType();
    }

    /**
     * Create an instance of {@link WarningsType }
     * 
     */
    public WarningsType createWarningsType() {
        return new WarningsType();
    }

    /**
     * Create an instance of {@link PaymentFormTypeIATA.MiscChargeOrder }
     * 
     */
    public PaymentFormTypeIATA.MiscChargeOrder createPaymentFormTypeIATAMiscChargeOrder() {
        return new PaymentFormTypeIATA.MiscChargeOrder();
    }

}

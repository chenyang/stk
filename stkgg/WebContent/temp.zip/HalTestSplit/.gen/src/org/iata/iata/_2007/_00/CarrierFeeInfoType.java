
package org.iata.iata._2007._00;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * Carrier fee information.
 * 
 * <p>Java class for CarrierFeeInfoType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CarrierFeeInfoType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="PaymentDetail" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;extension base="{http://www.iata.org/IATA/2007/00}PaymentFormType_IATA">
 *                 &lt;attribute name="PaymentType" use="required" type="{http://www.iata.org/IATA/2007/00}IATA_CodeType" />
 *               &lt;/extension>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="CarrierFee" maxOccurs="9" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="FeeAmount" maxOccurs="9">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;attGroup ref="{http://www.iata.org/IATA/2007/00}OriginDestinationGroup"/>
 *                           &lt;attribute name="Type" use="required" type="{http://www.iata.org/IATA/2007/00}AlphaNumericStringLength1to3" />
 *                           &lt;attribute name="Amount" use="required" type="{http://www.iata.org/IATA/2007/00}Money" />
 *                           &lt;attribute name="ApplicationCode" use="required" type="{http://www.iata.org/IATA/2007/00}ListOfIATA_CodeType" />
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *                 &lt;attGroup ref="{http://www.iata.org/IATA/2007/00}FareComponentGroup"/>
 *                 &lt;attGroup ref="{http://www.iata.org/IATA/2007/00}CompanyID_AttributesGroup"/>
 *                 &lt;attribute name="Type" use="required" type="{http://www.iata.org/IATA/2007/00}IATA_CodeType" />
 *                 &lt;attribute name="FareClassCode" type="{http://www.iata.org/IATA/2007/00}StringLength1to8" />
 *                 &lt;attribute name="ReportingCode" type="{http://www.iata.org/IATA/2007/00}AlphaNumericStringLength1" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="Taxes" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="Tax" maxOccurs="99" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;attGroup ref="{http://www.iata.org/IATA/2007/00}FeeTaxGroup_IATA"/>
 *                           &lt;attribute name="ApplicationCode" type="{http://www.iata.org/IATA/2007/00}IATA_CodeType" />
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CarrierFeeInfoType", propOrder = {
    "paymentDetail",
    "carrierFee",
    "taxes"
})
public class CarrierFeeInfoType {

    @XmlElement(name = "PaymentDetail")
    protected CarrierFeeInfoType.PaymentDetail paymentDetail;
    @XmlElement(name = "CarrierFee")
    protected List<CarrierFeeInfoType.CarrierFee> carrierFee;
    @XmlElement(name = "Taxes")
    protected CarrierFeeInfoType.Taxes taxes;

    /**
     * Gets the value of the paymentDetail property.
     * 
     * @return
     *     possible object is
     *     {@link CarrierFeeInfoType.PaymentDetail }
     *     
     */
    public CarrierFeeInfoType.PaymentDetail getPaymentDetail() {
        return paymentDetail;
    }

    /**
     * Sets the value of the paymentDetail property.
     * 
     * @param value
     *     allowed object is
     *     {@link CarrierFeeInfoType.PaymentDetail }
     *     
     */
    public void setPaymentDetail(CarrierFeeInfoType.PaymentDetail value) {
        this.paymentDetail = value;
    }

    /**
     * Gets the value of the carrierFee property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the carrierFee property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCarrierFee().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CarrierFeeInfoType.CarrierFee }
     * 
     * 
     */
    public List<CarrierFeeInfoType.CarrierFee> getCarrierFee() {
        if (carrierFee == null) {
            carrierFee = new ArrayList<CarrierFeeInfoType.CarrierFee>();
        }
        return this.carrierFee;
    }

    /**
     * Gets the value of the taxes property.
     * 
     * @return
     *     possible object is
     *     {@link CarrierFeeInfoType.Taxes }
     *     
     */
    public CarrierFeeInfoType.Taxes getTaxes() {
        return taxes;
    }

    /**
     * Sets the value of the taxes property.
     * 
     * @param value
     *     allowed object is
     *     {@link CarrierFeeInfoType.Taxes }
     *     
     */
    public void setTaxes(CarrierFeeInfoType.Taxes value) {
        this.taxes = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="FeeAmount" maxOccurs="9">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;attGroup ref="{http://www.iata.org/IATA/2007/00}OriginDestinationGroup"/>
     *                 &lt;attribute name="Type" use="required" type="{http://www.iata.org/IATA/2007/00}AlphaNumericStringLength1to3" />
     *                 &lt;attribute name="Amount" use="required" type="{http://www.iata.org/IATA/2007/00}Money" />
     *                 &lt;attribute name="ApplicationCode" use="required" type="{http://www.iata.org/IATA/2007/00}ListOfIATA_CodeType" />
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *       &lt;/sequence>
     *       &lt;attGroup ref="{http://www.iata.org/IATA/2007/00}FareComponentGroup"/>
     *       &lt;attGroup ref="{http://www.iata.org/IATA/2007/00}CompanyID_AttributesGroup"/>
     *       &lt;attribute name="Type" use="required" type="{http://www.iata.org/IATA/2007/00}IATA_CodeType" />
     *       &lt;attribute name="FareClassCode" type="{http://www.iata.org/IATA/2007/00}StringLength1to8" />
     *       &lt;attribute name="ReportingCode" type="{http://www.iata.org/IATA/2007/00}AlphaNumericStringLength1" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "feeAmount"
    })
    public static class CarrierFee {

        @XmlElement(name = "FeeAmount", required = true)
        protected List<CarrierFeeInfoType.CarrierFee.FeeAmount> feeAmount;
        @XmlAttribute(name = "Type", required = true)
        protected String type;
        @XmlAttribute(name = "FareClassCode")
        protected String fareClassCode;
        @XmlAttribute(name = "ReportingCode")
        protected String reportingCode;
        @XmlAttribute(name = "Number")
        protected Integer number;
        @XmlAttribute(name = "TariffNumber")
        protected String tariffNumber;
        @XmlAttribute(name = "RuleNumber")
        protected String ruleNumber;
        @XmlAttribute(name = "RuleCode")
        protected String ruleCode;
        @XmlAttribute(name = "CompanyShortName")
        protected String companyShortName;
        @XmlAttribute(name = "TravelSector")
        protected String travelSector;
        @XmlAttribute(name = "Code")
        protected String code;
        @XmlAttribute(name = "CodeContext")
        protected String codeContext;

        /**
         * Gets the value of the feeAmount property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the feeAmount property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getFeeAmount().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link CarrierFeeInfoType.CarrierFee.FeeAmount }
         * 
         * 
         */
        public List<CarrierFeeInfoType.CarrierFee.FeeAmount> getFeeAmount() {
            if (feeAmount == null) {
                feeAmount = new ArrayList<CarrierFeeInfoType.CarrierFee.FeeAmount>();
            }
            return this.feeAmount;
        }

        /**
         * Gets the value of the type property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getType() {
            return type;
        }

        /**
         * Sets the value of the type property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setType(String value) {
            this.type = value;
        }

        /**
         * Gets the value of the fareClassCode property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getFareClassCode() {
            return fareClassCode;
        }

        /**
         * Sets the value of the fareClassCode property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setFareClassCode(String value) {
            this.fareClassCode = value;
        }

        /**
         * Gets the value of the reportingCode property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getReportingCode() {
            return reportingCode;
        }

        /**
         * Sets the value of the reportingCode property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setReportingCode(String value) {
            this.reportingCode = value;
        }

        /**
         * Gets the value of the number property.
         * 
         * @return
         *     possible object is
         *     {@link Integer }
         *     
         */
        public Integer getNumber() {
            return number;
        }

        /**
         * Sets the value of the number property.
         * 
         * @param value
         *     allowed object is
         *     {@link Integer }
         *     
         */
        public void setNumber(Integer value) {
            this.number = value;
        }

        /**
         * Gets the value of the tariffNumber property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getTariffNumber() {
            return tariffNumber;
        }

        /**
         * Sets the value of the tariffNumber property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setTariffNumber(String value) {
            this.tariffNumber = value;
        }

        /**
         * Gets the value of the ruleNumber property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getRuleNumber() {
            return ruleNumber;
        }

        /**
         * Sets the value of the ruleNumber property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setRuleNumber(String value) {
            this.ruleNumber = value;
        }

        /**
         * Gets the value of the ruleCode property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getRuleCode() {
            return ruleCode;
        }

        /**
         * Sets the value of the ruleCode property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setRuleCode(String value) {
            this.ruleCode = value;
        }

        /**
         * Gets the value of the companyShortName property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getCompanyShortName() {
            return companyShortName;
        }

        /**
         * Sets the value of the companyShortName property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setCompanyShortName(String value) {
            this.companyShortName = value;
        }

        /**
         * Gets the value of the travelSector property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getTravelSector() {
            return travelSector;
        }

        /**
         * Sets the value of the travelSector property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setTravelSector(String value) {
            this.travelSector = value;
        }

        /**
         * Gets the value of the code property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getCode() {
            return code;
        }

        /**
         * Sets the value of the code property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setCode(String value) {
            this.code = value;
        }

        /**
         * Gets the value of the codeContext property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getCodeContext() {
            return codeContext;
        }

        /**
         * Sets the value of the codeContext property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setCodeContext(String value) {
            this.codeContext = value;
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;attGroup ref="{http://www.iata.org/IATA/2007/00}OriginDestinationGroup"/>
         *       &lt;attribute name="Type" use="required" type="{http://www.iata.org/IATA/2007/00}AlphaNumericStringLength1to3" />
         *       &lt;attribute name="Amount" use="required" type="{http://www.iata.org/IATA/2007/00}Money" />
         *       &lt;attribute name="ApplicationCode" use="required" type="{http://www.iata.org/IATA/2007/00}ListOfIATA_CodeType" />
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "")
        public static class FeeAmount {

            @XmlAttribute(name = "Type", required = true)
            protected String type;
            @XmlAttribute(name = "Amount", required = true)
            protected BigDecimal amount;
            @XmlAttribute(name = "ApplicationCode", required = true)
            protected List<String> applicationCode;
            @XmlAttribute(name = "OriginCityCode")
            protected String originCityCode;
            @XmlAttribute(name = "DestinationCityCode")
            protected String destinationCityCode;

            /**
             * Gets the value of the type property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getType() {
                return type;
            }

            /**
             * Sets the value of the type property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setType(String value) {
                this.type = value;
            }

            /**
             * Gets the value of the amount property.
             * 
             * @return
             *     possible object is
             *     {@link BigDecimal }
             *     
             */
            public BigDecimal getAmount() {
                return amount;
            }

            /**
             * Sets the value of the amount property.
             * 
             * @param value
             *     allowed object is
             *     {@link BigDecimal }
             *     
             */
            public void setAmount(BigDecimal value) {
                this.amount = value;
            }

            /**
             * Gets the value of the applicationCode property.
             * 
             * <p>
             * This accessor method returns a reference to the live list,
             * not a snapshot. Therefore any modification you make to the
             * returned list will be present inside the JAXB object.
             * This is why there is not a <CODE>set</CODE> method for the applicationCode property.
             * 
             * <p>
             * For example, to add a new item, do as follows:
             * <pre>
             *    getApplicationCode().add(newItem);
             * </pre>
             * 
             * 
             * <p>
             * Objects of the following type(s) are allowed in the list
             * {@link String }
             * 
             * 
             */
            public List<String> getApplicationCode() {
                if (applicationCode == null) {
                    applicationCode = new ArrayList<String>();
                }
                return this.applicationCode;
            }

            /**
             * Gets the value of the originCityCode property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getOriginCityCode() {
                return originCityCode;
            }

            /**
             * Sets the value of the originCityCode property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setOriginCityCode(String value) {
                this.originCityCode = value;
            }

            /**
             * Gets the value of the destinationCityCode property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getDestinationCityCode() {
                return destinationCityCode;
            }

            /**
             * Sets the value of the destinationCityCode property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setDestinationCityCode(String value) {
                this.destinationCityCode = value;
            }

        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;extension base="{http://www.iata.org/IATA/2007/00}PaymentFormType_IATA">
     *       &lt;attribute name="PaymentType" use="required" type="{http://www.iata.org/IATA/2007/00}IATA_CodeType" />
     *     &lt;/extension>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "")
    public static class PaymentDetail
        extends PaymentFormTypeIATA
    {

        @XmlAttribute(name = "PaymentType", required = true)
        protected String paymentType;

        /**
         * Gets the value of the paymentType property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getPaymentType() {
            return paymentType;
        }

        /**
         * Sets the value of the paymentType property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setPaymentType(String value) {
            this.paymentType = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="Tax" maxOccurs="99" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;attGroup ref="{http://www.iata.org/IATA/2007/00}FeeTaxGroup_IATA"/>
     *                 &lt;attribute name="ApplicationCode" type="{http://www.iata.org/IATA/2007/00}IATA_CodeType" />
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "tax"
    })
    public static class Taxes {

        @XmlElement(name = "Tax")
        protected List<CarrierFeeInfoType.Taxes.Tax> tax;

        /**
         * Gets the value of the tax property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the tax property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getTax().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link CarrierFeeInfoType.Taxes.Tax }
         * 
         * 
         */
        public List<CarrierFeeInfoType.Taxes.Tax> getTax() {
            if (tax == null) {
                tax = new ArrayList<CarrierFeeInfoType.Taxes.Tax>();
            }
            return this.tax;
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;attGroup ref="{http://www.iata.org/IATA/2007/00}FeeTaxGroup_IATA"/>
         *       &lt;attribute name="ApplicationCode" type="{http://www.iata.org/IATA/2007/00}IATA_CodeType" />
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "")
        public static class Tax {

            @XmlAttribute(name = "ApplicationCode")
            protected String applicationCode;
            @XmlAttribute(name = "Qualifier")
            protected String qualifier;
            @XmlAttribute(name = "ISOCountry")
            protected String isoCountry;
            @XmlAttribute(name = "TaxType")
            protected String taxType;
            @XmlAttribute(name = "FiledAmount")
            protected BigDecimal filedAmount;
            @XmlAttribute(name = "FiledCurrencyCode")
            protected String filedCurrencyCode;
            @XmlAttribute(name = "FiledTaxType")
            protected String filedTaxType;
            @XmlAttribute(name = "ConversionRate")
            protected BigDecimal conversionRate;
            @XmlAttribute(name = "Usage")
            protected String usage;
            @XmlAttribute(name = "Amount")
            protected BigDecimal amount;
            @XmlAttribute(name = "CurrencyCode")
            protected String currencyCode;
            @XmlAttribute(name = "DecimalPlaces")
            @XmlSchemaType(name = "nonNegativeInteger")
            protected BigInteger decimalPlaces;

            /**
             * Gets the value of the applicationCode property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getApplicationCode() {
                return applicationCode;
            }

            /**
             * Sets the value of the applicationCode property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setApplicationCode(String value) {
                this.applicationCode = value;
            }

            /**
             * Gets the value of the qualifier property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getQualifier() {
                return qualifier;
            }

            /**
             * Sets the value of the qualifier property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setQualifier(String value) {
                this.qualifier = value;
            }

            /**
             * Gets the value of the isoCountry property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getISOCountry() {
                return isoCountry;
            }

            /**
             * Sets the value of the isoCountry property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setISOCountry(String value) {
                this.isoCountry = value;
            }

            /**
             * Gets the value of the taxType property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getTaxType() {
                return taxType;
            }

            /**
             * Sets the value of the taxType property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setTaxType(String value) {
                this.taxType = value;
            }

            /**
             * Gets the value of the filedAmount property.
             * 
             * @return
             *     possible object is
             *     {@link BigDecimal }
             *     
             */
            public BigDecimal getFiledAmount() {
                return filedAmount;
            }

            /**
             * Sets the value of the filedAmount property.
             * 
             * @param value
             *     allowed object is
             *     {@link BigDecimal }
             *     
             */
            public void setFiledAmount(BigDecimal value) {
                this.filedAmount = value;
            }

            /**
             * Gets the value of the filedCurrencyCode property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getFiledCurrencyCode() {
                return filedCurrencyCode;
            }

            /**
             * Sets the value of the filedCurrencyCode property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setFiledCurrencyCode(String value) {
                this.filedCurrencyCode = value;
            }

            /**
             * Gets the value of the filedTaxType property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getFiledTaxType() {
                return filedTaxType;
            }

            /**
             * Sets the value of the filedTaxType property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setFiledTaxType(String value) {
                this.filedTaxType = value;
            }

            /**
             * Gets the value of the conversionRate property.
             * 
             * @return
             *     possible object is
             *     {@link BigDecimal }
             *     
             */
            public BigDecimal getConversionRate() {
                return conversionRate;
            }

            /**
             * Sets the value of the conversionRate property.
             * 
             * @param value
             *     allowed object is
             *     {@link BigDecimal }
             *     
             */
            public void setConversionRate(BigDecimal value) {
                this.conversionRate = value;
            }

            /**
             * Gets the value of the usage property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getUsage() {
                return usage;
            }

            /**
             * Sets the value of the usage property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setUsage(String value) {
                this.usage = value;
            }

            /**
             * Gets the value of the amount property.
             * 
             * @return
             *     possible object is
             *     {@link BigDecimal }
             *     
             */
            public BigDecimal getAmount() {
                return amount;
            }

            /**
             * Sets the value of the amount property.
             * 
             * @param value
             *     allowed object is
             *     {@link BigDecimal }
             *     
             */
            public void setAmount(BigDecimal value) {
                this.amount = value;
            }

            /**
             * Gets the value of the currencyCode property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getCurrencyCode() {
                return currencyCode;
            }

            /**
             * Sets the value of the currencyCode property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setCurrencyCode(String value) {
                this.currencyCode = value;
            }

            /**
             * Gets the value of the decimalPlaces property.
             * 
             * @return
             *     possible object is
             *     {@link BigInteger }
             *     
             */
            public BigInteger getDecimalPlaces() {
                return decimalPlaces;
            }

            /**
             * Sets the value of the decimalPlaces property.
             * 
             * @param value
             *     allowed object is
             *     {@link BigInteger }
             *     
             */
            public void setDecimalPlaces(BigInteger value) {
                this.decimalPlaces = value;
            }

        }

    }

}

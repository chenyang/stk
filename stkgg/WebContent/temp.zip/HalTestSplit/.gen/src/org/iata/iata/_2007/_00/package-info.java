@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.iata.org/IATA/2007/00", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package org.iata.iata._2007._00;

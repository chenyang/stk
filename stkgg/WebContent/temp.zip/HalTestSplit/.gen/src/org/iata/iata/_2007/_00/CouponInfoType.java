
package org.iata.iata._2007._00;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * Information for a coupon.
 * 
 * <p>Java class for CouponInfoType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CouponInfoType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="SoldAirlineInfo" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;extension base="{http://www.iata.org/IATA/2007/00}FlightSegmentType_IATA">
 *                 &lt;attribute name="Status" type="{http://www.iata.org/IATA/2007/00}AlphaNumericStringLength1to3" />
 *                 &lt;attribute name="StopoverInd" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *                 &lt;attribute name="DepartureTerminal" type="{http://www.iata.org/IATA/2007/00}AlphaNumericStringLength1to5" />
 *                 &lt;attribute name="ArrivalTerminal" type="{http://www.iata.org/IATA/2007/00}AlphaNumericStringLength1to5" />
 *                 &lt;attribute name="SeatNumber" type="{http://www.iata.org/IATA/2007/00}AlphaNumericStringLength1to4" />
 *               &lt;/extension>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *       &lt;attGroup ref="{http://www.iata.org/IATA/2007/00}DateTimeSpanGroup"/>
 *       &lt;attribute name="Number" type="{http://www.iata.org/IATA/2007/00}Numeric1to4" />
 *       &lt;attribute name="InConnectionNbr" type="{http://www.iata.org/IATA/2007/00}Numeric1to4" />
 *       &lt;attribute name="CouponReference" type="{http://www.iata.org/IATA/2007/00}StringLength1to8" />
 *       &lt;attribute name="FareBasisCode" type="{http://www.iata.org/IATA/2007/00}StringLength1to16" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CouponInfoType", propOrder = {
    "soldAirlineInfo"
})
public class CouponInfoType {

    @XmlElement(name = "SoldAirlineInfo")
    protected CouponInfoType.SoldAirlineInfo soldAirlineInfo;
    @XmlAttribute(name = "Number")
    protected Integer number;
    @XmlAttribute(name = "InConnectionNbr")
    protected Integer inConnectionNbr;
    @XmlAttribute(name = "CouponReference")
    protected String couponReference;
    @XmlAttribute(name = "FareBasisCode")
    protected String fareBasisCode;
    @XmlAttribute(name = "Start")
    protected String start;
    @XmlAttribute(name = "Duration")
    protected String duration;
    @XmlAttribute(name = "End")
    protected String end;

    /**
     * Gets the value of the soldAirlineInfo property.
     * 
     * @return
     *     possible object is
     *     {@link CouponInfoType.SoldAirlineInfo }
     *     
     */
    public CouponInfoType.SoldAirlineInfo getSoldAirlineInfo() {
        return soldAirlineInfo;
    }

    /**
     * Sets the value of the soldAirlineInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link CouponInfoType.SoldAirlineInfo }
     *     
     */
    public void setSoldAirlineInfo(CouponInfoType.SoldAirlineInfo value) {
        this.soldAirlineInfo = value;
    }

    /**
     * Gets the value of the number property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getNumber() {
        return number;
    }

    /**
     * Sets the value of the number property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setNumber(Integer value) {
        this.number = value;
    }

    /**
     * Gets the value of the inConnectionNbr property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getInConnectionNbr() {
        return inConnectionNbr;
    }

    /**
     * Sets the value of the inConnectionNbr property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setInConnectionNbr(Integer value) {
        this.inConnectionNbr = value;
    }

    /**
     * Gets the value of the couponReference property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCouponReference() {
        return couponReference;
    }

    /**
     * Sets the value of the couponReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCouponReference(String value) {
        this.couponReference = value;
    }

    /**
     * Gets the value of the fareBasisCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFareBasisCode() {
        return fareBasisCode;
    }

    /**
     * Sets the value of the fareBasisCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFareBasisCode(String value) {
        this.fareBasisCode = value;
    }

    /**
     * Gets the value of the start property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStart() {
        return start;
    }

    /**
     * Sets the value of the start property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStart(String value) {
        this.start = value;
    }

    /**
     * Gets the value of the duration property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDuration() {
        return duration;
    }

    /**
     * Sets the value of the duration property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDuration(String value) {
        this.duration = value;
    }

    /**
     * Gets the value of the end property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEnd() {
        return end;
    }

    /**
     * Sets the value of the end property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEnd(String value) {
        this.end = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;extension base="{http://www.iata.org/IATA/2007/00}FlightSegmentType_IATA">
     *       &lt;attribute name="Status" type="{http://www.iata.org/IATA/2007/00}AlphaNumericStringLength1to3" />
     *       &lt;attribute name="StopoverInd" type="{http://www.w3.org/2001/XMLSchema}boolean" />
     *       &lt;attribute name="DepartureTerminal" type="{http://www.iata.org/IATA/2007/00}AlphaNumericStringLength1to5" />
     *       &lt;attribute name="ArrivalTerminal" type="{http://www.iata.org/IATA/2007/00}AlphaNumericStringLength1to5" />
     *       &lt;attribute name="SeatNumber" type="{http://www.iata.org/IATA/2007/00}AlphaNumericStringLength1to4" />
     *     &lt;/extension>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "")
    public static class SoldAirlineInfo
        extends FlightSegmentTypeIATA
    {

        @XmlAttribute(name = "Status")
        protected String status;
        @XmlAttribute(name = "StopoverInd")
        protected Boolean stopoverInd;
        @XmlAttribute(name = "DepartureTerminal")
        protected String departureTerminal;
        @XmlAttribute(name = "ArrivalTerminal")
        protected String arrivalTerminal;
        @XmlAttribute(name = "SeatNumber")
        protected String seatNumber;

        /**
         * Gets the value of the status property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getStatus() {
            return status;
        }

        /**
         * Sets the value of the status property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setStatus(String value) {
            this.status = value;
        }

        /**
         * Gets the value of the stopoverInd property.
         * 
         * @return
         *     possible object is
         *     {@link Boolean }
         *     
         */
        public Boolean isStopoverInd() {
            return stopoverInd;
        }

        /**
         * Sets the value of the stopoverInd property.
         * 
         * @param value
         *     allowed object is
         *     {@link Boolean }
         *     
         */
        public void setStopoverInd(Boolean value) {
            this.stopoverInd = value;
        }

        /**
         * Gets the value of the departureTerminal property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getDepartureTerminal() {
            return departureTerminal;
        }

        /**
         * Sets the value of the departureTerminal property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setDepartureTerminal(String value) {
            this.departureTerminal = value;
        }

        /**
         * Gets the value of the arrivalTerminal property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getArrivalTerminal() {
            return arrivalTerminal;
        }

        /**
         * Sets the value of the arrivalTerminal property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setArrivalTerminal(String value) {
            this.arrivalTerminal = value;
        }

        /**
         * Gets the value of the seatNumber property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getSeatNumber() {
            return seatNumber;
        }

        /**
         * Sets the value of the seatNumber property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setSeatNumber(String value) {
            this.seatNumber = value;
        }

    }

}

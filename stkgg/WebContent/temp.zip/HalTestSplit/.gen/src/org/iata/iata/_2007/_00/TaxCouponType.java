
package org.iata.iata._2007._00;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * Used to specify tax information for a coupon.
 * 
 * <p>Java class for TaxCouponType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="TaxCouponType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="TicketDocument" maxOccurs="4">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="CouponNumber" maxOccurs="4">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="TaxCouponInfo" minOccurs="0">
 *                               &lt;complexType>
 *                                 &lt;complexContent>
 *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                     &lt;attribute name="Cabin" type="{http://www.iata.org/IATA/2007/00}CabinType" />
 *                                     &lt;attribute name="AirEquipType" type="{http://www.iata.org/IATA/2007/00}StringLength3" />
 *                                   &lt;/restriction>
 *                                 &lt;/complexContent>
 *                               &lt;/complexType>
 *                             &lt;/element>
 *                             &lt;element name="Tax" maxOccurs="99" minOccurs="0">
 *                               &lt;complexType>
 *                                 &lt;complexContent>
 *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                     &lt;attGroup ref="{http://www.iata.org/IATA/2007/00}FeeTaxGroup_IATA"/>
 *                                   &lt;/restriction>
 *                                 &lt;/complexContent>
 *                               &lt;/complexType>
 *                             &lt;/element>
 *                             &lt;element name="UnticketedPointInfo" maxOccurs="5" minOccurs="0">
 *                               &lt;complexType>
 *                                 &lt;complexContent>
 *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                     &lt;attribute name="CityAirportCode" type="{http://www.iata.org/IATA/2007/00}StringLength1to8" />
 *                                     &lt;attribute name="ArrivalDate" type="{http://www.iata.org/IATA/2007/00}DateOrDateTimeType" />
 *                                     &lt;attribute name="DepartureDate" type="{http://www.iata.org/IATA/2007/00}DateOrDateTimeType" />
 *                                     &lt;attribute name="AirEquipType" type="{http://www.iata.org/IATA/2007/00}StringLength3" />
 *                                   &lt;/restriction>
 *                                 &lt;/complexContent>
 *                               &lt;/complexType>
 *                             &lt;/element>
 *                           &lt;/sequence>
 *                           &lt;attribute name="Number" use="required" type="{http://www.iata.org/IATA/2007/00}Numeric1to4" />
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *                 &lt;attribute name="TicketDocumentNbr" use="required" type="{http://www.iata.org/IATA/2007/00}StringLength1to16" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *       &lt;attribute name="BirthDate" type="{http://www.w3.org/2001/XMLSchema}date" />
 *       &lt;attribute name="JourneyTurnaroundCityCode" type="{http://www.iata.org/IATA/2007/00}StringLength1to8" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TaxCouponType", propOrder = {
    "ticketDocument"
})
public class TaxCouponType {

    @XmlElement(name = "TicketDocument", required = true)
    protected List<TaxCouponType.TicketDocument> ticketDocument;
    @XmlAttribute(name = "BirthDate")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar birthDate;
    @XmlAttribute(name = "JourneyTurnaroundCityCode")
    protected String journeyTurnaroundCityCode;

    /**
     * Gets the value of the ticketDocument property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the ticketDocument property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTicketDocument().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link TaxCouponType.TicketDocument }
     * 
     * 
     */
    public List<TaxCouponType.TicketDocument> getTicketDocument() {
        if (ticketDocument == null) {
            ticketDocument = new ArrayList<TaxCouponType.TicketDocument>();
        }
        return this.ticketDocument;
    }

    /**
     * Gets the value of the birthDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getBirthDate() {
        return birthDate;
    }

    /**
     * Sets the value of the birthDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setBirthDate(XMLGregorianCalendar value) {
        this.birthDate = value;
    }

    /**
     * Gets the value of the journeyTurnaroundCityCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJourneyTurnaroundCityCode() {
        return journeyTurnaroundCityCode;
    }

    /**
     * Sets the value of the journeyTurnaroundCityCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJourneyTurnaroundCityCode(String value) {
        this.journeyTurnaroundCityCode = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="CouponNumber" maxOccurs="4">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="TaxCouponInfo" minOccurs="0">
     *                     &lt;complexType>
     *                       &lt;complexContent>
     *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                           &lt;attribute name="Cabin" type="{http://www.iata.org/IATA/2007/00}CabinType" />
     *                           &lt;attribute name="AirEquipType" type="{http://www.iata.org/IATA/2007/00}StringLength3" />
     *                         &lt;/restriction>
     *                       &lt;/complexContent>
     *                     &lt;/complexType>
     *                   &lt;/element>
     *                   &lt;element name="Tax" maxOccurs="99" minOccurs="0">
     *                     &lt;complexType>
     *                       &lt;complexContent>
     *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                           &lt;attGroup ref="{http://www.iata.org/IATA/2007/00}FeeTaxGroup_IATA"/>
     *                         &lt;/restriction>
     *                       &lt;/complexContent>
     *                     &lt;/complexType>
     *                   &lt;/element>
     *                   &lt;element name="UnticketedPointInfo" maxOccurs="5" minOccurs="0">
     *                     &lt;complexType>
     *                       &lt;complexContent>
     *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                           &lt;attribute name="CityAirportCode" type="{http://www.iata.org/IATA/2007/00}StringLength1to8" />
     *                           &lt;attribute name="ArrivalDate" type="{http://www.iata.org/IATA/2007/00}DateOrDateTimeType" />
     *                           &lt;attribute name="DepartureDate" type="{http://www.iata.org/IATA/2007/00}DateOrDateTimeType" />
     *                           &lt;attribute name="AirEquipType" type="{http://www.iata.org/IATA/2007/00}StringLength3" />
     *                         &lt;/restriction>
     *                       &lt;/complexContent>
     *                     &lt;/complexType>
     *                   &lt;/element>
     *                 &lt;/sequence>
     *                 &lt;attribute name="Number" use="required" type="{http://www.iata.org/IATA/2007/00}Numeric1to4" />
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *       &lt;/sequence>
     *       &lt;attribute name="TicketDocumentNbr" use="required" type="{http://www.iata.org/IATA/2007/00}StringLength1to16" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "couponNumber"
    })
    public static class TicketDocument {

        @XmlElement(name = "CouponNumber", required = true)
        protected List<TaxCouponType.TicketDocument.CouponNumber> couponNumber;
        @XmlAttribute(name = "TicketDocumentNbr", required = true)
        protected String ticketDocumentNbr;

        /**
         * Gets the value of the couponNumber property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the couponNumber property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getCouponNumber().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link TaxCouponType.TicketDocument.CouponNumber }
         * 
         * 
         */
        public List<TaxCouponType.TicketDocument.CouponNumber> getCouponNumber() {
            if (couponNumber == null) {
                couponNumber = new ArrayList<TaxCouponType.TicketDocument.CouponNumber>();
            }
            return this.couponNumber;
        }

        /**
         * Gets the value of the ticketDocumentNbr property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getTicketDocumentNbr() {
            return ticketDocumentNbr;
        }

        /**
         * Sets the value of the ticketDocumentNbr property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setTicketDocumentNbr(String value) {
            this.ticketDocumentNbr = value;
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="TaxCouponInfo" minOccurs="0">
         *           &lt;complexType>
         *             &lt;complexContent>
         *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *                 &lt;attribute name="Cabin" type="{http://www.iata.org/IATA/2007/00}CabinType" />
         *                 &lt;attribute name="AirEquipType" type="{http://www.iata.org/IATA/2007/00}StringLength3" />
         *               &lt;/restriction>
         *             &lt;/complexContent>
         *           &lt;/complexType>
         *         &lt;/element>
         *         &lt;element name="Tax" maxOccurs="99" minOccurs="0">
         *           &lt;complexType>
         *             &lt;complexContent>
         *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *                 &lt;attGroup ref="{http://www.iata.org/IATA/2007/00}FeeTaxGroup_IATA"/>
         *               &lt;/restriction>
         *             &lt;/complexContent>
         *           &lt;/complexType>
         *         &lt;/element>
         *         &lt;element name="UnticketedPointInfo" maxOccurs="5" minOccurs="0">
         *           &lt;complexType>
         *             &lt;complexContent>
         *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *                 &lt;attribute name="CityAirportCode" type="{http://www.iata.org/IATA/2007/00}StringLength1to8" />
         *                 &lt;attribute name="ArrivalDate" type="{http://www.iata.org/IATA/2007/00}DateOrDateTimeType" />
         *                 &lt;attribute name="DepartureDate" type="{http://www.iata.org/IATA/2007/00}DateOrDateTimeType" />
         *                 &lt;attribute name="AirEquipType" type="{http://www.iata.org/IATA/2007/00}StringLength3" />
         *               &lt;/restriction>
         *             &lt;/complexContent>
         *           &lt;/complexType>
         *         &lt;/element>
         *       &lt;/sequence>
         *       &lt;attribute name="Number" use="required" type="{http://www.iata.org/IATA/2007/00}Numeric1to4" />
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "taxCouponInfo",
            "tax",
            "unticketedPointInfo"
        })
        public static class CouponNumber {

            @XmlElement(name = "TaxCouponInfo")
            protected TaxCouponType.TicketDocument.CouponNumber.TaxCouponInfo taxCouponInfo;
            @XmlElement(name = "Tax")
            protected List<TaxCouponType.TicketDocument.CouponNumber.Tax> tax;
            @XmlElement(name = "UnticketedPointInfo")
            protected List<TaxCouponType.TicketDocument.CouponNumber.UnticketedPointInfo> unticketedPointInfo;
            @XmlAttribute(name = "Number", required = true)
            protected int number;

            /**
             * Gets the value of the taxCouponInfo property.
             * 
             * @return
             *     possible object is
             *     {@link TaxCouponType.TicketDocument.CouponNumber.TaxCouponInfo }
             *     
             */
            public TaxCouponType.TicketDocument.CouponNumber.TaxCouponInfo getTaxCouponInfo() {
                return taxCouponInfo;
            }

            /**
             * Sets the value of the taxCouponInfo property.
             * 
             * @param value
             *     allowed object is
             *     {@link TaxCouponType.TicketDocument.CouponNumber.TaxCouponInfo }
             *     
             */
            public void setTaxCouponInfo(TaxCouponType.TicketDocument.CouponNumber.TaxCouponInfo value) {
                this.taxCouponInfo = value;
            }

            /**
             * Gets the value of the tax property.
             * 
             * <p>
             * This accessor method returns a reference to the live list,
             * not a snapshot. Therefore any modification you make to the
             * returned list will be present inside the JAXB object.
             * This is why there is not a <CODE>set</CODE> method for the tax property.
             * 
             * <p>
             * For example, to add a new item, do as follows:
             * <pre>
             *    getTax().add(newItem);
             * </pre>
             * 
             * 
             * <p>
             * Objects of the following type(s) are allowed in the list
             * {@link TaxCouponType.TicketDocument.CouponNumber.Tax }
             * 
             * 
             */
            public List<TaxCouponType.TicketDocument.CouponNumber.Tax> getTax() {
                if (tax == null) {
                    tax = new ArrayList<TaxCouponType.TicketDocument.CouponNumber.Tax>();
                }
                return this.tax;
            }

            /**
             * Gets the value of the unticketedPointInfo property.
             * 
             * <p>
             * This accessor method returns a reference to the live list,
             * not a snapshot. Therefore any modification you make to the
             * returned list will be present inside the JAXB object.
             * This is why there is not a <CODE>set</CODE> method for the unticketedPointInfo property.
             * 
             * <p>
             * For example, to add a new item, do as follows:
             * <pre>
             *    getUnticketedPointInfo().add(newItem);
             * </pre>
             * 
             * 
             * <p>
             * Objects of the following type(s) are allowed in the list
             * {@link TaxCouponType.TicketDocument.CouponNumber.UnticketedPointInfo }
             * 
             * 
             */
            public List<TaxCouponType.TicketDocument.CouponNumber.UnticketedPointInfo> getUnticketedPointInfo() {
                if (unticketedPointInfo == null) {
                    unticketedPointInfo = new ArrayList<TaxCouponType.TicketDocument.CouponNumber.UnticketedPointInfo>();
                }
                return this.unticketedPointInfo;
            }

            /**
             * Gets the value of the number property.
             * 
             */
            public int getNumber() {
                return number;
            }

            /**
             * Sets the value of the number property.
             * 
             */
            public void setNumber(int value) {
                this.number = value;
            }


            /**
             * <p>Java class for anonymous complex type.
             * 
             * <p>The following schema fragment specifies the expected content contained within this class.
             * 
             * <pre>
             * &lt;complexType>
             *   &lt;complexContent>
             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
             *       &lt;attGroup ref="{http://www.iata.org/IATA/2007/00}FeeTaxGroup_IATA"/>
             *     &lt;/restriction>
             *   &lt;/complexContent>
             * &lt;/complexType>
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "")
            public static class Tax {

                @XmlAttribute(name = "Qualifier")
                protected String qualifier;
                @XmlAttribute(name = "ISOCountry")
                protected String isoCountry;
                @XmlAttribute(name = "TaxType")
                protected String taxType;
                @XmlAttribute(name = "FiledAmount")
                protected BigDecimal filedAmount;
                @XmlAttribute(name = "FiledCurrencyCode")
                protected String filedCurrencyCode;
                @XmlAttribute(name = "FiledTaxType")
                protected String filedTaxType;
                @XmlAttribute(name = "ConversionRate")
                protected BigDecimal conversionRate;
                @XmlAttribute(name = "Usage")
                protected String usage;
                @XmlAttribute(name = "Amount")
                protected BigDecimal amount;
                @XmlAttribute(name = "CurrencyCode")
                protected String currencyCode;
                @XmlAttribute(name = "DecimalPlaces")
                @XmlSchemaType(name = "nonNegativeInteger")
                protected BigInteger decimalPlaces;

                /**
                 * Gets the value of the qualifier property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getQualifier() {
                    return qualifier;
                }

                /**
                 * Sets the value of the qualifier property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setQualifier(String value) {
                    this.qualifier = value;
                }

                /**
                 * Gets the value of the isoCountry property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getISOCountry() {
                    return isoCountry;
                }

                /**
                 * Sets the value of the isoCountry property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setISOCountry(String value) {
                    this.isoCountry = value;
                }

                /**
                 * Gets the value of the taxType property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getTaxType() {
                    return taxType;
                }

                /**
                 * Sets the value of the taxType property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setTaxType(String value) {
                    this.taxType = value;
                }

                /**
                 * Gets the value of the filedAmount property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link BigDecimal }
                 *     
                 */
                public BigDecimal getFiledAmount() {
                    return filedAmount;
                }

                /**
                 * Sets the value of the filedAmount property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link BigDecimal }
                 *     
                 */
                public void setFiledAmount(BigDecimal value) {
                    this.filedAmount = value;
                }

                /**
                 * Gets the value of the filedCurrencyCode property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getFiledCurrencyCode() {
                    return filedCurrencyCode;
                }

                /**
                 * Sets the value of the filedCurrencyCode property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setFiledCurrencyCode(String value) {
                    this.filedCurrencyCode = value;
                }

                /**
                 * Gets the value of the filedTaxType property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getFiledTaxType() {
                    return filedTaxType;
                }

                /**
                 * Sets the value of the filedTaxType property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setFiledTaxType(String value) {
                    this.filedTaxType = value;
                }

                /**
                 * Gets the value of the conversionRate property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link BigDecimal }
                 *     
                 */
                public BigDecimal getConversionRate() {
                    return conversionRate;
                }

                /**
                 * Sets the value of the conversionRate property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link BigDecimal }
                 *     
                 */
                public void setConversionRate(BigDecimal value) {
                    this.conversionRate = value;
                }

                /**
                 * Gets the value of the usage property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getUsage() {
                    return usage;
                }

                /**
                 * Sets the value of the usage property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setUsage(String value) {
                    this.usage = value;
                }

                /**
                 * Gets the value of the amount property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link BigDecimal }
                 *     
                 */
                public BigDecimal getAmount() {
                    return amount;
                }

                /**
                 * Sets the value of the amount property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link BigDecimal }
                 *     
                 */
                public void setAmount(BigDecimal value) {
                    this.amount = value;
                }

                /**
                 * Gets the value of the currencyCode property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getCurrencyCode() {
                    return currencyCode;
                }

                /**
                 * Sets the value of the currencyCode property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setCurrencyCode(String value) {
                    this.currencyCode = value;
                }

                /**
                 * Gets the value of the decimalPlaces property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link BigInteger }
                 *     
                 */
                public BigInteger getDecimalPlaces() {
                    return decimalPlaces;
                }

                /**
                 * Sets the value of the decimalPlaces property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link BigInteger }
                 *     
                 */
                public void setDecimalPlaces(BigInteger value) {
                    this.decimalPlaces = value;
                }

            }


            /**
             * <p>Java class for anonymous complex type.
             * 
             * <p>The following schema fragment specifies the expected content contained within this class.
             * 
             * <pre>
             * &lt;complexType>
             *   &lt;complexContent>
             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
             *       &lt;attribute name="Cabin" type="{http://www.iata.org/IATA/2007/00}CabinType" />
             *       &lt;attribute name="AirEquipType" type="{http://www.iata.org/IATA/2007/00}StringLength3" />
             *     &lt;/restriction>
             *   &lt;/complexContent>
             * &lt;/complexType>
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "")
            public static class TaxCouponInfo {

                @XmlAttribute(name = "Cabin")
                protected CabinType cabin;
                @XmlAttribute(name = "AirEquipType")
                protected String airEquipType;

                /**
                 * Gets the value of the cabin property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link CabinType }
                 *     
                 */
                public CabinType getCabin() {
                    return cabin;
                }

                /**
                 * Sets the value of the cabin property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link CabinType }
                 *     
                 */
                public void setCabin(CabinType value) {
                    this.cabin = value;
                }

                /**
                 * Gets the value of the airEquipType property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getAirEquipType() {
                    return airEquipType;
                }

                /**
                 * Sets the value of the airEquipType property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setAirEquipType(String value) {
                    this.airEquipType = value;
                }

            }


            /**
             * <p>Java class for anonymous complex type.
             * 
             * <p>The following schema fragment specifies the expected content contained within this class.
             * 
             * <pre>
             * &lt;complexType>
             *   &lt;complexContent>
             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
             *       &lt;attribute name="CityAirportCode" type="{http://www.iata.org/IATA/2007/00}StringLength1to8" />
             *       &lt;attribute name="ArrivalDate" type="{http://www.iata.org/IATA/2007/00}DateOrDateTimeType" />
             *       &lt;attribute name="DepartureDate" type="{http://www.iata.org/IATA/2007/00}DateOrDateTimeType" />
             *       &lt;attribute name="AirEquipType" type="{http://www.iata.org/IATA/2007/00}StringLength3" />
             *     &lt;/restriction>
             *   &lt;/complexContent>
             * &lt;/complexType>
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "")
            public static class UnticketedPointInfo {

                @XmlAttribute(name = "CityAirportCode")
                protected String cityAirportCode;
                @XmlAttribute(name = "ArrivalDate")
                protected String arrivalDate;
                @XmlAttribute(name = "DepartureDate")
                protected String departureDate;
                @XmlAttribute(name = "AirEquipType")
                protected String airEquipType;

                /**
                 * Gets the value of the cityAirportCode property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getCityAirportCode() {
                    return cityAirportCode;
                }

                /**
                 * Sets the value of the cityAirportCode property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setCityAirportCode(String value) {
                    this.cityAirportCode = value;
                }

                /**
                 * Gets the value of the arrivalDate property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getArrivalDate() {
                    return arrivalDate;
                }

                /**
                 * Sets the value of the arrivalDate property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setArrivalDate(String value) {
                    this.arrivalDate = value;
                }

                /**
                 * Gets the value of the departureDate property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getDepartureDate() {
                    return departureDate;
                }

                /**
                 * Sets the value of the departureDate property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setDepartureDate(String value) {
                    this.departureDate = value;
                }

                /**
                 * Gets the value of the airEquipType property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getAirEquipType() {
                    return airEquipType;
                }

                /**
                 * Sets the value of the airEquipType property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setAirEquipType(String value) {
                    this.airEquipType = value;
                }

            }

        }

    }

}

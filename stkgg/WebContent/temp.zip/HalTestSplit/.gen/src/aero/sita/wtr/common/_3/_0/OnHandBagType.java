
package aero.sita.wtr.common._3._0;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for OnHandBagType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="OnHandBagType">
 *   &lt;complexContent>
 *     &lt;extension base="{http://sita.aero/wtr/common/3/0}BagType">
 *       &lt;sequence>
 *         &lt;element name="Itinerary">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="FlightSegments">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="FlightSegment" type="{http://sita.aero/wtr/common/3/0}FlightOptionalDateOrARNKType" maxOccurs="5"/>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                   &lt;element name="Routes">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="Route" type="{http://www.iata.org/IATA/2007/00}StationType" maxOccurs="5"/>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="BagAddress" type="{http://sita.aero/wtr/common/3/0}WTR_AddressType" minOccurs="0"/>
 *         &lt;element name="BagContents" type="{http://sita.aero/wtr/common/3/0}ContentsType" minOccurs="0"/>
 *         &lt;element name="ContentsDesc" type="{http://sita.aero/wtr/common/3/0}StringLength1to58" minOccurs="0"/>
 *         &lt;element name="ContentsGender" type="{http://sita.aero/wtr/common/3/0}GenderType" minOccurs="0"/>
 *         &lt;element name="Remarks" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="Remark" type="{http://sita.aero/wtr/common/3/0}StringLength1to58" maxOccurs="3"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="BagPhones" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="Phone" type="{http://sita.aero/wtr/common/3/0}StringLength0to20" maxOccurs="2"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="BaggageWeight" type="{http://sita.aero/wtr/common/3/0}StringLength1to58" minOccurs="0"/>
 *         &lt;element name="Delivery" type="{http://sita.aero/wtr/common/3/0}DeliveryType" minOccurs="0"/>
 *         &lt;element name="RushTag" type="{http://sita.aero/wtr/common/3/0}BagTagType" minOccurs="0"/>
 *         &lt;element name="LossComments" type="{http://sita.aero/wtr/common/3/0}StringLength1to58" minOccurs="0"/>
 *         &lt;element name="DisposalDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "OnHandBagType", propOrder = {
    "itinerary",
    "bagAddress",
    "bagContents",
    "contentsDesc",
    "contentsGender",
    "remarks",
    "bagPhones",
    "baggageWeight",
    "delivery",
    "rushTag",
    "lossComments",
    "disposalDate"
})
@XmlSeeAlso({
    OnHandBagTracingType.class
})
public class OnHandBagType
    extends BagType
{

    @XmlElement(name = "Itinerary", required = true)
    protected OnHandBagType.Itinerary itinerary;
    @XmlElement(name = "BagAddress")
    protected WTRAddressType bagAddress;
    @XmlElement(name = "BagContents")
    protected ContentsType bagContents;
    @XmlElement(name = "ContentsDesc")
    protected String contentsDesc;
    @XmlElement(name = "ContentsGender")
    protected GenderType contentsGender;
    @XmlElement(name = "Remarks")
    protected OnHandBagType.Remarks remarks;
    @XmlElement(name = "BagPhones")
    protected OnHandBagType.BagPhones bagPhones;
    @XmlElement(name = "BaggageWeight")
    protected String baggageWeight;
    @XmlElement(name = "Delivery")
    protected DeliveryType delivery;
    @XmlElement(name = "RushTag")
    protected BagTagType rushTag;
    @XmlElement(name = "LossComments")
    protected String lossComments;
    @XmlElement(name = "DisposalDate")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar disposalDate;

    /**
     * Gets the value of the itinerary property.
     * 
     * @return
     *     possible object is
     *     {@link OnHandBagType.Itinerary }
     *     
     */
    public OnHandBagType.Itinerary getItinerary() {
        return itinerary;
    }

    /**
     * Sets the value of the itinerary property.
     * 
     * @param value
     *     allowed object is
     *     {@link OnHandBagType.Itinerary }
     *     
     */
    public void setItinerary(OnHandBagType.Itinerary value) {
        this.itinerary = value;
    }

    /**
     * Gets the value of the bagAddress property.
     * 
     * @return
     *     possible object is
     *     {@link WTRAddressType }
     *     
     */
    public WTRAddressType getBagAddress() {
        return bagAddress;
    }

    /**
     * Sets the value of the bagAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link WTRAddressType }
     *     
     */
    public void setBagAddress(WTRAddressType value) {
        this.bagAddress = value;
    }

    /**
     * Gets the value of the bagContents property.
     * 
     * @return
     *     possible object is
     *     {@link ContentsType }
     *     
     */
    public ContentsType getBagContents() {
        return bagContents;
    }

    /**
     * Sets the value of the bagContents property.
     * 
     * @param value
     *     allowed object is
     *     {@link ContentsType }
     *     
     */
    public void setBagContents(ContentsType value) {
        this.bagContents = value;
    }

    /**
     * Gets the value of the contentsDesc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContentsDesc() {
        return contentsDesc;
    }

    /**
     * Sets the value of the contentsDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContentsDesc(String value) {
        this.contentsDesc = value;
    }

    /**
     * Gets the value of the contentsGender property.
     * 
     * @return
     *     possible object is
     *     {@link GenderType }
     *     
     */
    public GenderType getContentsGender() {
        return contentsGender;
    }

    /**
     * Sets the value of the contentsGender property.
     * 
     * @param value
     *     allowed object is
     *     {@link GenderType }
     *     
     */
    public void setContentsGender(GenderType value) {
        this.contentsGender = value;
    }

    /**
     * Gets the value of the remarks property.
     * 
     * @return
     *     possible object is
     *     {@link OnHandBagType.Remarks }
     *     
     */
    public OnHandBagType.Remarks getRemarks() {
        return remarks;
    }

    /**
     * Sets the value of the remarks property.
     * 
     * @param value
     *     allowed object is
     *     {@link OnHandBagType.Remarks }
     *     
     */
    public void setRemarks(OnHandBagType.Remarks value) {
        this.remarks = value;
    }

    /**
     * Gets the value of the bagPhones property.
     * 
     * @return
     *     possible object is
     *     {@link OnHandBagType.BagPhones }
     *     
     */
    public OnHandBagType.BagPhones getBagPhones() {
        return bagPhones;
    }

    /**
     * Sets the value of the bagPhones property.
     * 
     * @param value
     *     allowed object is
     *     {@link OnHandBagType.BagPhones }
     *     
     */
    public void setBagPhones(OnHandBagType.BagPhones value) {
        this.bagPhones = value;
    }

    /**
     * Gets the value of the baggageWeight property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBaggageWeight() {
        return baggageWeight;
    }

    /**
     * Sets the value of the baggageWeight property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBaggageWeight(String value) {
        this.baggageWeight = value;
    }

    /**
     * Gets the value of the delivery property.
     * 
     * @return
     *     possible object is
     *     {@link DeliveryType }
     *     
     */
    public DeliveryType getDelivery() {
        return delivery;
    }

    /**
     * Sets the value of the delivery property.
     * 
     * @param value
     *     allowed object is
     *     {@link DeliveryType }
     *     
     */
    public void setDelivery(DeliveryType value) {
        this.delivery = value;
    }

    /**
     * Gets the value of the rushTag property.
     * 
     * @return
     *     possible object is
     *     {@link BagTagType }
     *     
     */
    public BagTagType getRushTag() {
        return rushTag;
    }

    /**
     * Sets the value of the rushTag property.
     * 
     * @param value
     *     allowed object is
     *     {@link BagTagType }
     *     
     */
    public void setRushTag(BagTagType value) {
        this.rushTag = value;
    }

    /**
     * Gets the value of the lossComments property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLossComments() {
        return lossComments;
    }

    /**
     * Sets the value of the lossComments property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLossComments(String value) {
        this.lossComments = value;
    }

    /**
     * Gets the value of the disposalDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDisposalDate() {
        return disposalDate;
    }

    /**
     * Sets the value of the disposalDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDisposalDate(XMLGregorianCalendar value) {
        this.disposalDate = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="Phone" type="{http://sita.aero/wtr/common/3/0}StringLength0to20" maxOccurs="2"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "phone"
    })
    public static class BagPhones {

        @XmlElement(name = "Phone", required = true)
        protected List<String> phone;

        /**
         * Gets the value of the phone property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the phone property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getPhone().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getPhone() {
            if (phone == null) {
                phone = new ArrayList<String>();
            }
            return this.phone;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="FlightSegments">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="FlightSegment" type="{http://sita.aero/wtr/common/3/0}FlightOptionalDateOrARNKType" maxOccurs="5"/>
     *                 &lt;/sequence>
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *         &lt;element name="Routes">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="Route" type="{http://www.iata.org/IATA/2007/00}StationType" maxOccurs="5"/>
     *                 &lt;/sequence>
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "flightSegments",
        "routes"
    })
    public static class Itinerary {

        @XmlElement(name = "FlightSegments", required = true)
        protected OnHandBagType.Itinerary.FlightSegments flightSegments;
        @XmlElement(name = "Routes", required = true)
        protected OnHandBagType.Itinerary.Routes routes;

        /**
         * Gets the value of the flightSegments property.
         * 
         * @return
         *     possible object is
         *     {@link OnHandBagType.Itinerary.FlightSegments }
         *     
         */
        public OnHandBagType.Itinerary.FlightSegments getFlightSegments() {
            return flightSegments;
        }

        /**
         * Sets the value of the flightSegments property.
         * 
         * @param value
         *     allowed object is
         *     {@link OnHandBagType.Itinerary.FlightSegments }
         *     
         */
        public void setFlightSegments(OnHandBagType.Itinerary.FlightSegments value) {
            this.flightSegments = value;
        }

        /**
         * Gets the value of the routes property.
         * 
         * @return
         *     possible object is
         *     {@link OnHandBagType.Itinerary.Routes }
         *     
         */
        public OnHandBagType.Itinerary.Routes getRoutes() {
            return routes;
        }

        /**
         * Sets the value of the routes property.
         * 
         * @param value
         *     allowed object is
         *     {@link OnHandBagType.Itinerary.Routes }
         *     
         */
        public void setRoutes(OnHandBagType.Itinerary.Routes value) {
            this.routes = value;
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="FlightSegment" type="{http://sita.aero/wtr/common/3/0}FlightOptionalDateOrARNKType" maxOccurs="5"/>
         *       &lt;/sequence>
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "flightSegment"
        })
        public static class FlightSegments {

            @XmlElement(name = "FlightSegment", required = true)
            protected List<FlightOptionalDateOrARNKType> flightSegment;

            /**
             * Gets the value of the flightSegment property.
             * 
             * <p>
             * This accessor method returns a reference to the live list,
             * not a snapshot. Therefore any modification you make to the
             * returned list will be present inside the JAXB object.
             * This is why there is not a <CODE>set</CODE> method for the flightSegment property.
             * 
             * <p>
             * For example, to add a new item, do as follows:
             * <pre>
             *    getFlightSegment().add(newItem);
             * </pre>
             * 
             * 
             * <p>
             * Objects of the following type(s) are allowed in the list
             * {@link FlightOptionalDateOrARNKType }
             * 
             * 
             */
            public List<FlightOptionalDateOrARNKType> getFlightSegment() {
                if (flightSegment == null) {
                    flightSegment = new ArrayList<FlightOptionalDateOrARNKType>();
                }
                return this.flightSegment;
            }

        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="Route" type="{http://www.iata.org/IATA/2007/00}StationType" maxOccurs="5"/>
         *       &lt;/sequence>
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "route"
        })
        public static class Routes {

            @XmlElement(name = "Route", required = true)
            protected List<String> route;

            /**
             * Gets the value of the route property.
             * 
             * <p>
             * This accessor method returns a reference to the live list,
             * not a snapshot. Therefore any modification you make to the
             * returned list will be present inside the JAXB object.
             * This is why there is not a <CODE>set</CODE> method for the route property.
             * 
             * <p>
             * For example, to add a new item, do as follows:
             * <pre>
             *    getRoute().add(newItem);
             * </pre>
             * 
             * 
             * <p>
             * Objects of the following type(s) are allowed in the list
             * {@link String }
             * 
             * 
             */
            public List<String> getRoute() {
                if (route == null) {
                    route = new ArrayList<String>();
                }
                return this.route;
            }

        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="Remark" type="{http://sita.aero/wtr/common/3/0}StringLength1to58" maxOccurs="3"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "remark"
    })
    public static class Remarks {

        @XmlElement(name = "Remark", required = true)
        protected List<String> remark;

        /**
         * Gets the value of the remark property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the remark property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getRemark().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getRemark() {
            if (remark == null) {
                remark = new ArrayList<String>();
            }
            return this.remark;
        }

    }

}


package aero.sita.wtr.common._3._0;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for RushBagGroupType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="RushBagGroupType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="RushBags">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="RushBag" type="{http://sita.aero/wtr/common/3/0}RushBagType" maxOccurs="18"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="RushFlights">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="FlightDateOrARNK" maxOccurs="5">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;choice>
 *                             &lt;element name="FlightDate" type="{http://sita.aero/wtr/common/3/0}FlightDateType"/>
 *                             &lt;element name="ARNK" type="{http://sita.aero/wtr/common/3/0}ARNK_Type"/>
 *                           &lt;/choice>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="RushDestinations">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="Destination" type="{http://sita.aero/wtr/common/3/0}StationAirlineType" maxOccurs="5"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="OriginalFlights" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="FlightDateOrARNK" type="{http://sita.aero/wtr/common/3/0}FlightOptionalDateOrARNKType" maxOccurs="5" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="NumberOfBags" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}integer">
 *               &lt;minInclusive value="0"/>
 *               &lt;maxInclusive value="18"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Names" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="Name" type="{http://sita.aero/wtr/common/3/0}AlphaLength2to16" maxOccurs="10"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="BagArrivalTime" type="{http://sita.aero/wtr/common/3/0}StringLength1to58" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RushBagGroupType", propOrder = {
    "rushBags",
    "rushFlights",
    "rushDestinations",
    "originalFlights",
    "numberOfBags",
    "names",
    "bagArrivalTime"
})
@XmlSeeAlso({
    RushBagGroupTypeTracing.class
})
public class RushBagGroupType {

    @XmlElement(name = "RushBags", required = true)
    protected RushBagGroupType.RushBags rushBags;
    @XmlElement(name = "RushFlights", required = true)
    protected RushBagGroupType.RushFlights rushFlights;
    @XmlElement(name = "RushDestinations", required = true)
    protected RushBagGroupType.RushDestinations rushDestinations;
    @XmlElement(name = "OriginalFlights")
    protected RushBagGroupType.OriginalFlights originalFlights;
    @XmlElement(name = "NumberOfBags")
    protected Integer numberOfBags;
    @XmlElement(name = "Names")
    protected RushBagGroupType.Names names;
    @XmlElement(name = "BagArrivalTime")
    protected String bagArrivalTime;

    /**
     * Gets the value of the rushBags property.
     * 
     * @return
     *     possible object is
     *     {@link RushBagGroupType.RushBags }
     *     
     */
    public RushBagGroupType.RushBags getRushBags() {
        return rushBags;
    }

    /**
     * Sets the value of the rushBags property.
     * 
     * @param value
     *     allowed object is
     *     {@link RushBagGroupType.RushBags }
     *     
     */
    public void setRushBags(RushBagGroupType.RushBags value) {
        this.rushBags = value;
    }

    /**
     * Gets the value of the rushFlights property.
     * 
     * @return
     *     possible object is
     *     {@link RushBagGroupType.RushFlights }
     *     
     */
    public RushBagGroupType.RushFlights getRushFlights() {
        return rushFlights;
    }

    /**
     * Sets the value of the rushFlights property.
     * 
     * @param value
     *     allowed object is
     *     {@link RushBagGroupType.RushFlights }
     *     
     */
    public void setRushFlights(RushBagGroupType.RushFlights value) {
        this.rushFlights = value;
    }

    /**
     * Gets the value of the rushDestinations property.
     * 
     * @return
     *     possible object is
     *     {@link RushBagGroupType.RushDestinations }
     *     
     */
    public RushBagGroupType.RushDestinations getRushDestinations() {
        return rushDestinations;
    }

    /**
     * Sets the value of the rushDestinations property.
     * 
     * @param value
     *     allowed object is
     *     {@link RushBagGroupType.RushDestinations }
     *     
     */
    public void setRushDestinations(RushBagGroupType.RushDestinations value) {
        this.rushDestinations = value;
    }

    /**
     * Gets the value of the originalFlights property.
     * 
     * @return
     *     possible object is
     *     {@link RushBagGroupType.OriginalFlights }
     *     
     */
    public RushBagGroupType.OriginalFlights getOriginalFlights() {
        return originalFlights;
    }

    /**
     * Sets the value of the originalFlights property.
     * 
     * @param value
     *     allowed object is
     *     {@link RushBagGroupType.OriginalFlights }
     *     
     */
    public void setOriginalFlights(RushBagGroupType.OriginalFlights value) {
        this.originalFlights = value;
    }

    /**
     * Gets the value of the numberOfBags property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getNumberOfBags() {
        return numberOfBags;
    }

    /**
     * Sets the value of the numberOfBags property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setNumberOfBags(Integer value) {
        this.numberOfBags = value;
    }

    /**
     * Gets the value of the names property.
     * 
     * @return
     *     possible object is
     *     {@link RushBagGroupType.Names }
     *     
     */
    public RushBagGroupType.Names getNames() {
        return names;
    }

    /**
     * Sets the value of the names property.
     * 
     * @param value
     *     allowed object is
     *     {@link RushBagGroupType.Names }
     *     
     */
    public void setNames(RushBagGroupType.Names value) {
        this.names = value;
    }

    /**
     * Gets the value of the bagArrivalTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBagArrivalTime() {
        return bagArrivalTime;
    }

    /**
     * Sets the value of the bagArrivalTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBagArrivalTime(String value) {
        this.bagArrivalTime = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="Name" type="{http://sita.aero/wtr/common/3/0}AlphaLength2to16" maxOccurs="10"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "name"
    })
    public static class Names {

        @XmlElement(name = "Name", required = true)
        protected List<String> name;

        /**
         * Gets the value of the name property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the name property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getName().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getName() {
            if (name == null) {
                name = new ArrayList<String>();
            }
            return this.name;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="FlightDateOrARNK" type="{http://sita.aero/wtr/common/3/0}FlightOptionalDateOrARNKType" maxOccurs="5" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "flightDateOrARNK"
    })
    public static class OriginalFlights {

        @XmlElement(name = "FlightDateOrARNK")
        protected List<FlightOptionalDateOrARNKType> flightDateOrARNK;

        /**
         * Gets the value of the flightDateOrARNK property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the flightDateOrARNK property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getFlightDateOrARNK().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link FlightOptionalDateOrARNKType }
         * 
         * 
         */
        public List<FlightOptionalDateOrARNKType> getFlightDateOrARNK() {
            if (flightDateOrARNK == null) {
                flightDateOrARNK = new ArrayList<FlightOptionalDateOrARNKType>();
            }
            return this.flightDateOrARNK;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="RushBag" type="{http://sita.aero/wtr/common/3/0}RushBagType" maxOccurs="18"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "rushBag"
    })
    public static class RushBags {

        @XmlElement(name = "RushBag", required = true)
        protected List<RushBagType> rushBag;

        /**
         * Gets the value of the rushBag property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the rushBag property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getRushBag().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link RushBagType }
         * 
         * 
         */
        public List<RushBagType> getRushBag() {
            if (rushBag == null) {
                rushBag = new ArrayList<RushBagType>();
            }
            return this.rushBag;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="Destination" type="{http://sita.aero/wtr/common/3/0}StationAirlineType" maxOccurs="5"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "destination"
    })
    public static class RushDestinations {

        @XmlElement(name = "Destination", required = true)
        protected List<StationAirlineType> destination;

        /**
         * Gets the value of the destination property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the destination property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getDestination().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link StationAirlineType }
         * 
         * 
         */
        public List<StationAirlineType> getDestination() {
            if (destination == null) {
                destination = new ArrayList<StationAirlineType>();
            }
            return this.destination;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="FlightDateOrARNK" maxOccurs="5">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;choice>
     *                   &lt;element name="FlightDate" type="{http://sita.aero/wtr/common/3/0}FlightDateType"/>
     *                   &lt;element name="ARNK" type="{http://sita.aero/wtr/common/3/0}ARNK_Type"/>
     *                 &lt;/choice>
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "flightDateOrARNK"
    })
    public static class RushFlights {

        @XmlElement(name = "FlightDateOrARNK", required = true)
        protected List<RushBagGroupType.RushFlights.FlightDateOrARNK> flightDateOrARNK;

        /**
         * Gets the value of the flightDateOrARNK property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the flightDateOrARNK property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getFlightDateOrARNK().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link RushBagGroupType.RushFlights.FlightDateOrARNK }
         * 
         * 
         */
        public List<RushBagGroupType.RushFlights.FlightDateOrARNK> getFlightDateOrARNK() {
            if (flightDateOrARNK == null) {
                flightDateOrARNK = new ArrayList<RushBagGroupType.RushFlights.FlightDateOrARNK>();
            }
            return this.flightDateOrARNK;
        }


        /**
         * FD - Contians Flight date or ARNK
         * 
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;choice>
         *         &lt;element name="FlightDate" type="{http://sita.aero/wtr/common/3/0}FlightDateType"/>
         *         &lt;element name="ARNK" type="{http://sita.aero/wtr/common/3/0}ARNK_Type"/>
         *       &lt;/choice>
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "flightDate",
            "arnk"
        })
        public static class FlightDateOrARNK {

            @XmlElement(name = "FlightDate")
            protected FlightDateType flightDate;
            @XmlElement(name = "ARNK")
            protected String arnk;

            /**
             * Gets the value of the flightDate property.
             * 
             * @return
             *     possible object is
             *     {@link FlightDateType }
             *     
             */
            public FlightDateType getFlightDate() {
                return flightDate;
            }

            /**
             * Sets the value of the flightDate property.
             * 
             * @param value
             *     allowed object is
             *     {@link FlightDateType }
             *     
             */
            public void setFlightDate(FlightDateType value) {
                this.flightDate = value;
            }

            /**
             * Gets the value of the arnk property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getARNK() {
                return arnk;
            }

            /**
             * Sets the value of the arnk property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setARNK(String value) {
                this.arnk = value;
            }

        }

    }

}

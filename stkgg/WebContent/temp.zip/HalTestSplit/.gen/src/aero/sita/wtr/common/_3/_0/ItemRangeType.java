
package aero.sita.wtr.common._3._0;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ItemRangeType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ItemRangeType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="FromItem" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="ToItem" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ItemRangeType", propOrder = {
    "fromItem",
    "toItem"
})
public class ItemRangeType {

    @XmlElement(name = "FromItem")
    protected int fromItem;
    @XmlElement(name = "ToItem")
    protected Integer toItem;

    /**
     * Gets the value of the fromItem property.
     * 
     */
    public int getFromItem() {
        return fromItem;
    }

    /**
     * Sets the value of the fromItem property.
     * 
     */
    public void setFromItem(int value) {
        this.fromItem = value;
    }

    /**
     * Gets the value of the toItem property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getToItem() {
        return toItem;
    }

    /**
     * Sets the value of the toItem property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setToItem(Integer value) {
        this.toItem = value;
    }

}


package aero.sita.wtr.common._3._0;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;


/**
 * <p>Java class for BagType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BagType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ColorTypeDesc" type="{http://sita.aero/wtr/common/3/0}ColorTypeDescType"/>
 *         &lt;element name="BagTag" type="{http://sita.aero/wtr/common/3/0}BagTagType" minOccurs="0"/>
 *         &lt;element name="BrandInfo" minOccurs="0">
 *           &lt;complexType>
 *             &lt;simpleContent>
 *               &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>StringLength2to58">
 *                 &lt;attribute name="Suspended" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *               &lt;/extension>
 *             &lt;/simpleContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="BagDelivery" type="{http://sita.aero/wtr/common/3/0}BagDeliveryType" minOccurs="0"/>
 *         &lt;element name="LockCode" type="{http://sita.aero/wtr/common/3/0}AlphaNumericStringLength1to6" minOccurs="0"/>
 *         &lt;element name="UniqueID" minOccurs="0">
 *           &lt;complexType>
 *             &lt;simpleContent>
 *               &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>UniqueIDType">
 *                 &lt;attribute name="Suspended" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *               &lt;/extension>
 *             &lt;/simpleContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="BagSentToCustoms" type="{http://sita.aero/wtr/common/3/0}CustomsDate" minOccurs="0"/>
 *         &lt;element name="BagReceivedFromCustoms" type="{http://sita.aero/wtr/common/3/0}CustomsDate" minOccurs="0"/>
 *         &lt;element name="StorageLocation" type="{http://www.iata.org/IATA/2007/00}StringLength1to32" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BagType", propOrder = {
    "colorTypeDesc",
    "bagTag",
    "brandInfo",
    "bagDelivery",
    "lockCode",
    "uniqueID",
    "bagSentToCustoms",
    "bagReceivedFromCustoms",
    "storageLocation"
})
@XmlSeeAlso({
    DamagedBagType.class,
    OnHandBagType.class,
    DelayedBagType.class
})
public class BagType {

    @XmlElement(name = "ColorTypeDesc", required = true)
    protected ColorTypeDescType colorTypeDesc;
    @XmlElement(name = "BagTag")
    protected BagTagType bagTag;
    @XmlElement(name = "BrandInfo")
    protected BagType.BrandInfo brandInfo;
    @XmlElement(name = "BagDelivery")
    protected BagDeliveryType bagDelivery;
    @XmlElement(name = "LockCode")
    protected String lockCode;
    @XmlElement(name = "UniqueID")
    protected BagType.UniqueID uniqueID;
    @XmlElement(name = "BagSentToCustoms")
    protected CustomsDate bagSentToCustoms;
    @XmlElement(name = "BagReceivedFromCustoms")
    protected CustomsDate bagReceivedFromCustoms;
    @XmlElement(name = "StorageLocation")
    protected String storageLocation;

    /**
     * Gets the value of the colorTypeDesc property.
     * 
     * @return
     *     possible object is
     *     {@link ColorTypeDescType }
     *     
     */
    public ColorTypeDescType getColorTypeDesc() {
        return colorTypeDesc;
    }

    /**
     * Sets the value of the colorTypeDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link ColorTypeDescType }
     *     
     */
    public void setColorTypeDesc(ColorTypeDescType value) {
        this.colorTypeDesc = value;
    }

    /**
     * Gets the value of the bagTag property.
     * 
     * @return
     *     possible object is
     *     {@link BagTagType }
     *     
     */
    public BagTagType getBagTag() {
        return bagTag;
    }

    /**
     * Sets the value of the bagTag property.
     * 
     * @param value
     *     allowed object is
     *     {@link BagTagType }
     *     
     */
    public void setBagTag(BagTagType value) {
        this.bagTag = value;
    }

    /**
     * Gets the value of the brandInfo property.
     * 
     * @return
     *     possible object is
     *     {@link BagType.BrandInfo }
     *     
     */
    public BagType.BrandInfo getBrandInfo() {
        return brandInfo;
    }

    /**
     * Sets the value of the brandInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link BagType.BrandInfo }
     *     
     */
    public void setBrandInfo(BagType.BrandInfo value) {
        this.brandInfo = value;
    }

    /**
     * Gets the value of the bagDelivery property.
     * 
     * @return
     *     possible object is
     *     {@link BagDeliveryType }
     *     
     */
    public BagDeliveryType getBagDelivery() {
        return bagDelivery;
    }

    /**
     * Sets the value of the bagDelivery property.
     * 
     * @param value
     *     allowed object is
     *     {@link BagDeliveryType }
     *     
     */
    public void setBagDelivery(BagDeliveryType value) {
        this.bagDelivery = value;
    }

    /**
     * Gets the value of the lockCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLockCode() {
        return lockCode;
    }

    /**
     * Sets the value of the lockCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLockCode(String value) {
        this.lockCode = value;
    }

    /**
     * Gets the value of the uniqueID property.
     * 
     * @return
     *     possible object is
     *     {@link BagType.UniqueID }
     *     
     */
    public BagType.UniqueID getUniqueID() {
        return uniqueID;
    }

    /**
     * Sets the value of the uniqueID property.
     * 
     * @param value
     *     allowed object is
     *     {@link BagType.UniqueID }
     *     
     */
    public void setUniqueID(BagType.UniqueID value) {
        this.uniqueID = value;
    }

    /**
     * Gets the value of the bagSentToCustoms property.
     * 
     * @return
     *     possible object is
     *     {@link CustomsDate }
     *     
     */
    public CustomsDate getBagSentToCustoms() {
        return bagSentToCustoms;
    }

    /**
     * Sets the value of the bagSentToCustoms property.
     * 
     * @param value
     *     allowed object is
     *     {@link CustomsDate }
     *     
     */
    public void setBagSentToCustoms(CustomsDate value) {
        this.bagSentToCustoms = value;
    }

    /**
     * Gets the value of the bagReceivedFromCustoms property.
     * 
     * @return
     *     possible object is
     *     {@link CustomsDate }
     *     
     */
    public CustomsDate getBagReceivedFromCustoms() {
        return bagReceivedFromCustoms;
    }

    /**
     * Sets the value of the bagReceivedFromCustoms property.
     * 
     * @param value
     *     allowed object is
     *     {@link CustomsDate }
     *     
     */
    public void setBagReceivedFromCustoms(CustomsDate value) {
        this.bagReceivedFromCustoms = value;
    }

    /**
     * Gets the value of the storageLocation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStorageLocation() {
        return storageLocation;
    }

    /**
     * Sets the value of the storageLocation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStorageLocation(String value) {
        this.storageLocation = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;simpleContent>
     *     &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>StringLength2to58">
     *       &lt;attribute name="Suspended" type="{http://www.w3.org/2001/XMLSchema}boolean" />
     *     &lt;/extension>
     *   &lt;/simpleContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class BrandInfo {

        @XmlValue
        protected String value;
        @XmlAttribute(name = "Suspended")
        protected Boolean suspended;

        /**
         * Used for Character Strings, length 2 to 58
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setValue(String value) {
            this.value = value;
        }

        /**
         * Gets the value of the suspended property.
         * 
         * @return
         *     possible object is
         *     {@link Boolean }
         *     
         */
        public Boolean isSuspended() {
            return suspended;
        }

        /**
         * Sets the value of the suspended property.
         * 
         * @param value
         *     allowed object is
         *     {@link Boolean }
         *     
         */
        public void setSuspended(Boolean value) {
            this.suspended = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;simpleContent>
     *     &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>UniqueIDType">
     *       &lt;attribute name="Suspended" type="{http://www.w3.org/2001/XMLSchema}boolean" />
     *     &lt;/extension>
     *   &lt;/simpleContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class UniqueID {

        @XmlValue
        protected String value;
        @XmlAttribute(name = "Suspended")
        protected Boolean suspended;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setValue(String value) {
            this.value = value;
        }

        /**
         * Gets the value of the suspended property.
         * 
         * @return
         *     possible object is
         *     {@link Boolean }
         *     
         */
        public Boolean isSuspended() {
            return suspended;
        }

        /**
         * Sets the value of the suspended property.
         * 
         * @param value
         *     allowed object is
         *     {@link Boolean }
         *     
         */
        public void setSuspended(Boolean value) {
            this.suspended = value;
        }

    }

}

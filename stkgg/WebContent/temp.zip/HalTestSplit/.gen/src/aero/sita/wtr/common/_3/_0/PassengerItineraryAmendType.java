
package aero.sita.wtr.common._3._0;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;


/**
 * Contains details of a passenger like name, address etc
 * 
 * <p>Java class for PassengerItineraryAmendType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PassengerItineraryAmendType">
 *   &lt;complexContent>
 *     &lt;extension base="{http://sita.aero/wtr/common/3/0}PassengerAmendType">
 *       &lt;sequence>
 *         &lt;element name="Itinerary" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="FlightSegments" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="Flight" type="{http://sita.aero/wtr/common/3/0}FlightSegmentOrARNK_AmendType" maxOccurs="5"/>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                   &lt;element name="AdditionalRoutes" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="Route" type="{http://www.iata.org/IATA/2007/00}StationType" maxOccurs="13"/>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="Status" minOccurs="0">
 *           &lt;complexType>
 *             &lt;simpleContent>
 *               &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>StringLength0to58">
 *                 &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
 *               &lt;/extension>
 *             &lt;/simpleContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="PooledTktNumber" minOccurs="0">
 *           &lt;complexType>
 *             &lt;simpleContent>
 *               &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>AlphaNumericStringLength0to15">
 *                 &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
 *               &lt;/extension>
 *             &lt;/simpleContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="FareBasis" minOccurs="0">
 *           &lt;complexType>
 *             &lt;simpleContent>
 *               &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>AlphaNumericStringLength0to7">
 *                 &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
 *               &lt;/extension>
 *             &lt;/simpleContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PassengerItineraryAmendType", propOrder = {
    "itinerary",
    "status",
    "pooledTktNumber",
    "fareBasis"
})
public class PassengerItineraryAmendType
    extends PassengerAmendType
{

    @XmlElement(name = "Itinerary")
    protected PassengerItineraryAmendType.Itinerary itinerary;
    @XmlElement(name = "Status")
    protected PassengerItineraryAmendType.Status status;
    @XmlElement(name = "PooledTktNumber")
    protected PassengerItineraryAmendType.PooledTktNumber pooledTktNumber;
    @XmlElement(name = "FareBasis")
    protected PassengerItineraryAmendType.FareBasis fareBasis;

    /**
     * Gets the value of the itinerary property.
     * 
     * @return
     *     possible object is
     *     {@link PassengerItineraryAmendType.Itinerary }
     *     
     */
    public PassengerItineraryAmendType.Itinerary getItinerary() {
        return itinerary;
    }

    /**
     * Sets the value of the itinerary property.
     * 
     * @param value
     *     allowed object is
     *     {@link PassengerItineraryAmendType.Itinerary }
     *     
     */
    public void setItinerary(PassengerItineraryAmendType.Itinerary value) {
        this.itinerary = value;
    }

    /**
     * Gets the value of the status property.
     * 
     * @return
     *     possible object is
     *     {@link PassengerItineraryAmendType.Status }
     *     
     */
    public PassengerItineraryAmendType.Status getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link PassengerItineraryAmendType.Status }
     *     
     */
    public void setStatus(PassengerItineraryAmendType.Status value) {
        this.status = value;
    }

    /**
     * Gets the value of the pooledTktNumber property.
     * 
     * @return
     *     possible object is
     *     {@link PassengerItineraryAmendType.PooledTktNumber }
     *     
     */
    public PassengerItineraryAmendType.PooledTktNumber getPooledTktNumber() {
        return pooledTktNumber;
    }

    /**
     * Sets the value of the pooledTktNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link PassengerItineraryAmendType.PooledTktNumber }
     *     
     */
    public void setPooledTktNumber(PassengerItineraryAmendType.PooledTktNumber value) {
        this.pooledTktNumber = value;
    }

    /**
     * Gets the value of the fareBasis property.
     * 
     * @return
     *     possible object is
     *     {@link PassengerItineraryAmendType.FareBasis }
     *     
     */
    public PassengerItineraryAmendType.FareBasis getFareBasis() {
        return fareBasis;
    }

    /**
     * Sets the value of the fareBasis property.
     * 
     * @param value
     *     allowed object is
     *     {@link PassengerItineraryAmendType.FareBasis }
     *     
     */
    public void setFareBasis(PassengerItineraryAmendType.FareBasis value) {
        this.fareBasis = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;simpleContent>
     *     &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>AlphaNumericStringLength0to7">
     *       &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
     *     &lt;/extension>
     *   &lt;/simpleContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class FareBasis {

        @XmlValue
        protected String value;
        @XmlAttribute(name = "Delete")
        protected Boolean delete;

        /**
         * Used for Alpha Numeric Strings, length 0 and 7
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setValue(String value) {
            this.value = value;
        }

        /**
         * Gets the value of the delete property.
         * 
         * @return
         *     possible object is
         *     {@link Boolean }
         *     
         */
        public boolean isDelete() {
            if (delete == null) {
                return false;
            } else {
                return delete;
            }
        }

        /**
         * Sets the value of the delete property.
         * 
         * @param value
         *     allowed object is
         *     {@link Boolean }
         *     
         */
        public void setDelete(Boolean value) {
            this.delete = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="FlightSegments" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="Flight" type="{http://sita.aero/wtr/common/3/0}FlightSegmentOrARNK_AmendType" maxOccurs="5"/>
     *                 &lt;/sequence>
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *         &lt;element name="AdditionalRoutes" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="Route" type="{http://www.iata.org/IATA/2007/00}StationType" maxOccurs="13"/>
     *                 &lt;/sequence>
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "flightSegments",
        "additionalRoutes"
    })
    public static class Itinerary {

        @XmlElement(name = "FlightSegments")
        protected PassengerItineraryAmendType.Itinerary.FlightSegments flightSegments;
        @XmlElement(name = "AdditionalRoutes")
        protected PassengerItineraryAmendType.Itinerary.AdditionalRoutes additionalRoutes;

        /**
         * Gets the value of the flightSegments property.
         * 
         * @return
         *     possible object is
         *     {@link PassengerItineraryAmendType.Itinerary.FlightSegments }
         *     
         */
        public PassengerItineraryAmendType.Itinerary.FlightSegments getFlightSegments() {
            return flightSegments;
        }

        /**
         * Sets the value of the flightSegments property.
         * 
         * @param value
         *     allowed object is
         *     {@link PassengerItineraryAmendType.Itinerary.FlightSegments }
         *     
         */
        public void setFlightSegments(PassengerItineraryAmendType.Itinerary.FlightSegments value) {
            this.flightSegments = value;
        }

        /**
         * Gets the value of the additionalRoutes property.
         * 
         * @return
         *     possible object is
         *     {@link PassengerItineraryAmendType.Itinerary.AdditionalRoutes }
         *     
         */
        public PassengerItineraryAmendType.Itinerary.AdditionalRoutes getAdditionalRoutes() {
            return additionalRoutes;
        }

        /**
         * Sets the value of the additionalRoutes property.
         * 
         * @param value
         *     allowed object is
         *     {@link PassengerItineraryAmendType.Itinerary.AdditionalRoutes }
         *     
         */
        public void setAdditionalRoutes(PassengerItineraryAmendType.Itinerary.AdditionalRoutes value) {
            this.additionalRoutes = value;
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="Route" type="{http://www.iata.org/IATA/2007/00}StationType" maxOccurs="13"/>
         *       &lt;/sequence>
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "route"
        })
        public static class AdditionalRoutes {

            @XmlElement(name = "Route", required = true)
            protected List<String> route;

            /**
             * Gets the value of the route property.
             * 
             * <p>
             * This accessor method returns a reference to the live list,
             * not a snapshot. Therefore any modification you make to the
             * returned list will be present inside the JAXB object.
             * This is why there is not a <CODE>set</CODE> method for the route property.
             * 
             * <p>
             * For example, to add a new item, do as follows:
             * <pre>
             *    getRoute().add(newItem);
             * </pre>
             * 
             * 
             * <p>
             * Objects of the following type(s) are allowed in the list
             * {@link String }
             * 
             * 
             */
            public List<String> getRoute() {
                if (route == null) {
                    route = new ArrayList<String>();
                }
                return this.route;
            }

        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="Flight" type="{http://sita.aero/wtr/common/3/0}FlightSegmentOrARNK_AmendType" maxOccurs="5"/>
         *       &lt;/sequence>
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "flight"
        })
        public static class FlightSegments {

            @XmlElement(name = "Flight", required = true)
            protected List<FlightSegmentOrARNKAmendType> flight;

            /**
             * Gets the value of the flight property.
             * 
             * <p>
             * This accessor method returns a reference to the live list,
             * not a snapshot. Therefore any modification you make to the
             * returned list will be present inside the JAXB object.
             * This is why there is not a <CODE>set</CODE> method for the flight property.
             * 
             * <p>
             * For example, to add a new item, do as follows:
             * <pre>
             *    getFlight().add(newItem);
             * </pre>
             * 
             * 
             * <p>
             * Objects of the following type(s) are allowed in the list
             * {@link FlightSegmentOrARNKAmendType }
             * 
             * 
             */
            public List<FlightSegmentOrARNKAmendType> getFlight() {
                if (flight == null) {
                    flight = new ArrayList<FlightSegmentOrARNKAmendType>();
                }
                return this.flight;
            }

        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;simpleContent>
     *     &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>AlphaNumericStringLength0to15">
     *       &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
     *     &lt;/extension>
     *   &lt;/simpleContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class PooledTktNumber {

        @XmlValue
        protected String value;
        @XmlAttribute(name = "Delete")
        protected Boolean delete;

        /**
         * Used for Alpha Numeric Strings, length 0 and 15
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setValue(String value) {
            this.value = value;
        }

        /**
         * Gets the value of the delete property.
         * 
         * @return
         *     possible object is
         *     {@link Boolean }
         *     
         */
        public boolean isDelete() {
            if (delete == null) {
                return false;
            } else {
                return delete;
            }
        }

        /**
         * Sets the value of the delete property.
         * 
         * @param value
         *     allowed object is
         *     {@link Boolean }
         *     
         */
        public void setDelete(Boolean value) {
            this.delete = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;simpleContent>
     *     &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>StringLength0to58">
     *       &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
     *     &lt;/extension>
     *   &lt;/simpleContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class Status {

        @XmlValue
        protected String value;
        @XmlAttribute(name = "Delete")
        protected Boolean delete;

        /**
         * Used for Character Strings, length 0 to 58
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setValue(String value) {
            this.value = value;
        }

        /**
         * Gets the value of the delete property.
         * 
         * @return
         *     possible object is
         *     {@link Boolean }
         *     
         */
        public boolean isDelete() {
            if (delete == null) {
                return false;
            } else {
                return delete;
            }
        }

        /**
         * Sets the value of the delete property.
         * 
         * @param value
         *     allowed object is
         *     {@link Boolean }
         *     
         */
        public void setDelete(Boolean value) {
            this.delete = value;
        }

    }

}

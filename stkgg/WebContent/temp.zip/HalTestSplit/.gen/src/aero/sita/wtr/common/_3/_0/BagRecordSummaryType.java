
package aero.sita.wtr.common._3._0;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * Contins a summary of a bag record
 * 
 * <p>Java class for BagRecordSummaryType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BagRecordSummaryType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="RecordIdentifier" type="{http://sita.aero/wtr/common/3/0}RecordIdentifierType"/>
 *         &lt;element name="Status" type="{http://sita.aero/wtr/common/3/0}RecordStatus"/>
 *         &lt;element name="Names" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="Name" type="{http://sita.aero/wtr/common/3/0}NameType" maxOccurs="10"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="Initials" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="Intial" type="{http://sita.aero/wtr/common/3/0}InitialType" maxOccurs="3"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="OriginalBags" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="Bag" type="{http://sita.aero/wtr/common/3/0}BagSummaryType" maxOccurs="18"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="RushBags" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="Bag" type="{http://sita.aero/wtr/common/3/0}BagSummaryType" maxOccurs="18"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="LossReasonCode" type="{http://sita.aero/wtr/common/3/0}LossReasonCodeType" minOccurs="0"/>
 *         &lt;element name="CreateDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="FurtherInfo" type="{http://sita.aero/wtr/common/3/0}StringLength1to58" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BagRecordSummaryType", propOrder = {
    "recordIdentifier",
    "status",
    "names",
    "initials",
    "originalBags",
    "rushBags",
    "lossReasonCode",
    "createDate",
    "furtherInfo"
})
public class BagRecordSummaryType {

    @XmlElement(name = "RecordIdentifier", required = true)
    protected RecordIdentifierType recordIdentifier;
    @XmlElement(name = "Status", required = true)
    protected RecordStatus status;
    @XmlElement(name = "Names")
    protected BagRecordSummaryType.Names names;
    @XmlElement(name = "Initials")
    protected BagRecordSummaryType.Initials initials;
    @XmlElement(name = "OriginalBags")
    protected BagRecordSummaryType.OriginalBags originalBags;
    @XmlElement(name = "RushBags")
    protected BagRecordSummaryType.RushBags rushBags;
    @XmlElement(name = "LossReasonCode")
    protected Integer lossReasonCode;
    @XmlElement(name = "CreateDate")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar createDate;
    @XmlElement(name = "FurtherInfo")
    protected String furtherInfo;

    /**
     * Gets the value of the recordIdentifier property.
     * 
     * @return
     *     possible object is
     *     {@link RecordIdentifierType }
     *     
     */
    public RecordIdentifierType getRecordIdentifier() {
        return recordIdentifier;
    }

    /**
     * Sets the value of the recordIdentifier property.
     * 
     * @param value
     *     allowed object is
     *     {@link RecordIdentifierType }
     *     
     */
    public void setRecordIdentifier(RecordIdentifierType value) {
        this.recordIdentifier = value;
    }

    /**
     * Gets the value of the status property.
     * 
     * @return
     *     possible object is
     *     {@link RecordStatus }
     *     
     */
    public RecordStatus getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link RecordStatus }
     *     
     */
    public void setStatus(RecordStatus value) {
        this.status = value;
    }

    /**
     * Gets the value of the names property.
     * 
     * @return
     *     possible object is
     *     {@link BagRecordSummaryType.Names }
     *     
     */
    public BagRecordSummaryType.Names getNames() {
        return names;
    }

    /**
     * Sets the value of the names property.
     * 
     * @param value
     *     allowed object is
     *     {@link BagRecordSummaryType.Names }
     *     
     */
    public void setNames(BagRecordSummaryType.Names value) {
        this.names = value;
    }

    /**
     * Gets the value of the initials property.
     * 
     * @return
     *     possible object is
     *     {@link BagRecordSummaryType.Initials }
     *     
     */
    public BagRecordSummaryType.Initials getInitials() {
        return initials;
    }

    /**
     * Sets the value of the initials property.
     * 
     * @param value
     *     allowed object is
     *     {@link BagRecordSummaryType.Initials }
     *     
     */
    public void setInitials(BagRecordSummaryType.Initials value) {
        this.initials = value;
    }

    /**
     * Gets the value of the originalBags property.
     * 
     * @return
     *     possible object is
     *     {@link BagRecordSummaryType.OriginalBags }
     *     
     */
    public BagRecordSummaryType.OriginalBags getOriginalBags() {
        return originalBags;
    }

    /**
     * Sets the value of the originalBags property.
     * 
     * @param value
     *     allowed object is
     *     {@link BagRecordSummaryType.OriginalBags }
     *     
     */
    public void setOriginalBags(BagRecordSummaryType.OriginalBags value) {
        this.originalBags = value;
    }

    /**
     * Gets the value of the rushBags property.
     * 
     * @return
     *     possible object is
     *     {@link BagRecordSummaryType.RushBags }
     *     
     */
    public BagRecordSummaryType.RushBags getRushBags() {
        return rushBags;
    }

    /**
     * Sets the value of the rushBags property.
     * 
     * @param value
     *     allowed object is
     *     {@link BagRecordSummaryType.RushBags }
     *     
     */
    public void setRushBags(BagRecordSummaryType.RushBags value) {
        this.rushBags = value;
    }

    /**
     * Gets the value of the lossReasonCode property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getLossReasonCode() {
        return lossReasonCode;
    }

    /**
     * Sets the value of the lossReasonCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setLossReasonCode(Integer value) {
        this.lossReasonCode = value;
    }

    /**
     * Gets the value of the createDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getCreateDate() {
        return createDate;
    }

    /**
     * Sets the value of the createDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setCreateDate(XMLGregorianCalendar value) {
        this.createDate = value;
    }

    /**
     * Gets the value of the furtherInfo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFurtherInfo() {
        return furtherInfo;
    }

    /**
     * Sets the value of the furtherInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFurtherInfo(String value) {
        this.furtherInfo = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="Intial" type="{http://sita.aero/wtr/common/3/0}InitialType" maxOccurs="3"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "intial"
    })
    public static class Initials {

        @XmlElement(name = "Intial", required = true)
        protected List<InitialType> intial;

        /**
         * Gets the value of the intial property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the intial property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getIntial().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link InitialType }
         * 
         * 
         */
        public List<InitialType> getIntial() {
            if (intial == null) {
                intial = new ArrayList<InitialType>();
            }
            return this.intial;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="Name" type="{http://sita.aero/wtr/common/3/0}NameType" maxOccurs="10"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "name"
    })
    public static class Names {

        @XmlElement(name = "Name", required = true)
        protected List<NameType> name;

        /**
         * Gets the value of the name property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the name property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getName().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link NameType }
         * 
         * 
         */
        public List<NameType> getName() {
            if (name == null) {
                name = new ArrayList<NameType>();
            }
            return this.name;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="Bag" type="{http://sita.aero/wtr/common/3/0}BagSummaryType" maxOccurs="18"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "bag"
    })
    public static class OriginalBags {

        @XmlElement(name = "Bag", required = true)
        protected List<BagSummaryType> bag;

        /**
         * Gets the value of the bag property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the bag property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getBag().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link BagSummaryType }
         * 
         * 
         */
        public List<BagSummaryType> getBag() {
            if (bag == null) {
                bag = new ArrayList<BagSummaryType>();
            }
            return this.bag;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="Bag" type="{http://sita.aero/wtr/common/3/0}BagSummaryType" maxOccurs="18"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "bag"
    })
    public static class RushBags {

        @XmlElement(name = "Bag", required = true)
        protected List<BagSummaryType> bag;

        /**
         * Gets the value of the bag property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the bag property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getBag().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link BagSummaryType }
         * 
         * 
         */
        public List<BagSummaryType> getBag() {
            if (bag == null) {
                bag = new ArrayList<BagSummaryType>();
            }
            return this.bag;
        }

    }

}

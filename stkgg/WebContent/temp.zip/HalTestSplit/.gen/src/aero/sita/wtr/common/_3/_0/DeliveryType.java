
package aero.sita.wtr.common._3._0;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * Contians the deatials required for the delivery of the bag
 * 
 * <p>Java class for DeliveryType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DeliveryType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="DeliveryAddress" type="{http://sita.aero/wtr/common/3/0}WTR_AddressType" minOccurs="0"/>
 *         &lt;element name="DeliveryWeight" type="{http://sita.aero/wtr/common/3/0}StringLength1to9" minOccurs="0"/>
 *         &lt;element name="LocalDlvInfo" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="DlvInfo" type="{http://sita.aero/wtr/common/3/0}StringLength0to58" maxOccurs="2"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="DeliveryService" type="{http://sita.aero/wtr/common/3/0}StringLength0to205" maxOccurs="10" minOccurs="0"/>
 *         &lt;element name="DeliveryInfo" type="{http://sita.aero/wtr/common/3/0}StringLength0to2000" maxOccurs="10" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DeliveryType", propOrder = {
    "deliveryAddress",
    "deliveryWeight",
    "localDlvInfo",
    "deliveryService",
    "deliveryInfo"
})
public class DeliveryType {

    @XmlElement(name = "DeliveryAddress")
    protected WTRAddressType deliveryAddress;
    @XmlElement(name = "DeliveryWeight")
    protected String deliveryWeight;
    @XmlElement(name = "LocalDlvInfo")
    protected DeliveryType.LocalDlvInfo localDlvInfo;
    @XmlElement(name = "DeliveryService")
    protected List<String> deliveryService;
    @XmlElement(name = "DeliveryInfo")
    protected List<String> deliveryInfo;

    /**
     * Gets the value of the deliveryAddress property.
     * 
     * @return
     *     possible object is
     *     {@link WTRAddressType }
     *     
     */
    public WTRAddressType getDeliveryAddress() {
        return deliveryAddress;
    }

    /**
     * Sets the value of the deliveryAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link WTRAddressType }
     *     
     */
    public void setDeliveryAddress(WTRAddressType value) {
        this.deliveryAddress = value;
    }

    /**
     * Gets the value of the deliveryWeight property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeliveryWeight() {
        return deliveryWeight;
    }

    /**
     * Sets the value of the deliveryWeight property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeliveryWeight(String value) {
        this.deliveryWeight = value;
    }

    /**
     * Gets the value of the localDlvInfo property.
     * 
     * @return
     *     possible object is
     *     {@link DeliveryType.LocalDlvInfo }
     *     
     */
    public DeliveryType.LocalDlvInfo getLocalDlvInfo() {
        return localDlvInfo;
    }

    /**
     * Sets the value of the localDlvInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link DeliveryType.LocalDlvInfo }
     *     
     */
    public void setLocalDlvInfo(DeliveryType.LocalDlvInfo value) {
        this.localDlvInfo = value;
    }

    /**
     * Gets the value of the deliveryService property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the deliveryService property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDeliveryService().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getDeliveryService() {
        if (deliveryService == null) {
            deliveryService = new ArrayList<String>();
        }
        return this.deliveryService;
    }

    /**
     * Gets the value of the deliveryInfo property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the deliveryInfo property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDeliveryInfo().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getDeliveryInfo() {
        if (deliveryInfo == null) {
            deliveryInfo = new ArrayList<String>();
        }
        return this.deliveryInfo;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="DlvInfo" type="{http://sita.aero/wtr/common/3/0}StringLength0to58" maxOccurs="2"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "dlvInfo"
    })
    public static class LocalDlvInfo {

        @XmlElement(name = "DlvInfo", required = true)
        protected List<String> dlvInfo;

        /**
         * Gets the value of the dlvInfo property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the dlvInfo property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getDlvInfo().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getDlvInfo() {
            if (dlvInfo == null) {
                dlvInfo = new ArrayList<String>();
            }
            return this.dlvInfo;
        }

    }

}

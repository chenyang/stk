
package aero.sita.wtr.common._3._0;

import java.math.BigDecimal;
import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DelayedClaimType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DelayedClaimType">
 *   &lt;complexContent>
 *     &lt;extension base="{http://sita.aero/wtr/common/3/0}ClaimType">
 *       &lt;sequence>
 *         &lt;element name="LossReasonCode" type="{http://sita.aero/wtr/common/3/0}LossReasonCodeType" minOccurs="0"/>
 *         &lt;element name="ToiletKits" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="Male" type="{http://sita.aero/wtr/common/3/0}NumericLength2" minOccurs="0"/>
 *                   &lt;element name="Female" type="{http://sita.aero/wtr/common/3/0}NumericLength2" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="ExcessValue" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;attGroup ref="{http://www.iata.org/IATA/2007/00}CurrencyAmountGroup"/>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DelayedClaimType", propOrder = {
    "lossReasonCode",
    "toiletKits",
    "excessValue"
})
public class DelayedClaimType
    extends ClaimType
{

    @XmlElement(name = "LossReasonCode")
    protected Integer lossReasonCode;
    @XmlElement(name = "ToiletKits")
    protected DelayedClaimType.ToiletKits toiletKits;
    @XmlElement(name = "ExcessValue")
    protected DelayedClaimType.ExcessValue excessValue;

    /**
     * Gets the value of the lossReasonCode property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getLossReasonCode() {
        return lossReasonCode;
    }

    /**
     * Sets the value of the lossReasonCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setLossReasonCode(Integer value) {
        this.lossReasonCode = value;
    }

    /**
     * Gets the value of the toiletKits property.
     * 
     * @return
     *     possible object is
     *     {@link DelayedClaimType.ToiletKits }
     *     
     */
    public DelayedClaimType.ToiletKits getToiletKits() {
        return toiletKits;
    }

    /**
     * Sets the value of the toiletKits property.
     * 
     * @param value
     *     allowed object is
     *     {@link DelayedClaimType.ToiletKits }
     *     
     */
    public void setToiletKits(DelayedClaimType.ToiletKits value) {
        this.toiletKits = value;
    }

    /**
     * Gets the value of the excessValue property.
     * 
     * @return
     *     possible object is
     *     {@link DelayedClaimType.ExcessValue }
     *     
     */
    public DelayedClaimType.ExcessValue getExcessValue() {
        return excessValue;
    }

    /**
     * Sets the value of the excessValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link DelayedClaimType.ExcessValue }
     *     
     */
    public void setExcessValue(DelayedClaimType.ExcessValue value) {
        this.excessValue = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;attGroup ref="{http://www.iata.org/IATA/2007/00}CurrencyAmountGroup"/>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "")
    public static class ExcessValue {

        @XmlAttribute(name = "Amount")
        protected BigDecimal amount;
        @XmlAttribute(name = "CurrencyCode")
        protected String currencyCode;
        @XmlAttribute(name = "DecimalPlaces")
        @XmlSchemaType(name = "nonNegativeInteger")
        protected BigInteger decimalPlaces;

        /**
         * Gets the value of the amount property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getAmount() {
            return amount;
        }

        /**
         * Sets the value of the amount property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setAmount(BigDecimal value) {
            this.amount = value;
        }

        /**
         * Gets the value of the currencyCode property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getCurrencyCode() {
            return currencyCode;
        }

        /**
         * Sets the value of the currencyCode property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setCurrencyCode(String value) {
            this.currencyCode = value;
        }

        /**
         * Gets the value of the decimalPlaces property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getDecimalPlaces() {
            return decimalPlaces;
        }

        /**
         * Sets the value of the decimalPlaces property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setDecimalPlaces(BigInteger value) {
            this.decimalPlaces = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="Male" type="{http://sita.aero/wtr/common/3/0}NumericLength2" minOccurs="0"/>
     *         &lt;element name="Female" type="{http://sita.aero/wtr/common/3/0}NumericLength2" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "male",
        "female"
    })
    public static class ToiletKits {

        @XmlElement(name = "Male")
        protected Short male;
        @XmlElement(name = "Female")
        protected Short female;

        /**
         * Gets the value of the male property.
         * 
         * @return
         *     possible object is
         *     {@link Short }
         *     
         */
        public Short getMale() {
            return male;
        }

        /**
         * Sets the value of the male property.
         * 
         * @param value
         *     allowed object is
         *     {@link Short }
         *     
         */
        public void setMale(Short value) {
            this.male = value;
        }

        /**
         * Gets the value of the female property.
         * 
         * @return
         *     possible object is
         *     {@link Short }
         *     
         */
        public Short getFemale() {
            return female;
        }

        /**
         * Sets the value of the female property.
         * 
         * @param value
         *     allowed object is
         *     {@link Short }
         *     
         */
        public void setFemale(Short value) {
            this.female = value;
        }

    }

}

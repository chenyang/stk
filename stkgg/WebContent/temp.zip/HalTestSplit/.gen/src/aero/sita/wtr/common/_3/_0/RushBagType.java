
package aero.sita.wtr.common._3._0;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for RushBagType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="RushBagType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="RushBagTag" type="{http://sita.aero/wtr/common/3/0}BagTagType" minOccurs="0"/>
 *         &lt;element name="OriginalBagTag" type="{http://sita.aero/wtr/common/3/0}BagTagType" minOccurs="0"/>
 *         &lt;element name="ColorTypeDesc" type="{http://sita.aero/wtr/common/3/0}ColorTypeDescType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RushBagType", propOrder = {
    "rushBagTag",
    "originalBagTag",
    "colorTypeDesc"
})
public class RushBagType {

    @XmlElement(name = "RushBagTag")
    protected BagTagType rushBagTag;
    @XmlElement(name = "OriginalBagTag")
    protected BagTagType originalBagTag;
    @XmlElement(name = "ColorTypeDesc")
    protected ColorTypeDescType colorTypeDesc;

    /**
     * Gets the value of the rushBagTag property.
     * 
     * @return
     *     possible object is
     *     {@link BagTagType }
     *     
     */
    public BagTagType getRushBagTag() {
        return rushBagTag;
    }

    /**
     * Sets the value of the rushBagTag property.
     * 
     * @param value
     *     allowed object is
     *     {@link BagTagType }
     *     
     */
    public void setRushBagTag(BagTagType value) {
        this.rushBagTag = value;
    }

    /**
     * Gets the value of the originalBagTag property.
     * 
     * @return
     *     possible object is
     *     {@link BagTagType }
     *     
     */
    public BagTagType getOriginalBagTag() {
        return originalBagTag;
    }

    /**
     * Sets the value of the originalBagTag property.
     * 
     * @param value
     *     allowed object is
     *     {@link BagTagType }
     *     
     */
    public void setOriginalBagTag(BagTagType value) {
        this.originalBagTag = value;
    }

    /**
     * Gets the value of the colorTypeDesc property.
     * 
     * @return
     *     possible object is
     *     {@link ColorTypeDescType }
     *     
     */
    public ColorTypeDescType getColorTypeDesc() {
        return colorTypeDesc;
    }

    /**
     * Sets the value of the colorTypeDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link ColorTypeDescType }
     *     
     */
    public void setColorTypeDesc(ColorTypeDescType value) {
        this.colorTypeDesc = value;
    }

}

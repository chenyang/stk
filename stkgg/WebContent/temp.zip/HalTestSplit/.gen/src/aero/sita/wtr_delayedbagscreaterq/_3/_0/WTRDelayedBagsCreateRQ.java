
package aero.sita.wtr_delayedbagscreaterq._3._0;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import javax.xml.datatype.XMLGregorianCalendar;
import aero.sita.wtr.common._3._0.AdditionalInfoType;
import aero.sita.wtr.common._3._0.DelayedBagGroupType;
import aero.sita.wtr.common._3._0.DelayedClaimType;
import aero.sita.wtr.common._3._0.HandledAirlineCopyIndType;
import aero.sita.wtr.common._3._0.PassengerItineraryType;
import aero.sita.wtr.common._3._0.RecordIdentifierType;
import aero.sita.wtr.common._3._0.StationAirlineType;
import aero.sita.wtr.common._3._0.TracingOptionType;
import org.iata.iata._2007._00.POSType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="POS" type="{http://www.iata.org/IATA/2007/00}POS_Type"/>
 *         &lt;element name="RefStationAirline" type="{http://sita.aero/wtr/common/3/0}StationAirlineType"/>
 *         &lt;element name="TracingOption" type="{http://sita.aero/wtr/common/3/0}TracingOptionType" minOccurs="0"/>
 *         &lt;element name="DelayedBagGroup" type="{http://sita.aero/wtr/common/3/0}DelayedBagGroupType"/>
 *         &lt;element name="Passengers" type="{http://sita.aero/wtr/common/3/0}PassengerItineraryType"/>
 *         &lt;element name="CrossReferenceRecords" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="CrossReferenceRecord" type="{http://sita.aero/wtr/common/3/0}RecordIdentifierType" maxOccurs="5"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="CrossReferenceRecord" type="{http://sita.aero/wtr/common/3/0}RecordIdentifierType" minOccurs="0"/>
 *         &lt;element name="HandledAirlineCopyInd" type="{http://sita.aero/wtr/common/3/0}HandledAirlineCopyIndType" minOccurs="0"/>
 *         &lt;element name="DesignatedLocator" type="{http://sita.aero/wtr/common/3/0}StringLength4to12" minOccurs="0"/>
 *         &lt;element name="AdditionalInfo" type="{http://sita.aero/wtr/common/3/0}AdditionalInfoType" minOccurs="0"/>
 *         &lt;element name="MatchInfo" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="Text" type="{http://sita.aero/wtr/common/3/0}StringLength1to2000" maxOccurs="20"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="Claim" type="{http://sita.aero/wtr/common/3/0}DelayedClaimType" minOccurs="0"/>
 *         &lt;element name="TeletypeAddresses" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="TeletypeAddress" type="{http://www.iata.org/IATA/2007/00}TTY_Address" maxOccurs="10"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="AgentID" type="{http://sita.aero/wtr/common/3/0}StringLength1to12"/>
 *       &lt;/sequence>
 *       &lt;attGroup ref="{http://www.iata.org/IATA/2007/00}IATA_PayloadStdAttributes"/>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "pos",
    "refStationAirline",
    "tracingOption",
    "delayedBagGroup",
    "passengers",
    "crossReferenceRecords",
    "crossReferenceRecord",
    "handledAirlineCopyInd",
    "designatedLocator",
    "additionalInfo",
    "matchInfo",
    "claim",
    "teletypeAddresses",
    "agentID"
})
@XmlRootElement(name = "WTR_DelayedBagsCreateRQ")
public class WTRDelayedBagsCreateRQ {

    @XmlElement(name = "POS", required = true)
    protected POSType pos;
    @XmlElement(name = "RefStationAirline", required = true)
    protected StationAirlineType refStationAirline;
    @XmlElement(name = "TracingOption")
    protected TracingOptionType tracingOption;
    @XmlElement(name = "DelayedBagGroup", required = true)
    protected DelayedBagGroupType delayedBagGroup;
    @XmlElement(name = "Passengers", required = true)
    protected PassengerItineraryType passengers;
    @XmlElement(name = "CrossReferenceRecords")
    protected WTRDelayedBagsCreateRQ.CrossReferenceRecords crossReferenceRecords;
    @XmlElement(name = "CrossReferenceRecord")
    protected RecordIdentifierType crossReferenceRecord;
    @XmlElement(name = "HandledAirlineCopyInd")
    protected HandledAirlineCopyIndType handledAirlineCopyInd;
    @XmlElement(name = "DesignatedLocator")
    protected String designatedLocator;
    @XmlElement(name = "AdditionalInfo")
    protected AdditionalInfoType additionalInfo;
    @XmlElement(name = "MatchInfo")
    protected WTRDelayedBagsCreateRQ.MatchInfo matchInfo;
    @XmlElement(name = "Claim")
    protected DelayedClaimType claim;
    @XmlElement(name = "TeletypeAddresses")
    protected WTRDelayedBagsCreateRQ.TeletypeAddresses teletypeAddresses;
    @XmlElement(name = "AgentID", required = true)
    protected String agentID;
    @XmlAttribute(name = "EchoToken")
    protected String echoToken;
    @XmlAttribute(name = "TimeStamp")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar timeStamp;
    @XmlAttribute(name = "Target")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String target;
    @XmlAttribute(name = "Version", required = true)
    protected BigDecimal version;
    @XmlAttribute(name = "TransactionIdentifier")
    protected String transactionIdentifier;
    @XmlAttribute(name = "SequenceNmbr")
    @XmlSchemaType(name = "nonNegativeInteger")
    protected BigInteger sequenceNmbr;
    @XmlAttribute(name = "TransactionStatusCode")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String transactionStatusCode;
    @XmlAttribute(name = "RetransmissionIndicator")
    protected Boolean retransmissionIndicator;
    @XmlAttribute(name = "AltLangID")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "language")
    protected String altLangID;
    @XmlAttribute(name = "PrimaryLangID")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "language")
    protected String primaryLangID;

    /**
     * Gets the value of the pos property.
     * 
     * @return
     *     possible object is
     *     {@link POSType }
     *     
     */
    public POSType getPOS() {
        return pos;
    }

    /**
     * Sets the value of the pos property.
     * 
     * @param value
     *     allowed object is
     *     {@link POSType }
     *     
     */
    public void setPOS(POSType value) {
        this.pos = value;
    }

    /**
     * Gets the value of the refStationAirline property.
     * 
     * @return
     *     possible object is
     *     {@link StationAirlineType }
     *     
     */
    public StationAirlineType getRefStationAirline() {
        return refStationAirline;
    }

    /**
     * Sets the value of the refStationAirline property.
     * 
     * @param value
     *     allowed object is
     *     {@link StationAirlineType }
     *     
     */
    public void setRefStationAirline(StationAirlineType value) {
        this.refStationAirline = value;
    }

    /**
     * Gets the value of the tracingOption property.
     * 
     * @return
     *     possible object is
     *     {@link TracingOptionType }
     *     
     */
    public TracingOptionType getTracingOption() {
        return tracingOption;
    }

    /**
     * Sets the value of the tracingOption property.
     * 
     * @param value
     *     allowed object is
     *     {@link TracingOptionType }
     *     
     */
    public void setTracingOption(TracingOptionType value) {
        this.tracingOption = value;
    }

    /**
     * Gets the value of the delayedBagGroup property.
     * 
     * @return
     *     possible object is
     *     {@link DelayedBagGroupType }
     *     
     */
    public DelayedBagGroupType getDelayedBagGroup() {
        return delayedBagGroup;
    }

    /**
     * Sets the value of the delayedBagGroup property.
     * 
     * @param value
     *     allowed object is
     *     {@link DelayedBagGroupType }
     *     
     */
    public void setDelayedBagGroup(DelayedBagGroupType value) {
        this.delayedBagGroup = value;
    }

    /**
     * Gets the value of the passengers property.
     * 
     * @return
     *     possible object is
     *     {@link PassengerItineraryType }
     *     
     */
    public PassengerItineraryType getPassengers() {
        return passengers;
    }

    /**
     * Sets the value of the passengers property.
     * 
     * @param value
     *     allowed object is
     *     {@link PassengerItineraryType }
     *     
     */
    public void setPassengers(PassengerItineraryType value) {
        this.passengers = value;
    }

    /**
     * Gets the value of the crossReferenceRecords property.
     * 
     * @return
     *     possible object is
     *     {@link WTRDelayedBagsCreateRQ.CrossReferenceRecords }
     *     
     */
    public WTRDelayedBagsCreateRQ.CrossReferenceRecords getCrossReferenceRecords() {
        return crossReferenceRecords;
    }

    /**
     * Sets the value of the crossReferenceRecords property.
     * 
     * @param value
     *     allowed object is
     *     {@link WTRDelayedBagsCreateRQ.CrossReferenceRecords }
     *     
     */
    public void setCrossReferenceRecords(WTRDelayedBagsCreateRQ.CrossReferenceRecords value) {
        this.crossReferenceRecords = value;
    }

    /**
     * Gets the value of the crossReferenceRecord property.
     * 
     * @return
     *     possible object is
     *     {@link RecordIdentifierType }
     *     
     */
    public RecordIdentifierType getCrossReferenceRecord() {
        return crossReferenceRecord;
    }

    /**
     * Sets the value of the crossReferenceRecord property.
     * 
     * @param value
     *     allowed object is
     *     {@link RecordIdentifierType }
     *     
     */
    public void setCrossReferenceRecord(RecordIdentifierType value) {
        this.crossReferenceRecord = value;
    }

    /**
     * Gets the value of the handledAirlineCopyInd property.
     * 
     * @return
     *     possible object is
     *     {@link HandledAirlineCopyIndType }
     *     
     */
    public HandledAirlineCopyIndType getHandledAirlineCopyInd() {
        return handledAirlineCopyInd;
    }

    /**
     * Sets the value of the handledAirlineCopyInd property.
     * 
     * @param value
     *     allowed object is
     *     {@link HandledAirlineCopyIndType }
     *     
     */
    public void setHandledAirlineCopyInd(HandledAirlineCopyIndType value) {
        this.handledAirlineCopyInd = value;
    }

    /**
     * Gets the value of the designatedLocator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDesignatedLocator() {
        return designatedLocator;
    }

    /**
     * Sets the value of the designatedLocator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDesignatedLocator(String value) {
        this.designatedLocator = value;
    }

    /**
     * Gets the value of the additionalInfo property.
     * 
     * @return
     *     possible object is
     *     {@link AdditionalInfoType }
     *     
     */
    public AdditionalInfoType getAdditionalInfo() {
        return additionalInfo;
    }

    /**
     * Sets the value of the additionalInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link AdditionalInfoType }
     *     
     */
    public void setAdditionalInfo(AdditionalInfoType value) {
        this.additionalInfo = value;
    }

    /**
     * Gets the value of the matchInfo property.
     * 
     * @return
     *     possible object is
     *     {@link WTRDelayedBagsCreateRQ.MatchInfo }
     *     
     */
    public WTRDelayedBagsCreateRQ.MatchInfo getMatchInfo() {
        return matchInfo;
    }

    /**
     * Sets the value of the matchInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link WTRDelayedBagsCreateRQ.MatchInfo }
     *     
     */
    public void setMatchInfo(WTRDelayedBagsCreateRQ.MatchInfo value) {
        this.matchInfo = value;
    }

    /**
     * Gets the value of the claim property.
     * 
     * @return
     *     possible object is
     *     {@link DelayedClaimType }
     *     
     */
    public DelayedClaimType getClaim() {
        return claim;
    }

    /**
     * Sets the value of the claim property.
     * 
     * @param value
     *     allowed object is
     *     {@link DelayedClaimType }
     *     
     */
    public void setClaim(DelayedClaimType value) {
        this.claim = value;
    }

    /**
     * Gets the value of the teletypeAddresses property.
     * 
     * @return
     *     possible object is
     *     {@link WTRDelayedBagsCreateRQ.TeletypeAddresses }
     *     
     */
    public WTRDelayedBagsCreateRQ.TeletypeAddresses getTeletypeAddresses() {
        return teletypeAddresses;
    }

    /**
     * Sets the value of the teletypeAddresses property.
     * 
     * @param value
     *     allowed object is
     *     {@link WTRDelayedBagsCreateRQ.TeletypeAddresses }
     *     
     */
    public void setTeletypeAddresses(WTRDelayedBagsCreateRQ.TeletypeAddresses value) {
        this.teletypeAddresses = value;
    }

    /**
     * Gets the value of the agentID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAgentID() {
        return agentID;
    }

    /**
     * Sets the value of the agentID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAgentID(String value) {
        this.agentID = value;
    }

    /**
     * Gets the value of the echoToken property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEchoToken() {
        return echoToken;
    }

    /**
     * Sets the value of the echoToken property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEchoToken(String value) {
        this.echoToken = value;
    }

    /**
     * Gets the value of the timeStamp property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getTimeStamp() {
        return timeStamp;
    }

    /**
     * Sets the value of the timeStamp property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setTimeStamp(XMLGregorianCalendar value) {
        this.timeStamp = value;
    }

    /**
     * Gets the value of the target property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTarget() {
        if (target == null) {
            return "Production";
        } else {
            return target;
        }
    }

    /**
     * Sets the value of the target property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTarget(String value) {
        this.target = value;
    }

    /**
     * Gets the value of the version property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getVersion() {
        return version;
    }

    /**
     * Sets the value of the version property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setVersion(BigDecimal value) {
        this.version = value;
    }

    /**
     * Gets the value of the transactionIdentifier property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransactionIdentifier() {
        return transactionIdentifier;
    }

    /**
     * Sets the value of the transactionIdentifier property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransactionIdentifier(String value) {
        this.transactionIdentifier = value;
    }

    /**
     * Gets the value of the sequenceNmbr property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getSequenceNmbr() {
        return sequenceNmbr;
    }

    /**
     * Sets the value of the sequenceNmbr property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setSequenceNmbr(BigInteger value) {
        this.sequenceNmbr = value;
    }

    /**
     * Gets the value of the transactionStatusCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransactionStatusCode() {
        return transactionStatusCode;
    }

    /**
     * Sets the value of the transactionStatusCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransactionStatusCode(String value) {
        this.transactionStatusCode = value;
    }

    /**
     * Gets the value of the retransmissionIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isRetransmissionIndicator() {
        return retransmissionIndicator;
    }

    /**
     * Sets the value of the retransmissionIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setRetransmissionIndicator(Boolean value) {
        this.retransmissionIndicator = value;
    }

    /**
     * Gets the value of the altLangID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAltLangID() {
        return altLangID;
    }

    /**
     * Sets the value of the altLangID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAltLangID(String value) {
        this.altLangID = value;
    }

    /**
     * Gets the value of the primaryLangID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPrimaryLangID() {
        return primaryLangID;
    }

    /**
     * Sets the value of the primaryLangID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPrimaryLangID(String value) {
        this.primaryLangID = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="CrossReferenceRecord" type="{http://sita.aero/wtr/common/3/0}RecordIdentifierType" maxOccurs="5"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "crossReferenceRecord"
    })
    public static class CrossReferenceRecords {

        @XmlElement(name = "CrossReferenceRecord", required = true)
        protected List<RecordIdentifierType> crossReferenceRecord;

        /**
         * Gets the value of the crossReferenceRecord property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the crossReferenceRecord property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getCrossReferenceRecord().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link RecordIdentifierType }
         * 
         * 
         */
        public List<RecordIdentifierType> getCrossReferenceRecord() {
            if (crossReferenceRecord == null) {
                crossReferenceRecord = new ArrayList<RecordIdentifierType>();
            }
            return this.crossReferenceRecord;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="Text" type="{http://sita.aero/wtr/common/3/0}StringLength1to2000" maxOccurs="20"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "text"
    })
    public static class MatchInfo {

        @XmlElement(name = "Text", required = true)
        protected List<String> text;

        /**
         * Gets the value of the text property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the text property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getText().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getText() {
            if (text == null) {
                text = new ArrayList<String>();
            }
            return this.text;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="TeletypeAddress" type="{http://www.iata.org/IATA/2007/00}TTY_Address" maxOccurs="10"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "teletypeAddress"
    })
    public static class TeletypeAddresses {

        @XmlElement(name = "TeletypeAddress", required = true)
        protected List<String> teletypeAddress;

        /**
         * Gets the value of the teletypeAddress property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the teletypeAddress property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getTeletypeAddress().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getTeletypeAddress() {
            if (teletypeAddress == null) {
                teletypeAddress = new ArrayList<String>();
            }
            return this.teletypeAddress;
        }

    }

}

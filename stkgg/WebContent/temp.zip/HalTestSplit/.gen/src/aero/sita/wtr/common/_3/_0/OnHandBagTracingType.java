
package aero.sita.wtr.common._3._0;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for OnHandBagTracingType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="OnHandBagTracingType">
 *   &lt;complexContent>
 *     &lt;extension base="{http://sita.aero/wtr/common/3/0}OnHandBagType">
 *       &lt;sequence>
 *         &lt;element name="NewFlights" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="FlightDateOrARNK" type="{http://sita.aero/wtr/common/3/0}FlightDateOrARNKType" maxOccurs="5" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="NewRouting" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="Route" type="{http://www.iata.org/IATA/2007/00}StationType" maxOccurs="5"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "OnHandBagTracingType", propOrder = {
    "newFlights",
    "newRouting"
})
public class OnHandBagTracingType
    extends OnHandBagType
{

    @XmlElement(name = "NewFlights")
    protected OnHandBagTracingType.NewFlights newFlights;
    @XmlElement(name = "NewRouting")
    protected OnHandBagTracingType.NewRouting newRouting;

    /**
     * Gets the value of the newFlights property.
     * 
     * @return
     *     possible object is
     *     {@link OnHandBagTracingType.NewFlights }
     *     
     */
    public OnHandBagTracingType.NewFlights getNewFlights() {
        return newFlights;
    }

    /**
     * Sets the value of the newFlights property.
     * 
     * @param value
     *     allowed object is
     *     {@link OnHandBagTracingType.NewFlights }
     *     
     */
    public void setNewFlights(OnHandBagTracingType.NewFlights value) {
        this.newFlights = value;
    }

    /**
     * Gets the value of the newRouting property.
     * 
     * @return
     *     possible object is
     *     {@link OnHandBagTracingType.NewRouting }
     *     
     */
    public OnHandBagTracingType.NewRouting getNewRouting() {
        return newRouting;
    }

    /**
     * Sets the value of the newRouting property.
     * 
     * @param value
     *     allowed object is
     *     {@link OnHandBagTracingType.NewRouting }
     *     
     */
    public void setNewRouting(OnHandBagTracingType.NewRouting value) {
        this.newRouting = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="FlightDateOrARNK" type="{http://sita.aero/wtr/common/3/0}FlightDateOrARNKType" maxOccurs="5" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "flightDateOrARNK"
    })
    public static class NewFlights {

        @XmlElement(name = "FlightDateOrARNK")
        protected List<FlightDateOrARNKType> flightDateOrARNK;

        /**
         * Gets the value of the flightDateOrARNK property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the flightDateOrARNK property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getFlightDateOrARNK().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link FlightDateOrARNKType }
         * 
         * 
         */
        public List<FlightDateOrARNKType> getFlightDateOrARNK() {
            if (flightDateOrARNK == null) {
                flightDateOrARNK = new ArrayList<FlightDateOrARNKType>();
            }
            return this.flightDateOrARNK;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="Route" type="{http://www.iata.org/IATA/2007/00}StationType" maxOccurs="5"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "route"
    })
    public static class NewRouting {

        @XmlElement(name = "Route", required = true)
        protected List<String> route;

        /**
         * Gets the value of the route property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the route property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getRoute().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getRoute() {
            if (route == null) {
                route = new ArrayList<String>();
            }
            return this.route;
        }

    }

}

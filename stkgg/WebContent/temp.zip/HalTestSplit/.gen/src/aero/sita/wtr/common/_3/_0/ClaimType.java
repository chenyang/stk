
package aero.sita.wtr.common._3._0;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * Contains the claim data
 * 
 * <p>Java class for ClaimType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ClaimType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ClaimAmout" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;choice>
 *                   &lt;element name="Unknown" type="{http://sita.aero/wtr/common/3/0}EmptyType"/>
 *                   &lt;element name="Amount">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;attGroup ref="{http://www.iata.org/IATA/2007/00}CurrencyAmountGroup"/>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                 &lt;/choice>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="CostRemarks" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="TextLine" type="{http://sita.aero/wtr/common/3/0}StringLength1to58" maxOccurs="5"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="PassengerPayments" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="PassengerPayment" type="{http://sita.aero/wtr/common/3/0}PassengerPaymentType" maxOccurs="5"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="ClaimDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="DateNotified" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="QuestionnaireDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="FaultStationCode" type="{http://www.iata.org/IATA/2007/00}StationType" minOccurs="0"/>
 *         &lt;element name="FaultTerminal" type="{http://sita.aero/wtr/common/3/0}AlphaNumericStringLength1to2" minOccurs="0"/>
 *         &lt;element name="Insurance" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;attribute name="Value" type="{http://sita.aero/wtr/common/3/0}YesNoType" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="LiabilityTag" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;attribute name="Value" type="{http://sita.aero/wtr/common/3/0}YesNoType" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="MissingBags" type="{http://sita.aero/wtr/common/3/0}NumericLength2" minOccurs="0"/>
 *         &lt;element name="PartnerCode" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;choice>
 *                   &lt;element name="CarrierCode">
 *                     &lt;simpleType>
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                         &lt;pattern value="[a-zA-Z0-9]{2,3}"/>
 *                       &lt;/restriction>
 *                     &lt;/simpleType>
 *                   &lt;/element>
 *                   &lt;element name="None" type="{http://sita.aero/wtr/common/3/0}EmptyType"/>
 *                 &lt;/choice>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="LossComments" type="{http://sita.aero/wtr/common/3/0}StringLength1to58" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ClaimType", propOrder = {
    "claimAmout",
    "costRemarks",
    "passengerPayments",
    "claimDate",
    "dateNotified",
    "questionnaireDate",
    "faultStationCode",
    "faultTerminal",
    "insurance",
    "liabilityTag",
    "missingBags",
    "partnerCode",
    "lossComments"
})
@XmlSeeAlso({
    DamageClaimType.class,
    DelayedClaimType.class
})
public class ClaimType {

    @XmlElement(name = "ClaimAmout")
    protected ClaimType.ClaimAmout claimAmout;
    @XmlElement(name = "CostRemarks")
    protected ClaimType.CostRemarks costRemarks;
    @XmlElement(name = "PassengerPayments")
    protected ClaimType.PassengerPayments passengerPayments;
    @XmlElement(name = "ClaimDate")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar claimDate;
    @XmlElement(name = "DateNotified")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateNotified;
    @XmlElement(name = "QuestionnaireDate")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar questionnaireDate;
    @XmlElement(name = "FaultStationCode")
    protected String faultStationCode;
    @XmlElement(name = "FaultTerminal")
    protected String faultTerminal;
    @XmlElement(name = "Insurance")
    protected ClaimType.Insurance insurance;
    @XmlElement(name = "LiabilityTag")
    protected ClaimType.LiabilityTag liabilityTag;
    @XmlElement(name = "MissingBags")
    protected Short missingBags;
    @XmlElement(name = "PartnerCode")
    protected ClaimType.PartnerCode partnerCode;
    @XmlElement(name = "LossComments")
    protected String lossComments;

    /**
     * Gets the value of the claimAmout property.
     * 
     * @return
     *     possible object is
     *     {@link ClaimType.ClaimAmout }
     *     
     */
    public ClaimType.ClaimAmout getClaimAmout() {
        return claimAmout;
    }

    /**
     * Sets the value of the claimAmout property.
     * 
     * @param value
     *     allowed object is
     *     {@link ClaimType.ClaimAmout }
     *     
     */
    public void setClaimAmout(ClaimType.ClaimAmout value) {
        this.claimAmout = value;
    }

    /**
     * Gets the value of the costRemarks property.
     * 
     * @return
     *     possible object is
     *     {@link ClaimType.CostRemarks }
     *     
     */
    public ClaimType.CostRemarks getCostRemarks() {
        return costRemarks;
    }

    /**
     * Sets the value of the costRemarks property.
     * 
     * @param value
     *     allowed object is
     *     {@link ClaimType.CostRemarks }
     *     
     */
    public void setCostRemarks(ClaimType.CostRemarks value) {
        this.costRemarks = value;
    }

    /**
     * Gets the value of the passengerPayments property.
     * 
     * @return
     *     possible object is
     *     {@link ClaimType.PassengerPayments }
     *     
     */
    public ClaimType.PassengerPayments getPassengerPayments() {
        return passengerPayments;
    }

    /**
     * Sets the value of the passengerPayments property.
     * 
     * @param value
     *     allowed object is
     *     {@link ClaimType.PassengerPayments }
     *     
     */
    public void setPassengerPayments(ClaimType.PassengerPayments value) {
        this.passengerPayments = value;
    }

    /**
     * Gets the value of the claimDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getClaimDate() {
        return claimDate;
    }

    /**
     * Sets the value of the claimDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setClaimDate(XMLGregorianCalendar value) {
        this.claimDate = value;
    }

    /**
     * Gets the value of the dateNotified property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateNotified() {
        return dateNotified;
    }

    /**
     * Sets the value of the dateNotified property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateNotified(XMLGregorianCalendar value) {
        this.dateNotified = value;
    }

    /**
     * Gets the value of the questionnaireDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getQuestionnaireDate() {
        return questionnaireDate;
    }

    /**
     * Sets the value of the questionnaireDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setQuestionnaireDate(XMLGregorianCalendar value) {
        this.questionnaireDate = value;
    }

    /**
     * Gets the value of the faultStationCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFaultStationCode() {
        return faultStationCode;
    }

    /**
     * Sets the value of the faultStationCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFaultStationCode(String value) {
        this.faultStationCode = value;
    }

    /**
     * Gets the value of the faultTerminal property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFaultTerminal() {
        return faultTerminal;
    }

    /**
     * Sets the value of the faultTerminal property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFaultTerminal(String value) {
        this.faultTerminal = value;
    }

    /**
     * Gets the value of the insurance property.
     * 
     * @return
     *     possible object is
     *     {@link ClaimType.Insurance }
     *     
     */
    public ClaimType.Insurance getInsurance() {
        return insurance;
    }

    /**
     * Sets the value of the insurance property.
     * 
     * @param value
     *     allowed object is
     *     {@link ClaimType.Insurance }
     *     
     */
    public void setInsurance(ClaimType.Insurance value) {
        this.insurance = value;
    }

    /**
     * Gets the value of the liabilityTag property.
     * 
     * @return
     *     possible object is
     *     {@link ClaimType.LiabilityTag }
     *     
     */
    public ClaimType.LiabilityTag getLiabilityTag() {
        return liabilityTag;
    }

    /**
     * Sets the value of the liabilityTag property.
     * 
     * @param value
     *     allowed object is
     *     {@link ClaimType.LiabilityTag }
     *     
     */
    public void setLiabilityTag(ClaimType.LiabilityTag value) {
        this.liabilityTag = value;
    }

    /**
     * Gets the value of the missingBags property.
     * 
     * @return
     *     possible object is
     *     {@link Short }
     *     
     */
    public Short getMissingBags() {
        return missingBags;
    }

    /**
     * Sets the value of the missingBags property.
     * 
     * @param value
     *     allowed object is
     *     {@link Short }
     *     
     */
    public void setMissingBags(Short value) {
        this.missingBags = value;
    }

    /**
     * Gets the value of the partnerCode property.
     * 
     * @return
     *     possible object is
     *     {@link ClaimType.PartnerCode }
     *     
     */
    public ClaimType.PartnerCode getPartnerCode() {
        return partnerCode;
    }

    /**
     * Sets the value of the partnerCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link ClaimType.PartnerCode }
     *     
     */
    public void setPartnerCode(ClaimType.PartnerCode value) {
        this.partnerCode = value;
    }

    /**
     * Gets the value of the lossComments property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLossComments() {
        return lossComments;
    }

    /**
     * Sets the value of the lossComments property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLossComments(String value) {
        this.lossComments = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;choice>
     *         &lt;element name="Unknown" type="{http://sita.aero/wtr/common/3/0}EmptyType"/>
     *         &lt;element name="Amount">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;attGroup ref="{http://www.iata.org/IATA/2007/00}CurrencyAmountGroup"/>
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *       &lt;/choice>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "unknown",
        "amount"
    })
    public static class ClaimAmout {

        @XmlElement(name = "Unknown")
        protected EmptyType unknown;
        @XmlElement(name = "Amount")
        protected ClaimType.ClaimAmout.Amount amount;

        /**
         * Gets the value of the unknown property.
         * 
         * @return
         *     possible object is
         *     {@link EmptyType }
         *     
         */
        public EmptyType getUnknown() {
            return unknown;
        }

        /**
         * Sets the value of the unknown property.
         * 
         * @param value
         *     allowed object is
         *     {@link EmptyType }
         *     
         */
        public void setUnknown(EmptyType value) {
            this.unknown = value;
        }

        /**
         * Gets the value of the amount property.
         * 
         * @return
         *     possible object is
         *     {@link ClaimType.ClaimAmout.Amount }
         *     
         */
        public ClaimType.ClaimAmout.Amount getAmount() {
            return amount;
        }

        /**
         * Sets the value of the amount property.
         * 
         * @param value
         *     allowed object is
         *     {@link ClaimType.ClaimAmout.Amount }
         *     
         */
        public void setAmount(ClaimType.ClaimAmout.Amount value) {
            this.amount = value;
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;attGroup ref="{http://www.iata.org/IATA/2007/00}CurrencyAmountGroup"/>
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "")
        public static class Amount {

            @XmlAttribute(name = "Amount")
            protected BigDecimal amount;
            @XmlAttribute(name = "CurrencyCode")
            protected String currencyCode;
            @XmlAttribute(name = "DecimalPlaces")
            @XmlSchemaType(name = "nonNegativeInteger")
            protected BigInteger decimalPlaces;

            /**
             * Gets the value of the amount property.
             * 
             * @return
             *     possible object is
             *     {@link BigDecimal }
             *     
             */
            public BigDecimal getAmount() {
                return amount;
            }

            /**
             * Sets the value of the amount property.
             * 
             * @param value
             *     allowed object is
             *     {@link BigDecimal }
             *     
             */
            public void setAmount(BigDecimal value) {
                this.amount = value;
            }

            /**
             * Gets the value of the currencyCode property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getCurrencyCode() {
                return currencyCode;
            }

            /**
             * Sets the value of the currencyCode property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setCurrencyCode(String value) {
                this.currencyCode = value;
            }

            /**
             * Gets the value of the decimalPlaces property.
             * 
             * @return
             *     possible object is
             *     {@link BigInteger }
             *     
             */
            public BigInteger getDecimalPlaces() {
                return decimalPlaces;
            }

            /**
             * Sets the value of the decimalPlaces property.
             * 
             * @param value
             *     allowed object is
             *     {@link BigInteger }
             *     
             */
            public void setDecimalPlaces(BigInteger value) {
                this.decimalPlaces = value;
            }

        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="TextLine" type="{http://sita.aero/wtr/common/3/0}StringLength1to58" maxOccurs="5"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "textLine"
    })
    public static class CostRemarks {

        @XmlElement(name = "TextLine", required = true)
        protected List<String> textLine;

        /**
         * Gets the value of the textLine property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the textLine property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getTextLine().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getTextLine() {
            if (textLine == null) {
                textLine = new ArrayList<String>();
            }
            return this.textLine;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;attribute name="Value" type="{http://sita.aero/wtr/common/3/0}YesNoType" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "")
    public static class Insurance {

        @XmlAttribute(name = "Value")
        protected YesNoType value;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link YesNoType }
         *     
         */
        public YesNoType getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link YesNoType }
         *     
         */
        public void setValue(YesNoType value) {
            this.value = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;attribute name="Value" type="{http://sita.aero/wtr/common/3/0}YesNoType" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "")
    public static class LiabilityTag {

        @XmlAttribute(name = "Value")
        protected YesNoType value;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link YesNoType }
         *     
         */
        public YesNoType getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link YesNoType }
         *     
         */
        public void setValue(YesNoType value) {
            this.value = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;choice>
     *         &lt;element name="CarrierCode">
     *           &lt;simpleType>
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *               &lt;pattern value="[a-zA-Z0-9]{2,3}"/>
     *             &lt;/restriction>
     *           &lt;/simpleType>
     *         &lt;/element>
     *         &lt;element name="None" type="{http://sita.aero/wtr/common/3/0}EmptyType"/>
     *       &lt;/choice>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "carrierCode",
        "none"
    })
    public static class PartnerCode {

        @XmlElement(name = "CarrierCode")
        protected String carrierCode;
        @XmlElement(name = "None")
        protected EmptyType none;

        /**
         * Gets the value of the carrierCode property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getCarrierCode() {
            return carrierCode;
        }

        /**
         * Sets the value of the carrierCode property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setCarrierCode(String value) {
            this.carrierCode = value;
        }

        /**
         * Gets the value of the none property.
         * 
         * @return
         *     possible object is
         *     {@link EmptyType }
         *     
         */
        public EmptyType getNone() {
            return none;
        }

        /**
         * Sets the value of the none property.
         * 
         * @param value
         *     allowed object is
         *     {@link EmptyType }
         *     
         */
        public void setNone(EmptyType value) {
            this.none = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="PassengerPayment" type="{http://sita.aero/wtr/common/3/0}PassengerPaymentType" maxOccurs="5"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "passengerPayment"
    })
    public static class PassengerPayments {

        @XmlElement(name = "PassengerPayment", required = true)
        protected List<PassengerPaymentType> passengerPayment;

        /**
         * Gets the value of the passengerPayment property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the passengerPayment property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getPassengerPayment().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link PassengerPaymentType }
         * 
         * 
         */
        public List<PassengerPaymentType> getPassengerPayment() {
            if (passengerPayment == null) {
                passengerPayment = new ArrayList<PassengerPaymentType>();
            }
            return this.passengerPayment;
        }

    }

}

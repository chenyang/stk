
package aero.sita.wtr.common._3._0;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for BagAmendType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BagAmendType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ColorTypeDesc" type="{http://sita.aero/wtr/common/3/0}ColorTypeDescAmendType" minOccurs="0"/>
 *         &lt;element name="BagTag" type="{http://sita.aero/wtr/common/3/0}BagTagAmendType" minOccurs="0"/>
 *         &lt;element name="BrandInfo" minOccurs="0">
 *           &lt;complexType>
 *             &lt;simpleContent>
 *               &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>StringLength0to58">
 *                 &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
 *               &lt;/extension>
 *             &lt;/simpleContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="BagDelivery" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="BagReceivedDate" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;simpleContent>
 *                         &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema>dateTime">
 *                           &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
 *                         &lt;/extension>
 *                       &lt;/simpleContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                   &lt;element name="BagReceived" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;extension base="{http://sita.aero/wtr/common/3/0}BagReceivedType">
 *                           &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
 *                         &lt;/extension>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                   &lt;element name="Status" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="OutForDelivery" minOccurs="0">
 *                               &lt;complexType>
 *                                 &lt;simpleContent>
 *                                   &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>StringLength0to58">
 *                                     &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
 *                                   &lt;/extension>
 *                                 &lt;/simpleContent>
 *                               &lt;/complexType>
 *                             &lt;/element>
 *                             &lt;element name="Delivered" minOccurs="0">
 *                               &lt;complexType>
 *                                 &lt;simpleContent>
 *                                   &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>StringLength0to58">
 *                                     &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
 *                                   &lt;/extension>
 *                                 &lt;/simpleContent>
 *                               &lt;/complexType>
 *                             &lt;/element>
 *                             &lt;element name="UnableToDeliver" minOccurs="0">
 *                               &lt;complexType>
 *                                 &lt;simpleContent>
 *                                   &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>StringLength0to58">
 *                                     &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
 *                                   &lt;/extension>
 *                                 &lt;/simpleContent>
 *                               &lt;/complexType>
 *                             &lt;/element>
 *                             &lt;element name="TrackingUpdate" minOccurs="0">
 *                               &lt;complexType>
 *                                 &lt;simpleContent>
 *                                   &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>StringLength0to58">
 *                                     &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
 *                                   &lt;/extension>
 *                                 &lt;/simpleContent>
 *                               &lt;/complexType>
 *                             &lt;/element>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                   &lt;element name="DeliveredTime" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;simpleContent>
 *                         &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema>dateTime">
 *                           &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
 *                         &lt;/extension>
 *                       &lt;/simpleContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="LockCode" minOccurs="0">
 *           &lt;complexType>
 *             &lt;simpleContent>
 *               &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>AlphaNumericStringLength0to6">
 *                 &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
 *               &lt;/extension>
 *             &lt;/simpleContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="UniqueID" minOccurs="0">
 *           &lt;complexType>
 *             &lt;simpleContent>
 *               &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>UniqueIDType">
 *                 &lt;attribute name="Suspended" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *                 &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
 *               &lt;/extension>
 *             &lt;/simpleContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="BagSentToCustoms" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;extension base="{http://sita.aero/wtr/common/3/0}CustomsDate">
 *                 &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
 *               &lt;/extension>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="BagReceivedFromCustoms" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;extension base="{http://sita.aero/wtr/common/3/0}CustomsDate">
 *                 &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
 *               &lt;/extension>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="StorageLocation" minOccurs="0">
 *           &lt;complexType>
 *             &lt;simpleContent>
 *               &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>StringLength0to32">
 *                 &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
 *               &lt;/extension>
 *             &lt;/simpleContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BagAmendType", propOrder = {
    "colorTypeDesc",
    "bagTag",
    "brandInfo",
    "bagDelivery",
    "lockCode",
    "uniqueID",
    "bagSentToCustoms",
    "bagReceivedFromCustoms",
    "storageLocation"
})
@XmlSeeAlso({
    DelayedBagAmendType.class,
    DamagedBagAmendType.class,
    OnHandBagAmendType.class
})
public class BagAmendType {

    @XmlElement(name = "ColorTypeDesc")
    protected ColorTypeDescAmendType colorTypeDesc;
    @XmlElement(name = "BagTag")
    protected BagTagAmendType bagTag;
    @XmlElement(name = "BrandInfo")
    protected BagAmendType.BrandInfo brandInfo;
    @XmlElement(name = "BagDelivery")
    protected BagAmendType.BagDelivery bagDelivery;
    @XmlElement(name = "LockCode")
    protected BagAmendType.LockCode lockCode;
    @XmlElement(name = "UniqueID")
    protected BagAmendType.UniqueID uniqueID;
    @XmlElement(name = "BagSentToCustoms")
    protected BagAmendType.BagSentToCustoms bagSentToCustoms;
    @XmlElement(name = "BagReceivedFromCustoms")
    protected BagAmendType.BagReceivedFromCustoms bagReceivedFromCustoms;
    @XmlElement(name = "StorageLocation")
    protected BagAmendType.StorageLocation storageLocation;

    /**
     * Gets the value of the colorTypeDesc property.
     * 
     * @return
     *     possible object is
     *     {@link ColorTypeDescAmendType }
     *     
     */
    public ColorTypeDescAmendType getColorTypeDesc() {
        return colorTypeDesc;
    }

    /**
     * Sets the value of the colorTypeDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link ColorTypeDescAmendType }
     *     
     */
    public void setColorTypeDesc(ColorTypeDescAmendType value) {
        this.colorTypeDesc = value;
    }

    /**
     * Gets the value of the bagTag property.
     * 
     * @return
     *     possible object is
     *     {@link BagTagAmendType }
     *     
     */
    public BagTagAmendType getBagTag() {
        return bagTag;
    }

    /**
     * Sets the value of the bagTag property.
     * 
     * @param value
     *     allowed object is
     *     {@link BagTagAmendType }
     *     
     */
    public void setBagTag(BagTagAmendType value) {
        this.bagTag = value;
    }

    /**
     * Gets the value of the brandInfo property.
     * 
     * @return
     *     possible object is
     *     {@link BagAmendType.BrandInfo }
     *     
     */
    public BagAmendType.BrandInfo getBrandInfo() {
        return brandInfo;
    }

    /**
     * Sets the value of the brandInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link BagAmendType.BrandInfo }
     *     
     */
    public void setBrandInfo(BagAmendType.BrandInfo value) {
        this.brandInfo = value;
    }

    /**
     * Gets the value of the bagDelivery property.
     * 
     * @return
     *     possible object is
     *     {@link BagAmendType.BagDelivery }
     *     
     */
    public BagAmendType.BagDelivery getBagDelivery() {
        return bagDelivery;
    }

    /**
     * Sets the value of the bagDelivery property.
     * 
     * @param value
     *     allowed object is
     *     {@link BagAmendType.BagDelivery }
     *     
     */
    public void setBagDelivery(BagAmendType.BagDelivery value) {
        this.bagDelivery = value;
    }

    /**
     * Gets the value of the lockCode property.
     * 
     * @return
     *     possible object is
     *     {@link BagAmendType.LockCode }
     *     
     */
    public BagAmendType.LockCode getLockCode() {
        return lockCode;
    }

    /**
     * Sets the value of the lockCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link BagAmendType.LockCode }
     *     
     */
    public void setLockCode(BagAmendType.LockCode value) {
        this.lockCode = value;
    }

    /**
     * Gets the value of the uniqueID property.
     * 
     * @return
     *     possible object is
     *     {@link BagAmendType.UniqueID }
     *     
     */
    public BagAmendType.UniqueID getUniqueID() {
        return uniqueID;
    }

    /**
     * Sets the value of the uniqueID property.
     * 
     * @param value
     *     allowed object is
     *     {@link BagAmendType.UniqueID }
     *     
     */
    public void setUniqueID(BagAmendType.UniqueID value) {
        this.uniqueID = value;
    }

    /**
     * Gets the value of the bagSentToCustoms property.
     * 
     * @return
     *     possible object is
     *     {@link BagAmendType.BagSentToCustoms }
     *     
     */
    public BagAmendType.BagSentToCustoms getBagSentToCustoms() {
        return bagSentToCustoms;
    }

    /**
     * Sets the value of the bagSentToCustoms property.
     * 
     * @param value
     *     allowed object is
     *     {@link BagAmendType.BagSentToCustoms }
     *     
     */
    public void setBagSentToCustoms(BagAmendType.BagSentToCustoms value) {
        this.bagSentToCustoms = value;
    }

    /**
     * Gets the value of the bagReceivedFromCustoms property.
     * 
     * @return
     *     possible object is
     *     {@link BagAmendType.BagReceivedFromCustoms }
     *     
     */
    public BagAmendType.BagReceivedFromCustoms getBagReceivedFromCustoms() {
        return bagReceivedFromCustoms;
    }

    /**
     * Sets the value of the bagReceivedFromCustoms property.
     * 
     * @param value
     *     allowed object is
     *     {@link BagAmendType.BagReceivedFromCustoms }
     *     
     */
    public void setBagReceivedFromCustoms(BagAmendType.BagReceivedFromCustoms value) {
        this.bagReceivedFromCustoms = value;
    }

    /**
     * Gets the value of the storageLocation property.
     * 
     * @return
     *     possible object is
     *     {@link BagAmendType.StorageLocation }
     *     
     */
    public BagAmendType.StorageLocation getStorageLocation() {
        return storageLocation;
    }

    /**
     * Sets the value of the storageLocation property.
     * 
     * @param value
     *     allowed object is
     *     {@link BagAmendType.StorageLocation }
     *     
     */
    public void setStorageLocation(BagAmendType.StorageLocation value) {
        this.storageLocation = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="BagReceivedDate" minOccurs="0">
     *           &lt;complexType>
     *             &lt;simpleContent>
     *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema>dateTime">
     *                 &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
     *               &lt;/extension>
     *             &lt;/simpleContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *         &lt;element name="BagReceived" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;extension base="{http://sita.aero/wtr/common/3/0}BagReceivedType">
     *                 &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
     *               &lt;/extension>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *         &lt;element name="Status" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="OutForDelivery" minOccurs="0">
     *                     &lt;complexType>
     *                       &lt;simpleContent>
     *                         &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>StringLength0to58">
     *                           &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
     *                         &lt;/extension>
     *                       &lt;/simpleContent>
     *                     &lt;/complexType>
     *                   &lt;/element>
     *                   &lt;element name="Delivered" minOccurs="0">
     *                     &lt;complexType>
     *                       &lt;simpleContent>
     *                         &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>StringLength0to58">
     *                           &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
     *                         &lt;/extension>
     *                       &lt;/simpleContent>
     *                     &lt;/complexType>
     *                   &lt;/element>
     *                   &lt;element name="UnableToDeliver" minOccurs="0">
     *                     &lt;complexType>
     *                       &lt;simpleContent>
     *                         &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>StringLength0to58">
     *                           &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
     *                         &lt;/extension>
     *                       &lt;/simpleContent>
     *                     &lt;/complexType>
     *                   &lt;/element>
     *                   &lt;element name="TrackingUpdate" minOccurs="0">
     *                     &lt;complexType>
     *                       &lt;simpleContent>
     *                         &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>StringLength0to58">
     *                           &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
     *                         &lt;/extension>
     *                       &lt;/simpleContent>
     *                     &lt;/complexType>
     *                   &lt;/element>
     *                 &lt;/sequence>
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *         &lt;element name="DeliveredTime" minOccurs="0">
     *           &lt;complexType>
     *             &lt;simpleContent>
     *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema>dateTime">
     *                 &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
     *               &lt;/extension>
     *             &lt;/simpleContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "bagReceivedDate",
        "bagReceived",
        "status",
        "deliveredTime"
    })
    public static class BagDelivery {

        @XmlElement(name = "BagReceivedDate")
        protected BagAmendType.BagDelivery.BagReceivedDate bagReceivedDate;
        @XmlElement(name = "BagReceived")
        protected BagAmendType.BagDelivery.BagReceived bagReceived;
        @XmlElement(name = "Status")
        protected BagAmendType.BagDelivery.Status status;
        @XmlElement(name = "DeliveredTime")
        protected BagAmendType.BagDelivery.DeliveredTime deliveredTime;

        /**
         * Gets the value of the bagReceivedDate property.
         * 
         * @return
         *     possible object is
         *     {@link BagAmendType.BagDelivery.BagReceivedDate }
         *     
         */
        public BagAmendType.BagDelivery.BagReceivedDate getBagReceivedDate() {
            return bagReceivedDate;
        }

        /**
         * Sets the value of the bagReceivedDate property.
         * 
         * @param value
         *     allowed object is
         *     {@link BagAmendType.BagDelivery.BagReceivedDate }
         *     
         */
        public void setBagReceivedDate(BagAmendType.BagDelivery.BagReceivedDate value) {
            this.bagReceivedDate = value;
        }

        /**
         * Gets the value of the bagReceived property.
         * 
         * @return
         *     possible object is
         *     {@link BagAmendType.BagDelivery.BagReceived }
         *     
         */
        public BagAmendType.BagDelivery.BagReceived getBagReceived() {
            return bagReceived;
        }

        /**
         * Sets the value of the bagReceived property.
         * 
         * @param value
         *     allowed object is
         *     {@link BagAmendType.BagDelivery.BagReceived }
         *     
         */
        public void setBagReceived(BagAmendType.BagDelivery.BagReceived value) {
            this.bagReceived = value;
        }

        /**
         * Gets the value of the status property.
         * 
         * @return
         *     possible object is
         *     {@link BagAmendType.BagDelivery.Status }
         *     
         */
        public BagAmendType.BagDelivery.Status getStatus() {
            return status;
        }

        /**
         * Sets the value of the status property.
         * 
         * @param value
         *     allowed object is
         *     {@link BagAmendType.BagDelivery.Status }
         *     
         */
        public void setStatus(BagAmendType.BagDelivery.Status value) {
            this.status = value;
        }

        /**
         * Gets the value of the deliveredTime property.
         * 
         * @return
         *     possible object is
         *     {@link BagAmendType.BagDelivery.DeliveredTime }
         *     
         */
        public BagAmendType.BagDelivery.DeliveredTime getDeliveredTime() {
            return deliveredTime;
        }

        /**
         * Sets the value of the deliveredTime property.
         * 
         * @param value
         *     allowed object is
         *     {@link BagAmendType.BagDelivery.DeliveredTime }
         *     
         */
        public void setDeliveredTime(BagAmendType.BagDelivery.DeliveredTime value) {
            this.deliveredTime = value;
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;extension base="{http://sita.aero/wtr/common/3/0}BagReceivedType">
         *       &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
         *     &lt;/extension>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "")
        public static class BagReceived
            extends BagReceivedType
        {

            @XmlAttribute(name = "Delete")
            protected Boolean delete;

            /**
             * Gets the value of the delete property.
             * 
             * @return
             *     possible object is
             *     {@link Boolean }
             *     
             */
            public boolean isDelete() {
                if (delete == null) {
                    return false;
                } else {
                    return delete;
                }
            }

            /**
             * Sets the value of the delete property.
             * 
             * @param value
             *     allowed object is
             *     {@link Boolean }
             *     
             */
            public void setDelete(Boolean value) {
                this.delete = value;
            }

        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;simpleContent>
         *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema>dateTime">
         *       &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
         *     &lt;/extension>
         *   &lt;/simpleContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "value"
        })
        public static class BagReceivedDate {

            @XmlValue
            @XmlSchemaType(name = "dateTime")
            protected XMLGregorianCalendar value;
            @XmlAttribute(name = "Delete")
            protected Boolean delete;

            /**
             * Gets the value of the value property.
             * 
             * @return
             *     possible object is
             *     {@link XMLGregorianCalendar }
             *     
             */
            public XMLGregorianCalendar getValue() {
                return value;
            }

            /**
             * Sets the value of the value property.
             * 
             * @param value
             *     allowed object is
             *     {@link XMLGregorianCalendar }
             *     
             */
            public void setValue(XMLGregorianCalendar value) {
                this.value = value;
            }

            /**
             * Gets the value of the delete property.
             * 
             * @return
             *     possible object is
             *     {@link Boolean }
             *     
             */
            public boolean isDelete() {
                if (delete == null) {
                    return false;
                } else {
                    return delete;
                }
            }

            /**
             * Sets the value of the delete property.
             * 
             * @param value
             *     allowed object is
             *     {@link Boolean }
             *     
             */
            public void setDelete(Boolean value) {
                this.delete = value;
            }

        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;simpleContent>
         *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema>dateTime">
         *       &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
         *     &lt;/extension>
         *   &lt;/simpleContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "value"
        })
        public static class DeliveredTime {

            @XmlValue
            @XmlSchemaType(name = "dateTime")
            protected XMLGregorianCalendar value;
            @XmlAttribute(name = "Delete")
            protected Boolean delete;

            /**
             * Gets the value of the value property.
             * 
             * @return
             *     possible object is
             *     {@link XMLGregorianCalendar }
             *     
             */
            public XMLGregorianCalendar getValue() {
                return value;
            }

            /**
             * Sets the value of the value property.
             * 
             * @param value
             *     allowed object is
             *     {@link XMLGregorianCalendar }
             *     
             */
            public void setValue(XMLGregorianCalendar value) {
                this.value = value;
            }

            /**
             * Gets the value of the delete property.
             * 
             * @return
             *     possible object is
             *     {@link Boolean }
             *     
             */
            public boolean isDelete() {
                if (delete == null) {
                    return false;
                } else {
                    return delete;
                }
            }

            /**
             * Sets the value of the delete property.
             * 
             * @param value
             *     allowed object is
             *     {@link Boolean }
             *     
             */
            public void setDelete(Boolean value) {
                this.delete = value;
            }

        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="OutForDelivery" minOccurs="0">
         *           &lt;complexType>
         *             &lt;simpleContent>
         *               &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>StringLength0to58">
         *                 &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
         *               &lt;/extension>
         *             &lt;/simpleContent>
         *           &lt;/complexType>
         *         &lt;/element>
         *         &lt;element name="Delivered" minOccurs="0">
         *           &lt;complexType>
         *             &lt;simpleContent>
         *               &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>StringLength0to58">
         *                 &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
         *               &lt;/extension>
         *             &lt;/simpleContent>
         *           &lt;/complexType>
         *         &lt;/element>
         *         &lt;element name="UnableToDeliver" minOccurs="0">
         *           &lt;complexType>
         *             &lt;simpleContent>
         *               &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>StringLength0to58">
         *                 &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
         *               &lt;/extension>
         *             &lt;/simpleContent>
         *           &lt;/complexType>
         *         &lt;/element>
         *         &lt;element name="TrackingUpdate" minOccurs="0">
         *           &lt;complexType>
         *             &lt;simpleContent>
         *               &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>StringLength0to58">
         *                 &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
         *               &lt;/extension>
         *             &lt;/simpleContent>
         *           &lt;/complexType>
         *         &lt;/element>
         *       &lt;/sequence>
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "outForDelivery",
            "delivered",
            "unableToDeliver",
            "trackingUpdate"
        })
        public static class Status {

            @XmlElement(name = "OutForDelivery")
            protected BagAmendType.BagDelivery.Status.OutForDelivery outForDelivery;
            @XmlElement(name = "Delivered")
            protected BagAmendType.BagDelivery.Status.Delivered delivered;
            @XmlElement(name = "UnableToDeliver")
            protected BagAmendType.BagDelivery.Status.UnableToDeliver unableToDeliver;
            @XmlElement(name = "TrackingUpdate")
            protected BagAmendType.BagDelivery.Status.TrackingUpdate trackingUpdate;

            /**
             * Gets the value of the outForDelivery property.
             * 
             * @return
             *     possible object is
             *     {@link BagAmendType.BagDelivery.Status.OutForDelivery }
             *     
             */
            public BagAmendType.BagDelivery.Status.OutForDelivery getOutForDelivery() {
                return outForDelivery;
            }

            /**
             * Sets the value of the outForDelivery property.
             * 
             * @param value
             *     allowed object is
             *     {@link BagAmendType.BagDelivery.Status.OutForDelivery }
             *     
             */
            public void setOutForDelivery(BagAmendType.BagDelivery.Status.OutForDelivery value) {
                this.outForDelivery = value;
            }

            /**
             * Gets the value of the delivered property.
             * 
             * @return
             *     possible object is
             *     {@link BagAmendType.BagDelivery.Status.Delivered }
             *     
             */
            public BagAmendType.BagDelivery.Status.Delivered getDelivered() {
                return delivered;
            }

            /**
             * Sets the value of the delivered property.
             * 
             * @param value
             *     allowed object is
             *     {@link BagAmendType.BagDelivery.Status.Delivered }
             *     
             */
            public void setDelivered(BagAmendType.BagDelivery.Status.Delivered value) {
                this.delivered = value;
            }

            /**
             * Gets the value of the unableToDeliver property.
             * 
             * @return
             *     possible object is
             *     {@link BagAmendType.BagDelivery.Status.UnableToDeliver }
             *     
             */
            public BagAmendType.BagDelivery.Status.UnableToDeliver getUnableToDeliver() {
                return unableToDeliver;
            }

            /**
             * Sets the value of the unableToDeliver property.
             * 
             * @param value
             *     allowed object is
             *     {@link BagAmendType.BagDelivery.Status.UnableToDeliver }
             *     
             */
            public void setUnableToDeliver(BagAmendType.BagDelivery.Status.UnableToDeliver value) {
                this.unableToDeliver = value;
            }

            /**
             * Gets the value of the trackingUpdate property.
             * 
             * @return
             *     possible object is
             *     {@link BagAmendType.BagDelivery.Status.TrackingUpdate }
             *     
             */
            public BagAmendType.BagDelivery.Status.TrackingUpdate getTrackingUpdate() {
                return trackingUpdate;
            }

            /**
             * Sets the value of the trackingUpdate property.
             * 
             * @param value
             *     allowed object is
             *     {@link BagAmendType.BagDelivery.Status.TrackingUpdate }
             *     
             */
            public void setTrackingUpdate(BagAmendType.BagDelivery.Status.TrackingUpdate value) {
                this.trackingUpdate = value;
            }


            /**
             * <p>Java class for anonymous complex type.
             * 
             * <p>The following schema fragment specifies the expected content contained within this class.
             * 
             * <pre>
             * &lt;complexType>
             *   &lt;simpleContent>
             *     &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>StringLength0to58">
             *       &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
             *     &lt;/extension>
             *   &lt;/simpleContent>
             * &lt;/complexType>
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "value"
            })
            public static class Delivered {

                @XmlValue
                protected String value;
                @XmlAttribute(name = "Delete")
                protected Boolean delete;

                /**
                 * Used for Character Strings, length 0 to 58
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getValue() {
                    return value;
                }

                /**
                 * Sets the value of the value property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setValue(String value) {
                    this.value = value;
                }

                /**
                 * Gets the value of the delete property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link Boolean }
                 *     
                 */
                public boolean isDelete() {
                    if (delete == null) {
                        return false;
                    } else {
                        return delete;
                    }
                }

                /**
                 * Sets the value of the delete property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link Boolean }
                 *     
                 */
                public void setDelete(Boolean value) {
                    this.delete = value;
                }

            }


            /**
             * <p>Java class for anonymous complex type.
             * 
             * <p>The following schema fragment specifies the expected content contained within this class.
             * 
             * <pre>
             * &lt;complexType>
             *   &lt;simpleContent>
             *     &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>StringLength0to58">
             *       &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
             *     &lt;/extension>
             *   &lt;/simpleContent>
             * &lt;/complexType>
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "value"
            })
            public static class OutForDelivery {

                @XmlValue
                protected String value;
                @XmlAttribute(name = "Delete")
                protected Boolean delete;

                /**
                 * Used for Character Strings, length 0 to 58
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getValue() {
                    return value;
                }

                /**
                 * Sets the value of the value property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setValue(String value) {
                    this.value = value;
                }

                /**
                 * Gets the value of the delete property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link Boolean }
                 *     
                 */
                public boolean isDelete() {
                    if (delete == null) {
                        return false;
                    } else {
                        return delete;
                    }
                }

                /**
                 * Sets the value of the delete property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link Boolean }
                 *     
                 */
                public void setDelete(Boolean value) {
                    this.delete = value;
                }

            }


            /**
             * <p>Java class for anonymous complex type.
             * 
             * <p>The following schema fragment specifies the expected content contained within this class.
             * 
             * <pre>
             * &lt;complexType>
             *   &lt;simpleContent>
             *     &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>StringLength0to58">
             *       &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
             *     &lt;/extension>
             *   &lt;/simpleContent>
             * &lt;/complexType>
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "value"
            })
            public static class TrackingUpdate {

                @XmlValue
                protected String value;
                @XmlAttribute(name = "Delete")
                protected Boolean delete;

                /**
                 * Used for Character Strings, length 0 to 58
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getValue() {
                    return value;
                }

                /**
                 * Sets the value of the value property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setValue(String value) {
                    this.value = value;
                }

                /**
                 * Gets the value of the delete property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link Boolean }
                 *     
                 */
                public boolean isDelete() {
                    if (delete == null) {
                        return false;
                    } else {
                        return delete;
                    }
                }

                /**
                 * Sets the value of the delete property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link Boolean }
                 *     
                 */
                public void setDelete(Boolean value) {
                    this.delete = value;
                }

            }


            /**
             * <p>Java class for anonymous complex type.
             * 
             * <p>The following schema fragment specifies the expected content contained within this class.
             * 
             * <pre>
             * &lt;complexType>
             *   &lt;simpleContent>
             *     &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>StringLength0to58">
             *       &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
             *     &lt;/extension>
             *   &lt;/simpleContent>
             * &lt;/complexType>
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "value"
            })
            public static class UnableToDeliver {

                @XmlValue
                protected String value;
                @XmlAttribute(name = "Delete")
                protected Boolean delete;

                /**
                 * Used for Character Strings, length 0 to 58
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getValue() {
                    return value;
                }

                /**
                 * Sets the value of the value property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setValue(String value) {
                    this.value = value;
                }

                /**
                 * Gets the value of the delete property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link Boolean }
                 *     
                 */
                public boolean isDelete() {
                    if (delete == null) {
                        return false;
                    } else {
                        return delete;
                    }
                }

                /**
                 * Sets the value of the delete property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link Boolean }
                 *     
                 */
                public void setDelete(Boolean value) {
                    this.delete = value;
                }

            }

        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;extension base="{http://sita.aero/wtr/common/3/0}CustomsDate">
     *       &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
     *     &lt;/extension>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "")
    public static class BagReceivedFromCustoms
        extends CustomsDate
    {

        @XmlAttribute(name = "Delete")
        protected Boolean delete;

        /**
         * Gets the value of the delete property.
         * 
         * @return
         *     possible object is
         *     {@link Boolean }
         *     
         */
        public boolean isDelete() {
            if (delete == null) {
                return false;
            } else {
                return delete;
            }
        }

        /**
         * Sets the value of the delete property.
         * 
         * @param value
         *     allowed object is
         *     {@link Boolean }
         *     
         */
        public void setDelete(Boolean value) {
            this.delete = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;extension base="{http://sita.aero/wtr/common/3/0}CustomsDate">
     *       &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
     *     &lt;/extension>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "")
    public static class BagSentToCustoms
        extends CustomsDate
    {

        @XmlAttribute(name = "Delete")
        protected Boolean delete;

        /**
         * Gets the value of the delete property.
         * 
         * @return
         *     possible object is
         *     {@link Boolean }
         *     
         */
        public boolean isDelete() {
            if (delete == null) {
                return false;
            } else {
                return delete;
            }
        }

        /**
         * Sets the value of the delete property.
         * 
         * @param value
         *     allowed object is
         *     {@link Boolean }
         *     
         */
        public void setDelete(Boolean value) {
            this.delete = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;simpleContent>
     *     &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>StringLength0to58">
     *       &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
     *     &lt;/extension>
     *   &lt;/simpleContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class BrandInfo {

        @XmlValue
        protected String value;
        @XmlAttribute(name = "Delete")
        protected Boolean delete;

        /**
         * Used for Character Strings, length 0 to 58
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setValue(String value) {
            this.value = value;
        }

        /**
         * Gets the value of the delete property.
         * 
         * @return
         *     possible object is
         *     {@link Boolean }
         *     
         */
        public boolean isDelete() {
            if (delete == null) {
                return false;
            } else {
                return delete;
            }
        }

        /**
         * Sets the value of the delete property.
         * 
         * @param value
         *     allowed object is
         *     {@link Boolean }
         *     
         */
        public void setDelete(Boolean value) {
            this.delete = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;simpleContent>
     *     &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>AlphaNumericStringLength0to6">
     *       &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
     *     &lt;/extension>
     *   &lt;/simpleContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class LockCode {

        @XmlValue
        protected String value;
        @XmlAttribute(name = "Delete")
        protected Boolean delete;

        /**
         * Used for Alpha Numeric Strings, length 0 and 6
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setValue(String value) {
            this.value = value;
        }

        /**
         * Gets the value of the delete property.
         * 
         * @return
         *     possible object is
         *     {@link Boolean }
         *     
         */
        public boolean isDelete() {
            if (delete == null) {
                return false;
            } else {
                return delete;
            }
        }

        /**
         * Sets the value of the delete property.
         * 
         * @param value
         *     allowed object is
         *     {@link Boolean }
         *     
         */
        public void setDelete(Boolean value) {
            this.delete = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;simpleContent>
     *     &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>StringLength0to32">
     *       &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
     *     &lt;/extension>
     *   &lt;/simpleContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class StorageLocation {

        @XmlValue
        protected String value;
        @XmlAttribute(name = "Delete")
        protected Boolean delete;

        /**
         * Used for Character Strings, length 0 to 32
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setValue(String value) {
            this.value = value;
        }

        /**
         * Gets the value of the delete property.
         * 
         * @return
         *     possible object is
         *     {@link Boolean }
         *     
         */
        public boolean isDelete() {
            if (delete == null) {
                return false;
            } else {
                return delete;
            }
        }

        /**
         * Sets the value of the delete property.
         * 
         * @param value
         *     allowed object is
         *     {@link Boolean }
         *     
         */
        public void setDelete(Boolean value) {
            this.delete = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;simpleContent>
     *     &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>UniqueIDType">
     *       &lt;attribute name="Suspended" type="{http://www.w3.org/2001/XMLSchema}boolean" />
     *       &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
     *     &lt;/extension>
     *   &lt;/simpleContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class UniqueID {

        @XmlValue
        protected String value;
        @XmlAttribute(name = "Suspended")
        protected Boolean suspended;
        @XmlAttribute(name = "Delete")
        protected Boolean delete;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setValue(String value) {
            this.value = value;
        }

        /**
         * Gets the value of the suspended property.
         * 
         * @return
         *     possible object is
         *     {@link Boolean }
         *     
         */
        public Boolean isSuspended() {
            return suspended;
        }

        /**
         * Sets the value of the suspended property.
         * 
         * @param value
         *     allowed object is
         *     {@link Boolean }
         *     
         */
        public void setSuspended(Boolean value) {
            this.suspended = value;
        }

        /**
         * Gets the value of the delete property.
         * 
         * @return
         *     possible object is
         *     {@link Boolean }
         *     
         */
        public boolean isDelete() {
            if (delete == null) {
                return false;
            } else {
                return delete;
            }
        }

        /**
         * Sets the value of the delete property.
         * 
         * @param value
         *     allowed object is
         *     {@link Boolean }
         *     
         */
        public void setDelete(Boolean value) {
            this.delete = value;
        }

    }

}

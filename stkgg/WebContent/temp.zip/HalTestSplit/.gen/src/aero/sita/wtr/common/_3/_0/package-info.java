@javax.xml.bind.annotation.XmlSchema(namespace = "http://sita.aero/wtr/common/3/0", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package aero.sita.wtr.common._3._0;


package aero.sita.wtr.common._3._0;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;


/**
 * <p>Java class for DelayedBagGroupAmendType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DelayedBagGroupAmendType">
 *   &lt;complexContent>
 *     &lt;extension base="{http://sita.aero/wtr/common/3/0}BagGroupAmendType">
 *       &lt;sequence>
 *         &lt;element name="DelayedBags" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="DelayedBag" maxOccurs="10" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;extension base="{http://sita.aero/wtr/common/3/0}DelayedBagAmendType">
 *                           &lt;attribute name="Seq" use="required" type="{http://www.w3.org/2001/XMLSchema}int" />
 *                         &lt;/extension>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="BagLastSeen" minOccurs="0">
 *           &lt;complexType>
 *             &lt;simpleContent>
 *               &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>AlphaLength0to4">
 *                 &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
 *               &lt;/extension>
 *             &lt;/simpleContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="BaggageItinerary" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence minOccurs="0">
 *                   &lt;element name="FlightDateOrARNK" type="{http://sita.aero/wtr/common/3/0}FlightDateOrARNKType" maxOccurs="5"/>
 *                 &lt;/sequence>
 *                 &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="ExcessBaggage" minOccurs="0">
 *           &lt;complexType>
 *             &lt;simpleContent>
 *               &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>AlphaNumericStringLength0to15">
 *                 &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
 *               &lt;/extension>
 *             &lt;/simpleContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="BagTagDestinations" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence minOccurs="0">
 *                   &lt;element name="Station" type="{http://www.iata.org/IATA/2007/00}StationType" maxOccurs="2"/>
 *                 &lt;/sequence>
 *                 &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="KeysCollected" minOccurs="0">
 *           &lt;complexType>
 *             &lt;simpleContent>
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema>boolean">
 *                 &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
 *               &lt;/extension>
 *             &lt;/simpleContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="MissingWeight" minOccurs="0">
 *           &lt;complexType>
 *             &lt;simpleContent>
 *               &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>StringLength0to9">
 *                 &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
 *               &lt;/extension>
 *             &lt;/simpleContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="MatchWindow" minOccurs="0">
 *           &lt;complexType>
 *             &lt;simpleContent>
 *               &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>NumericLength2">
 *                 &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
 *               &lt;/extension>
 *             &lt;/simpleContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DelayedBagGroupAmendType", propOrder = {
    "delayedBags",
    "bagLastSeen",
    "baggageItinerary",
    "excessBaggage",
    "bagTagDestinations",
    "keysCollected",
    "missingWeight",
    "matchWindow"
})
public class DelayedBagGroupAmendType
    extends BagGroupAmendType
{

    @XmlElement(name = "DelayedBags")
    protected DelayedBagGroupAmendType.DelayedBags delayedBags;
    @XmlElement(name = "BagLastSeen")
    protected DelayedBagGroupAmendType.BagLastSeen bagLastSeen;
    @XmlElement(name = "BaggageItinerary")
    protected DelayedBagGroupAmendType.BaggageItinerary baggageItinerary;
    @XmlElement(name = "ExcessBaggage")
    protected DelayedBagGroupAmendType.ExcessBaggage excessBaggage;
    @XmlElement(name = "BagTagDestinations")
    protected DelayedBagGroupAmendType.BagTagDestinations bagTagDestinations;
    @XmlElement(name = "KeysCollected")
    protected DelayedBagGroupAmendType.KeysCollected keysCollected;
    @XmlElement(name = "MissingWeight")
    protected DelayedBagGroupAmendType.MissingWeight missingWeight;
    @XmlElement(name = "MatchWindow")
    protected DelayedBagGroupAmendType.MatchWindow matchWindow;

    /**
     * Gets the value of the delayedBags property.
     * 
     * @return
     *     possible object is
     *     {@link DelayedBagGroupAmendType.DelayedBags }
     *     
     */
    public DelayedBagGroupAmendType.DelayedBags getDelayedBags() {
        return delayedBags;
    }

    /**
     * Sets the value of the delayedBags property.
     * 
     * @param value
     *     allowed object is
     *     {@link DelayedBagGroupAmendType.DelayedBags }
     *     
     */
    public void setDelayedBags(DelayedBagGroupAmendType.DelayedBags value) {
        this.delayedBags = value;
    }

    /**
     * Gets the value of the bagLastSeen property.
     * 
     * @return
     *     possible object is
     *     {@link DelayedBagGroupAmendType.BagLastSeen }
     *     
     */
    public DelayedBagGroupAmendType.BagLastSeen getBagLastSeen() {
        return bagLastSeen;
    }

    /**
     * Sets the value of the bagLastSeen property.
     * 
     * @param value
     *     allowed object is
     *     {@link DelayedBagGroupAmendType.BagLastSeen }
     *     
     */
    public void setBagLastSeen(DelayedBagGroupAmendType.BagLastSeen value) {
        this.bagLastSeen = value;
    }

    /**
     * Gets the value of the baggageItinerary property.
     * 
     * @return
     *     possible object is
     *     {@link DelayedBagGroupAmendType.BaggageItinerary }
     *     
     */
    public DelayedBagGroupAmendType.BaggageItinerary getBaggageItinerary() {
        return baggageItinerary;
    }

    /**
     * Sets the value of the baggageItinerary property.
     * 
     * @param value
     *     allowed object is
     *     {@link DelayedBagGroupAmendType.BaggageItinerary }
     *     
     */
    public void setBaggageItinerary(DelayedBagGroupAmendType.BaggageItinerary value) {
        this.baggageItinerary = value;
    }

    /**
     * Gets the value of the excessBaggage property.
     * 
     * @return
     *     possible object is
     *     {@link DelayedBagGroupAmendType.ExcessBaggage }
     *     
     */
    public DelayedBagGroupAmendType.ExcessBaggage getExcessBaggage() {
        return excessBaggage;
    }

    /**
     * Sets the value of the excessBaggage property.
     * 
     * @param value
     *     allowed object is
     *     {@link DelayedBagGroupAmendType.ExcessBaggage }
     *     
     */
    public void setExcessBaggage(DelayedBagGroupAmendType.ExcessBaggage value) {
        this.excessBaggage = value;
    }

    /**
     * Gets the value of the bagTagDestinations property.
     * 
     * @return
     *     possible object is
     *     {@link DelayedBagGroupAmendType.BagTagDestinations }
     *     
     */
    public DelayedBagGroupAmendType.BagTagDestinations getBagTagDestinations() {
        return bagTagDestinations;
    }

    /**
     * Sets the value of the bagTagDestinations property.
     * 
     * @param value
     *     allowed object is
     *     {@link DelayedBagGroupAmendType.BagTagDestinations }
     *     
     */
    public void setBagTagDestinations(DelayedBagGroupAmendType.BagTagDestinations value) {
        this.bagTagDestinations = value;
    }

    /**
     * Gets the value of the keysCollected property.
     * 
     * @return
     *     possible object is
     *     {@link DelayedBagGroupAmendType.KeysCollected }
     *     
     */
    public DelayedBagGroupAmendType.KeysCollected getKeysCollected() {
        return keysCollected;
    }

    /**
     * Sets the value of the keysCollected property.
     * 
     * @param value
     *     allowed object is
     *     {@link DelayedBagGroupAmendType.KeysCollected }
     *     
     */
    public void setKeysCollected(DelayedBagGroupAmendType.KeysCollected value) {
        this.keysCollected = value;
    }

    /**
     * Gets the value of the missingWeight property.
     * 
     * @return
     *     possible object is
     *     {@link DelayedBagGroupAmendType.MissingWeight }
     *     
     */
    public DelayedBagGroupAmendType.MissingWeight getMissingWeight() {
        return missingWeight;
    }

    /**
     * Sets the value of the missingWeight property.
     * 
     * @param value
     *     allowed object is
     *     {@link DelayedBagGroupAmendType.MissingWeight }
     *     
     */
    public void setMissingWeight(DelayedBagGroupAmendType.MissingWeight value) {
        this.missingWeight = value;
    }

    /**
     * Gets the value of the matchWindow property.
     * 
     * @return
     *     possible object is
     *     {@link DelayedBagGroupAmendType.MatchWindow }
     *     
     */
    public DelayedBagGroupAmendType.MatchWindow getMatchWindow() {
        return matchWindow;
    }

    /**
     * Sets the value of the matchWindow property.
     * 
     * @param value
     *     allowed object is
     *     {@link DelayedBagGroupAmendType.MatchWindow }
     *     
     */
    public void setMatchWindow(DelayedBagGroupAmendType.MatchWindow value) {
        this.matchWindow = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;simpleContent>
     *     &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>AlphaLength0to4">
     *       &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
     *     &lt;/extension>
     *   &lt;/simpleContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class BagLastSeen {

        @XmlValue
        protected String value;
        @XmlAttribute(name = "Delete")
        protected Boolean delete;

        /**
         * Used for Character Strings, length 0 to 4
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setValue(String value) {
            this.value = value;
        }

        /**
         * Gets the value of the delete property.
         * 
         * @return
         *     possible object is
         *     {@link Boolean }
         *     
         */
        public boolean isDelete() {
            if (delete == null) {
                return false;
            } else {
                return delete;
            }
        }

        /**
         * Sets the value of the delete property.
         * 
         * @param value
         *     allowed object is
         *     {@link Boolean }
         *     
         */
        public void setDelete(Boolean value) {
            this.delete = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence minOccurs="0">
     *         &lt;element name="Station" type="{http://www.iata.org/IATA/2007/00}StationType" maxOccurs="2"/>
     *       &lt;/sequence>
     *       &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "station"
    })
    public static class BagTagDestinations {

        @XmlElement(name = "Station")
        protected List<String> station;
        @XmlAttribute(name = "Delete")
        protected Boolean delete;

        /**
         * Gets the value of the station property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the station property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getStation().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getStation() {
            if (station == null) {
                station = new ArrayList<String>();
            }
            return this.station;
        }

        /**
         * Gets the value of the delete property.
         * 
         * @return
         *     possible object is
         *     {@link Boolean }
         *     
         */
        public boolean isDelete() {
            if (delete == null) {
                return false;
            } else {
                return delete;
            }
        }

        /**
         * Sets the value of the delete property.
         * 
         * @param value
         *     allowed object is
         *     {@link Boolean }
         *     
         */
        public void setDelete(Boolean value) {
            this.delete = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence minOccurs="0">
     *         &lt;element name="FlightDateOrARNK" type="{http://sita.aero/wtr/common/3/0}FlightDateOrARNKType" maxOccurs="5"/>
     *       &lt;/sequence>
     *       &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "flightDateOrARNK"
    })
    public static class BaggageItinerary {

        @XmlElement(name = "FlightDateOrARNK")
        protected List<FlightDateOrARNKType> flightDateOrARNK;
        @XmlAttribute(name = "Delete")
        protected Boolean delete;

        /**
         * Gets the value of the flightDateOrARNK property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the flightDateOrARNK property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getFlightDateOrARNK().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link FlightDateOrARNKType }
         * 
         * 
         */
        public List<FlightDateOrARNKType> getFlightDateOrARNK() {
            if (flightDateOrARNK == null) {
                flightDateOrARNK = new ArrayList<FlightDateOrARNKType>();
            }
            return this.flightDateOrARNK;
        }

        /**
         * Gets the value of the delete property.
         * 
         * @return
         *     possible object is
         *     {@link Boolean }
         *     
         */
        public boolean isDelete() {
            if (delete == null) {
                return false;
            } else {
                return delete;
            }
        }

        /**
         * Sets the value of the delete property.
         * 
         * @param value
         *     allowed object is
         *     {@link Boolean }
         *     
         */
        public void setDelete(Boolean value) {
            this.delete = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="DelayedBag" maxOccurs="10" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;extension base="{http://sita.aero/wtr/common/3/0}DelayedBagAmendType">
     *                 &lt;attribute name="Seq" use="required" type="{http://www.w3.org/2001/XMLSchema}int" />
     *               &lt;/extension>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "delayedBag"
    })
    public static class DelayedBags {

        @XmlElement(name = "DelayedBag")
        protected List<DelayedBagGroupAmendType.DelayedBags.DelayedBag> delayedBag;

        /**
         * Gets the value of the delayedBag property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the delayedBag property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getDelayedBag().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link DelayedBagGroupAmendType.DelayedBags.DelayedBag }
         * 
         * 
         */
        public List<DelayedBagGroupAmendType.DelayedBags.DelayedBag> getDelayedBag() {
            if (delayedBag == null) {
                delayedBag = new ArrayList<DelayedBagGroupAmendType.DelayedBags.DelayedBag>();
            }
            return this.delayedBag;
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;extension base="{http://sita.aero/wtr/common/3/0}DelayedBagAmendType">
         *       &lt;attribute name="Seq" use="required" type="{http://www.w3.org/2001/XMLSchema}int" />
         *     &lt;/extension>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "")
        public static class DelayedBag
            extends DelayedBagAmendType
        {

            @XmlAttribute(name = "Seq", required = true)
            protected int seq;

            /**
             * Gets the value of the seq property.
             * 
             */
            public int getSeq() {
                return seq;
            }

            /**
             * Sets the value of the seq property.
             * 
             */
            public void setSeq(int value) {
                this.seq = value;
            }

        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;simpleContent>
     *     &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>AlphaNumericStringLength0to15">
     *       &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
     *     &lt;/extension>
     *   &lt;/simpleContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class ExcessBaggage {

        @XmlValue
        protected String value;
        @XmlAttribute(name = "Delete")
        protected Boolean delete;

        /**
         * Used for Alpha Numeric Strings, length 0 and 15
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setValue(String value) {
            this.value = value;
        }

        /**
         * Gets the value of the delete property.
         * 
         * @return
         *     possible object is
         *     {@link Boolean }
         *     
         */
        public boolean isDelete() {
            if (delete == null) {
                return false;
            } else {
                return delete;
            }
        }

        /**
         * Sets the value of the delete property.
         * 
         * @param value
         *     allowed object is
         *     {@link Boolean }
         *     
         */
        public void setDelete(Boolean value) {
            this.delete = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;simpleContent>
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema>boolean">
     *       &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
     *     &lt;/extension>
     *   &lt;/simpleContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class KeysCollected {

        @XmlValue
        protected boolean value;
        @XmlAttribute(name = "Delete")
        protected Boolean delete;

        /**
         * Gets the value of the value property.
         * 
         */
        public boolean isValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         */
        public void setValue(boolean value) {
            this.value = value;
        }

        /**
         * Gets the value of the delete property.
         * 
         * @return
         *     possible object is
         *     {@link Boolean }
         *     
         */
        public boolean isDelete() {
            if (delete == null) {
                return false;
            } else {
                return delete;
            }
        }

        /**
         * Sets the value of the delete property.
         * 
         * @param value
         *     allowed object is
         *     {@link Boolean }
         *     
         */
        public void setDelete(Boolean value) {
            this.delete = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;simpleContent>
     *     &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>NumericLength2">
     *       &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
     *     &lt;/extension>
     *   &lt;/simpleContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class MatchWindow {

        @XmlValue
        protected short value;
        @XmlAttribute(name = "Delete")
        protected Boolean delete;

        /**
         * Contiains a number with up to 2 digits
         * 
         */
        public short getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         */
        public void setValue(short value) {
            this.value = value;
        }

        /**
         * Gets the value of the delete property.
         * 
         * @return
         *     possible object is
         *     {@link Boolean }
         *     
         */
        public boolean isDelete() {
            if (delete == null) {
                return false;
            } else {
                return delete;
            }
        }

        /**
         * Sets the value of the delete property.
         * 
         * @param value
         *     allowed object is
         *     {@link Boolean }
         *     
         */
        public void setDelete(Boolean value) {
            this.delete = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;simpleContent>
     *     &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>StringLength0to9">
     *       &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
     *     &lt;/extension>
     *   &lt;/simpleContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class MissingWeight {

        @XmlValue
        protected String value;
        @XmlAttribute(name = "Delete")
        protected Boolean delete;

        /**
         * Used for Character Strings, length 0 to 9
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setValue(String value) {
            this.value = value;
        }

        /**
         * Gets the value of the delete property.
         * 
         * @return
         *     possible object is
         *     {@link Boolean }
         *     
         */
        public boolean isDelete() {
            if (delete == null) {
                return false;
            } else {
                return delete;
            }
        }

        /**
         * Sets the value of the delete property.
         * 
         * @param value
         *     allowed object is
         *     {@link Boolean }
         *     
         */
        public void setDelete(Boolean value) {
            this.delete = value;
        }

    }

}

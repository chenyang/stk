
package aero.sita.wtr.common._3._0;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for StandardCategoryType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="StandardCategoryType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="ALCOHOL"/>
 *     &lt;enumeration value="ART"/>
 *     &lt;enumeration value="AUDIO"/>
 *     &lt;enumeration value="BOOK"/>
 *     &lt;enumeration value="COAT"/>
 *     &lt;enumeration value="COMPUTER"/>
 *     &lt;enumeration value="COSMETICS"/>
 *     &lt;enumeration value="CURRENCY"/>
 *     &lt;enumeration value="DRESS"/>
 *     &lt;enumeration value="ELECTRIC"/>
 *     &lt;enumeration value="FOOD"/>
 *     &lt;enumeration value="FOOTWEAR"/>
 *     &lt;enumeration value="GIFT"/>
 *     &lt;enumeration value="HAIR"/>
 *     &lt;enumeration value="HANDBAG"/>
 *     &lt;enumeration value="HEADWEAR"/>
 *     &lt;enumeration value="HOUSEHOLD"/>
 *     &lt;enumeration value="INFANT"/>
 *     &lt;enumeration value="JEWELLERY"/>
 *     &lt;enumeration value="LINEN"/>
 *     &lt;enumeration value="MECHANIC"/>
 *     &lt;enumeration value="MEDICAL"/>
 *     &lt;enumeration value="MUSIC"/>
 *     &lt;enumeration value="NATURE"/>
 *     &lt;enumeration value="OPTICS"/>
 *     &lt;enumeration value="PAPERS"/>
 *     &lt;enumeration value="PHOTO"/>
 *     &lt;enumeration value="RELIGIOUS"/>
 *     &lt;enumeration value="SHIRT"/>
 *     &lt;enumeration value="SKIRT"/>
 *     &lt;enumeration value="SLEEPWEAR"/>
 *     &lt;enumeration value="SPORT"/>
 *     &lt;enumeration value="SPORTSWEAR"/>
 *     &lt;enumeration value="SUIT"/>
 *     &lt;enumeration value="SWEATER"/>
 *     &lt;enumeration value="TIMEPIECE"/>
 *     &lt;enumeration value="TOBACCO"/>
 *     &lt;enumeration value="TOOLS"/>
 *     &lt;enumeration value="TOYS"/>
 *     &lt;enumeration value="TROUSERS"/>
 *     &lt;enumeration value="UNIFORM"/>
 *     &lt;enumeration value="VEDIO"/>
 *     &lt;enumeration value="WEAPON"/>
 *     &lt;enumeration value="WEATHER"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "StandardCategoryType")
@XmlEnum
public enum StandardCategoryType {

    ALCOHOL,
    ART,
    AUDIO,
    BOOK,
    COAT,
    COMPUTER,
    COSMETICS,
    CURRENCY,
    DRESS,
    ELECTRIC,
    FOOD,
    FOOTWEAR,
    GIFT,
    HAIR,
    HANDBAG,
    HEADWEAR,
    HOUSEHOLD,
    INFANT,
    JEWELLERY,
    LINEN,
    MECHANIC,
    MEDICAL,
    MUSIC,
    NATURE,
    OPTICS,
    PAPERS,
    PHOTO,
    RELIGIOUS,
    SHIRT,
    SKIRT,
    SLEEPWEAR,
    SPORT,
    SPORTSWEAR,
    SUIT,
    SWEATER,
    TIMEPIECE,
    TOBACCO,
    TOOLS,
    TOYS,
    TROUSERS,
    UNIFORM,
    VEDIO,
    WEAPON,
    WEATHER;

    public String value() {
        return name();
    }

    public static StandardCategoryType fromValue(String v) {
        return valueOf(v);
    }

}

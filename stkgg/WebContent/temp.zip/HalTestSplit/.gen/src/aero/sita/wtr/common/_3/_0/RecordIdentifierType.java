
package aero.sita.wtr.common._3._0;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * This identifies a unique bag record in the WorldTracer System
 * 
 * <p>Java class for RecordIdentifierType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="RecordIdentifierType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="RecordType" type="{http://sita.aero/wtr/common/3/0}RecordType"/>
 *         &lt;element name="RecordReference" type="{http://sita.aero/wtr/common/3/0}RecordReferenceType"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RecordIdentifierType", propOrder = {
    "recordType",
    "recordReference"
})
public class RecordIdentifierType {

    @XmlElement(name = "RecordType", required = true)
    protected RecordType recordType;
    @XmlElement(name = "RecordReference", required = true)
    protected RecordReferenceType recordReference;

    /**
     * Gets the value of the recordType property.
     * 
     * @return
     *     possible object is
     *     {@link RecordType }
     *     
     */
    public RecordType getRecordType() {
        return recordType;
    }

    /**
     * Sets the value of the recordType property.
     * 
     * @param value
     *     allowed object is
     *     {@link RecordType }
     *     
     */
    public void setRecordType(RecordType value) {
        this.recordType = value;
    }

    /**
     * Gets the value of the recordReference property.
     * 
     * @return
     *     possible object is
     *     {@link RecordReferenceType }
     *     
     */
    public RecordReferenceType getRecordReference() {
        return recordReference;
    }

    /**
     * Sets the value of the recordReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link RecordReferenceType }
     *     
     */
    public void setRecordReference(RecordReferenceType value) {
        this.recordReference = value;
    }

}


package aero.sita.wtr.common._3._0;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;


/**
 * <p>Java class for DamagedBagAmendType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DamagedBagAmendType">
 *   &lt;complexContent>
 *     &lt;extension base="{http://sita.aero/wtr/common/3/0}BagAmendType">
 *       &lt;sequence>
 *         &lt;element name="DamageTypes" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="DamageType" type="{http://sita.aero/wtr/common/3/0}DamageTypeType" maxOccurs="2"/>
 *                 &lt;/sequence>
 *                 &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="BagDetails" minOccurs="0">
 *           &lt;complexType>
 *             &lt;simpleContent>
 *               &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>StringLength0to58">
 *                 &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
 *               &lt;/extension>
 *             &lt;/simpleContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DamagedBagAmendType", propOrder = {
    "damageTypes",
    "bagDetails"
})
@XmlSeeAlso({
    aero.sita.wtr.common._3._0.DamagedBagGroupAmendType.DamagedBags.DamagedBag.class
})
public class DamagedBagAmendType
    extends BagAmendType
{

    @XmlElement(name = "DamageTypes")
    protected DamagedBagAmendType.DamageTypes damageTypes;
    @XmlElement(name = "BagDetails")
    protected DamagedBagAmendType.BagDetails bagDetails;

    /**
     * Gets the value of the damageTypes property.
     * 
     * @return
     *     possible object is
     *     {@link DamagedBagAmendType.DamageTypes }
     *     
     */
    public DamagedBagAmendType.DamageTypes getDamageTypes() {
        return damageTypes;
    }

    /**
     * Sets the value of the damageTypes property.
     * 
     * @param value
     *     allowed object is
     *     {@link DamagedBagAmendType.DamageTypes }
     *     
     */
    public void setDamageTypes(DamagedBagAmendType.DamageTypes value) {
        this.damageTypes = value;
    }

    /**
     * Gets the value of the bagDetails property.
     * 
     * @return
     *     possible object is
     *     {@link DamagedBagAmendType.BagDetails }
     *     
     */
    public DamagedBagAmendType.BagDetails getBagDetails() {
        return bagDetails;
    }

    /**
     * Sets the value of the bagDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link DamagedBagAmendType.BagDetails }
     *     
     */
    public void setBagDetails(DamagedBagAmendType.BagDetails value) {
        this.bagDetails = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;simpleContent>
     *     &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>StringLength0to58">
     *       &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
     *     &lt;/extension>
     *   &lt;/simpleContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class BagDetails {

        @XmlValue
        protected String value;
        @XmlAttribute(name = "Delete")
        protected Boolean delete;

        /**
         * Used for Character Strings, length 0 to 58
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setValue(String value) {
            this.value = value;
        }

        /**
         * Gets the value of the delete property.
         * 
         * @return
         *     possible object is
         *     {@link Boolean }
         *     
         */
        public boolean isDelete() {
            if (delete == null) {
                return false;
            } else {
                return delete;
            }
        }

        /**
         * Sets the value of the delete property.
         * 
         * @param value
         *     allowed object is
         *     {@link Boolean }
         *     
         */
        public void setDelete(Boolean value) {
            this.delete = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="DamageType" type="{http://sita.aero/wtr/common/3/0}DamageTypeType" maxOccurs="2"/>
     *       &lt;/sequence>
     *       &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "damageType"
    })
    public static class DamageTypes {

        @XmlElement(name = "DamageType", required = true)
        protected List<DamageTypeType> damageType;
        @XmlAttribute(name = "Delete")
        protected Boolean delete;

        /**
         * Gets the value of the damageType property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the damageType property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getDamageType().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link DamageTypeType }
         * 
         * 
         */
        public List<DamageTypeType> getDamageType() {
            if (damageType == null) {
                damageType = new ArrayList<DamageTypeType>();
            }
            return this.damageType;
        }

        /**
         * Gets the value of the delete property.
         * 
         * @return
         *     possible object is
         *     {@link Boolean }
         *     
         */
        public boolean isDelete() {
            if (delete == null) {
                return false;
            } else {
                return delete;
            }
        }

        /**
         * Sets the value of the delete property.
         * 
         * @param value
         *     allowed object is
         *     {@link Boolean }
         *     
         */
        public void setDelete(Boolean value) {
            this.delete = value;
        }

    }

}

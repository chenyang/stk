
package aero.sita.wtr.common._3._0;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AmendActionType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="AmendActionType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}NMTOKEN">
 *     &lt;enumeration value="AMEND"/>
 *     &lt;enumeration value="SUSPEND"/>
 *     &lt;enumeration value="CLOSE"/>
 *     &lt;enumeration value="REINSTATE"/>
 *     &lt;enumeration value="REACTIVATE"/>
 *     &lt;enumeration value="PASTDATE"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "AmendActionType")
@XmlEnum
public enum AmendActionType {

    AMEND,
    SUSPEND,
    CLOSE,
    REINSTATE,
    REACTIVATE,
    PASTDATE;

    public String value() {
        return name();
    }

    public static AmendActionType fromValue(String v) {
        return valueOf(v);
    }

}

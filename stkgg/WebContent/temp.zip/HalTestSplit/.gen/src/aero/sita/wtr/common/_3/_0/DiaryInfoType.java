
package aero.sita.wtr.common._3._0;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for DiaryInfoType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DiaryInfoType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="CreateDate" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="SuspendDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="TracingDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="CloseDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="ReinstateDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="RematchDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="LZControlDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="RetiredDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="AssociatedRecord" type="{http://sita.aero/wtr/common/3/0}RecordIdentifierType" minOccurs="0"/>
 *         &lt;element name="CrossReferenceRecords" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="CrossReferenceRecord" type="{http://sita.aero/wtr/common/3/0}RecordIdentifierType" maxOccurs="5"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="CrossReferenceRecord" type="{http://sita.aero/wtr/common/3/0}RecordIdentifierType" minOccurs="0"/>
 *         &lt;element name="DisposalDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="ControllingStation" type="{http://www.iata.org/IATA/2007/00}StationType" minOccurs="0"/>
 *         &lt;element name="TracingFinalized" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="ClaimInvestigationDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="DateInventoryReceived" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="TracingExtendedDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DiaryInfoType", propOrder = {
    "createDate",
    "suspendDate",
    "tracingDate",
    "closeDate",
    "reinstateDate",
    "rematchDate",
    "lzControlDate",
    "retiredDate",
    "associatedRecord",
    "crossReferenceRecords",
    "crossReferenceRecord",
    "disposalDate",
    "controllingStation",
    "tracingFinalized",
    "claimInvestigationDate",
    "dateInventoryReceived",
    "tracingExtendedDate"
})
public class DiaryInfoType {

    @XmlElement(name = "CreateDate", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar createDate;
    @XmlElement(name = "SuspendDate")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar suspendDate;
    @XmlElement(name = "TracingDate")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar tracingDate;
    @XmlElement(name = "CloseDate")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar closeDate;
    @XmlElement(name = "ReinstateDate")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar reinstateDate;
    @XmlElement(name = "RematchDate")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar rematchDate;
    @XmlElement(name = "LZControlDate")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar lzControlDate;
    @XmlElement(name = "RetiredDate")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar retiredDate;
    @XmlElement(name = "AssociatedRecord")
    protected RecordIdentifierType associatedRecord;
    @XmlElement(name = "CrossReferenceRecords")
    protected DiaryInfoType.CrossReferenceRecords crossReferenceRecords;
    @XmlElement(name = "CrossReferenceRecord")
    protected RecordIdentifierType crossReferenceRecord;
    @XmlElement(name = "DisposalDate")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar disposalDate;
    @XmlElement(name = "ControllingStation")
    protected String controllingStation;
    @XmlElement(name = "TracingFinalized")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar tracingFinalized;
    @XmlElement(name = "ClaimInvestigationDate")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar claimInvestigationDate;
    @XmlElement(name = "DateInventoryReceived")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar dateInventoryReceived;
    @XmlElement(name = "TracingExtendedDate")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar tracingExtendedDate;

    /**
     * Gets the value of the createDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getCreateDate() {
        return createDate;
    }

    /**
     * Sets the value of the createDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setCreateDate(XMLGregorianCalendar value) {
        this.createDate = value;
    }

    /**
     * Gets the value of the suspendDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getSuspendDate() {
        return suspendDate;
    }

    /**
     * Sets the value of the suspendDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setSuspendDate(XMLGregorianCalendar value) {
        this.suspendDate = value;
    }

    /**
     * Gets the value of the tracingDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getTracingDate() {
        return tracingDate;
    }

    /**
     * Sets the value of the tracingDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setTracingDate(XMLGregorianCalendar value) {
        this.tracingDate = value;
    }

    /**
     * Gets the value of the closeDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getCloseDate() {
        return closeDate;
    }

    /**
     * Sets the value of the closeDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setCloseDate(XMLGregorianCalendar value) {
        this.closeDate = value;
    }

    /**
     * Gets the value of the reinstateDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getReinstateDate() {
        return reinstateDate;
    }

    /**
     * Sets the value of the reinstateDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setReinstateDate(XMLGregorianCalendar value) {
        this.reinstateDate = value;
    }

    /**
     * Gets the value of the rematchDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getRematchDate() {
        return rematchDate;
    }

    /**
     * Sets the value of the rematchDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setRematchDate(XMLGregorianCalendar value) {
        this.rematchDate = value;
    }

    /**
     * Gets the value of the lzControlDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getLZControlDate() {
        return lzControlDate;
    }

    /**
     * Sets the value of the lzControlDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setLZControlDate(XMLGregorianCalendar value) {
        this.lzControlDate = value;
    }

    /**
     * Gets the value of the retiredDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getRetiredDate() {
        return retiredDate;
    }

    /**
     * Sets the value of the retiredDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setRetiredDate(XMLGregorianCalendar value) {
        this.retiredDate = value;
    }

    /**
     * Gets the value of the associatedRecord property.
     * 
     * @return
     *     possible object is
     *     {@link RecordIdentifierType }
     *     
     */
    public RecordIdentifierType getAssociatedRecord() {
        return associatedRecord;
    }

    /**
     * Sets the value of the associatedRecord property.
     * 
     * @param value
     *     allowed object is
     *     {@link RecordIdentifierType }
     *     
     */
    public void setAssociatedRecord(RecordIdentifierType value) {
        this.associatedRecord = value;
    }

    /**
     * Gets the value of the crossReferenceRecords property.
     * 
     * @return
     *     possible object is
     *     {@link DiaryInfoType.CrossReferenceRecords }
     *     
     */
    public DiaryInfoType.CrossReferenceRecords getCrossReferenceRecords() {
        return crossReferenceRecords;
    }

    /**
     * Sets the value of the crossReferenceRecords property.
     * 
     * @param value
     *     allowed object is
     *     {@link DiaryInfoType.CrossReferenceRecords }
     *     
     */
    public void setCrossReferenceRecords(DiaryInfoType.CrossReferenceRecords value) {
        this.crossReferenceRecords = value;
    }

    /**
     * Gets the value of the crossReferenceRecord property.
     * 
     * @return
     *     possible object is
     *     {@link RecordIdentifierType }
     *     
     */
    public RecordIdentifierType getCrossReferenceRecord() {
        return crossReferenceRecord;
    }

    /**
     * Sets the value of the crossReferenceRecord property.
     * 
     * @param value
     *     allowed object is
     *     {@link RecordIdentifierType }
     *     
     */
    public void setCrossReferenceRecord(RecordIdentifierType value) {
        this.crossReferenceRecord = value;
    }

    /**
     * Gets the value of the disposalDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDisposalDate() {
        return disposalDate;
    }

    /**
     * Sets the value of the disposalDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDisposalDate(XMLGregorianCalendar value) {
        this.disposalDate = value;
    }

    /**
     * Gets the value of the controllingStation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getControllingStation() {
        return controllingStation;
    }

    /**
     * Sets the value of the controllingStation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setControllingStation(String value) {
        this.controllingStation = value;
    }

    /**
     * Gets the value of the tracingFinalized property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getTracingFinalized() {
        return tracingFinalized;
    }

    /**
     * Sets the value of the tracingFinalized property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setTracingFinalized(XMLGregorianCalendar value) {
        this.tracingFinalized = value;
    }

    /**
     * Gets the value of the claimInvestigationDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getClaimInvestigationDate() {
        return claimInvestigationDate;
    }

    /**
     * Sets the value of the claimInvestigationDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setClaimInvestigationDate(XMLGregorianCalendar value) {
        this.claimInvestigationDate = value;
    }

    /**
     * Gets the value of the dateInventoryReceived property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateInventoryReceived() {
        return dateInventoryReceived;
    }

    /**
     * Sets the value of the dateInventoryReceived property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateInventoryReceived(XMLGregorianCalendar value) {
        this.dateInventoryReceived = value;
    }

    /**
     * Gets the value of the tracingExtendedDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getTracingExtendedDate() {
        return tracingExtendedDate;
    }

    /**
     * Sets the value of the tracingExtendedDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setTracingExtendedDate(XMLGregorianCalendar value) {
        this.tracingExtendedDate = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="CrossReferenceRecord" type="{http://sita.aero/wtr/common/3/0}RecordIdentifierType" maxOccurs="5"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "crossReferenceRecord"
    })
    public static class CrossReferenceRecords {

        @XmlElement(name = "CrossReferenceRecord", required = true)
        protected List<RecordIdentifierType> crossReferenceRecord;

        /**
         * Gets the value of the crossReferenceRecord property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the crossReferenceRecord property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getCrossReferenceRecord().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link RecordIdentifierType }
         * 
         * 
         */
        public List<RecordIdentifierType> getCrossReferenceRecord() {
            if (crossReferenceRecord == null) {
                crossReferenceRecord = new ArrayList<RecordIdentifierType>();
            }
            return this.crossReferenceRecord;
        }

    }

}

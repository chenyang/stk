@javax.xml.bind.annotation.XmlSchema(namespace = "http://sita.aero/WTR_BagsCreateRS/3/0", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package aero.sita.wtr_bagscreaters._3._0;

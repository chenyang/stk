
package aero.sita.wtr.common._3._0;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * This holds information about the damaged bag group
 * 
 * <p>Java class for DamagedBagGroupType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DamagedBagGroupType">
 *   &lt;complexContent>
 *     &lt;extension base="{http://sita.aero/wtr/common/3/0}BagGroupType">
 *       &lt;sequence>
 *         &lt;element name="DamagedBags">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="DamagedBag" type="{http://sita.aero/wtr/common/3/0}DamagedBagType" maxOccurs="10"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="BaggageItinerary" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="FlightDateOrARNK" type="{http://sita.aero/wtr/common/3/0}FlightDateOrARNKType" maxOccurs="5"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="ExcessBaggage" type="{http://sita.aero/wtr/common/3/0}AlphaNumericStringLength1to15" minOccurs="0"/>
 *         &lt;element name="MissingWeight" type="{http://sita.aero/wtr/common/3/0}StringLength1to9" minOccurs="0"/>
 *         &lt;element name="LostContents" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="Content" type="{http://sita.aero/wtr/common/3/0}StringLength1to58" maxOccurs="2"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="ContentsDamageDesc" type="{http://sita.aero/wtr/common/3/0}StringLength1to58" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DamagedBagGroupType", propOrder = {
    "damagedBags",
    "baggageItinerary",
    "excessBaggage",
    "missingWeight",
    "lostContents",
    "contentsDamageDesc"
})
public class DamagedBagGroupType
    extends BagGroupType
{

    @XmlElement(name = "DamagedBags", required = true)
    protected DamagedBagGroupType.DamagedBags damagedBags;
    @XmlElement(name = "BaggageItinerary")
    protected DamagedBagGroupType.BaggageItinerary baggageItinerary;
    @XmlElement(name = "ExcessBaggage")
    protected String excessBaggage;
    @XmlElement(name = "MissingWeight")
    protected String missingWeight;
    @XmlElement(name = "LostContents")
    protected DamagedBagGroupType.LostContents lostContents;
    @XmlElement(name = "ContentsDamageDesc")
    protected String contentsDamageDesc;

    /**
     * Gets the value of the damagedBags property.
     * 
     * @return
     *     possible object is
     *     {@link DamagedBagGroupType.DamagedBags }
     *     
     */
    public DamagedBagGroupType.DamagedBags getDamagedBags() {
        return damagedBags;
    }

    /**
     * Sets the value of the damagedBags property.
     * 
     * @param value
     *     allowed object is
     *     {@link DamagedBagGroupType.DamagedBags }
     *     
     */
    public void setDamagedBags(DamagedBagGroupType.DamagedBags value) {
        this.damagedBags = value;
    }

    /**
     * Gets the value of the baggageItinerary property.
     * 
     * @return
     *     possible object is
     *     {@link DamagedBagGroupType.BaggageItinerary }
     *     
     */
    public DamagedBagGroupType.BaggageItinerary getBaggageItinerary() {
        return baggageItinerary;
    }

    /**
     * Sets the value of the baggageItinerary property.
     * 
     * @param value
     *     allowed object is
     *     {@link DamagedBagGroupType.BaggageItinerary }
     *     
     */
    public void setBaggageItinerary(DamagedBagGroupType.BaggageItinerary value) {
        this.baggageItinerary = value;
    }

    /**
     * Gets the value of the excessBaggage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExcessBaggage() {
        return excessBaggage;
    }

    /**
     * Sets the value of the excessBaggage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExcessBaggage(String value) {
        this.excessBaggage = value;
    }

    /**
     * Gets the value of the missingWeight property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMissingWeight() {
        return missingWeight;
    }

    /**
     * Sets the value of the missingWeight property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMissingWeight(String value) {
        this.missingWeight = value;
    }

    /**
     * Gets the value of the lostContents property.
     * 
     * @return
     *     possible object is
     *     {@link DamagedBagGroupType.LostContents }
     *     
     */
    public DamagedBagGroupType.LostContents getLostContents() {
        return lostContents;
    }

    /**
     * Sets the value of the lostContents property.
     * 
     * @param value
     *     allowed object is
     *     {@link DamagedBagGroupType.LostContents }
     *     
     */
    public void setLostContents(DamagedBagGroupType.LostContents value) {
        this.lostContents = value;
    }

    /**
     * Gets the value of the contentsDamageDesc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContentsDamageDesc() {
        return contentsDamageDesc;
    }

    /**
     * Sets the value of the contentsDamageDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContentsDamageDesc(String value) {
        this.contentsDamageDesc = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="FlightDateOrARNK" type="{http://sita.aero/wtr/common/3/0}FlightDateOrARNKType" maxOccurs="5"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "flightDateOrARNK"
    })
    public static class BaggageItinerary {

        @XmlElement(name = "FlightDateOrARNK", required = true)
        protected List<FlightDateOrARNKType> flightDateOrARNK;

        /**
         * Gets the value of the flightDateOrARNK property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the flightDateOrARNK property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getFlightDateOrARNK().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link FlightDateOrARNKType }
         * 
         * 
         */
        public List<FlightDateOrARNKType> getFlightDateOrARNK() {
            if (flightDateOrARNK == null) {
                flightDateOrARNK = new ArrayList<FlightDateOrARNKType>();
            }
            return this.flightDateOrARNK;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="DamagedBag" type="{http://sita.aero/wtr/common/3/0}DamagedBagType" maxOccurs="10"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "damagedBag"
    })
    public static class DamagedBags {

        @XmlElement(name = "DamagedBag", required = true)
        protected List<DamagedBagType> damagedBag;

        /**
         * Gets the value of the damagedBag property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the damagedBag property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getDamagedBag().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link DamagedBagType }
         * 
         * 
         */
        public List<DamagedBagType> getDamagedBag() {
            if (damagedBag == null) {
                damagedBag = new ArrayList<DamagedBagType>();
            }
            return this.damagedBag;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="Content" type="{http://sita.aero/wtr/common/3/0}StringLength1to58" maxOccurs="2"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "content"
    })
    public static class LostContents {

        @XmlElement(name = "Content", required = true)
        protected List<String> content;

        /**
         * Gets the value of the content property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the content property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getContent().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getContent() {
            if (content == null) {
                content = new ArrayList<String>();
            }
            return this.content;
        }

    }

}

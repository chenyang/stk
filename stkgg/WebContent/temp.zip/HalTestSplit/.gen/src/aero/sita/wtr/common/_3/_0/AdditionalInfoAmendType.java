
package aero.sita.wtr.common._3._0;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;


/**
 * <p>Java class for AdditionalInfoAmendType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AdditionalInfoAmendType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="MiscInfo" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="TextLine" type="{http://sita.aero/wtr/common/3/0}StringLength0to58AmendType" maxOccurs="99"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="FurtherInfo" minOccurs="0">
 *           &lt;complexType>
 *             &lt;simpleContent>
 *               &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>StringLength0to58">
 *                 &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
 *               &lt;/extension>
 *             &lt;/simpleContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="SupplimentalInfo" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="TextLine" type="{http://sita.aero/wtr/common/3/0}StringLength0to58AmendType" maxOccurs="2"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="CustomsInfo" minOccurs="0">
 *           &lt;complexType>
 *             &lt;simpleContent>
 *               &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>StringLength0to58">
 *                 &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
 *               &lt;/extension>
 *             &lt;/simpleContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;choice>
 *           &lt;element name="DeliveryInfo" minOccurs="0">
 *             &lt;complexType>
 *               &lt;complexContent>
 *                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                   &lt;sequence>
 *                     &lt;element name="Text" type="{http://sita.aero/wtr/common/3/0}StringLength0to2000AmendType"/>
 *                   &lt;/sequence>
 *                 &lt;/restriction>
 *               &lt;/complexContent>
 *             &lt;/complexType>
 *           &lt;/element>
 *           &lt;element name="MessageInfo" minOccurs="0">
 *             &lt;complexType>
 *               &lt;complexContent>
 *                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                   &lt;sequence>
 *                     &lt;element name="Text" type="{http://sita.aero/wtr/common/3/0}StringLength0to2000AmendType"/>
 *                   &lt;/sequence>
 *                 &lt;/restriction>
 *               &lt;/complexContent>
 *             &lt;/complexType>
 *           &lt;/element>
 *           &lt;element name="MatchInfo" minOccurs="0">
 *             &lt;complexType>
 *               &lt;complexContent>
 *                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                   &lt;sequence>
 *                     &lt;element name="Text" type="{http://sita.aero/wtr/common/3/0}StringLength0to2000AmendType"/>
 *                   &lt;/sequence>
 *                 &lt;/restriction>
 *               &lt;/complexContent>
 *             &lt;/complexType>
 *           &lt;/element>
 *         &lt;/choice>
 *         &lt;element name="UserComments" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="TextLine" type="{http://sita.aero/wtr/common/3/0}StringLength0to58AmendType" maxOccurs="99"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AdditionalInfoAmendType", propOrder = {
    "miscInfo",
    "furtherInfo",
    "supplimentalInfo",
    "customsInfo",
    "deliveryInfo",
    "messageInfo",
    "matchInfo",
    "userComments"
})
public class AdditionalInfoAmendType {

    @XmlElement(name = "MiscInfo")
    protected AdditionalInfoAmendType.MiscInfo miscInfo;
    @XmlElement(name = "FurtherInfo")
    protected AdditionalInfoAmendType.FurtherInfo furtherInfo;
    @XmlElement(name = "SupplimentalInfo")
    protected AdditionalInfoAmendType.SupplimentalInfo supplimentalInfo;
    @XmlElement(name = "CustomsInfo")
    protected AdditionalInfoAmendType.CustomsInfo customsInfo;
    @XmlElement(name = "DeliveryInfo")
    protected AdditionalInfoAmendType.DeliveryInfo deliveryInfo;
    @XmlElement(name = "MessageInfo")
    protected AdditionalInfoAmendType.MessageInfo messageInfo;
    @XmlElement(name = "MatchInfo")
    protected AdditionalInfoAmendType.MatchInfo matchInfo;
    @XmlElement(name = "UserComments")
    protected AdditionalInfoAmendType.UserComments userComments;

    /**
     * Gets the value of the miscInfo property.
     * 
     * @return
     *     possible object is
     *     {@link AdditionalInfoAmendType.MiscInfo }
     *     
     */
    public AdditionalInfoAmendType.MiscInfo getMiscInfo() {
        return miscInfo;
    }

    /**
     * Sets the value of the miscInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link AdditionalInfoAmendType.MiscInfo }
     *     
     */
    public void setMiscInfo(AdditionalInfoAmendType.MiscInfo value) {
        this.miscInfo = value;
    }

    /**
     * Gets the value of the furtherInfo property.
     * 
     * @return
     *     possible object is
     *     {@link AdditionalInfoAmendType.FurtherInfo }
     *     
     */
    public AdditionalInfoAmendType.FurtherInfo getFurtherInfo() {
        return furtherInfo;
    }

    /**
     * Sets the value of the furtherInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link AdditionalInfoAmendType.FurtherInfo }
     *     
     */
    public void setFurtherInfo(AdditionalInfoAmendType.FurtherInfo value) {
        this.furtherInfo = value;
    }

    /**
     * Gets the value of the supplimentalInfo property.
     * 
     * @return
     *     possible object is
     *     {@link AdditionalInfoAmendType.SupplimentalInfo }
     *     
     */
    public AdditionalInfoAmendType.SupplimentalInfo getSupplimentalInfo() {
        return supplimentalInfo;
    }

    /**
     * Sets the value of the supplimentalInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link AdditionalInfoAmendType.SupplimentalInfo }
     *     
     */
    public void setSupplimentalInfo(AdditionalInfoAmendType.SupplimentalInfo value) {
        this.supplimentalInfo = value;
    }

    /**
     * Gets the value of the customsInfo property.
     * 
     * @return
     *     possible object is
     *     {@link AdditionalInfoAmendType.CustomsInfo }
     *     
     */
    public AdditionalInfoAmendType.CustomsInfo getCustomsInfo() {
        return customsInfo;
    }

    /**
     * Sets the value of the customsInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link AdditionalInfoAmendType.CustomsInfo }
     *     
     */
    public void setCustomsInfo(AdditionalInfoAmendType.CustomsInfo value) {
        this.customsInfo = value;
    }

    /**
     * Gets the value of the deliveryInfo property.
     * 
     * @return
     *     possible object is
     *     {@link AdditionalInfoAmendType.DeliveryInfo }
     *     
     */
    public AdditionalInfoAmendType.DeliveryInfo getDeliveryInfo() {
        return deliveryInfo;
    }

    /**
     * Sets the value of the deliveryInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link AdditionalInfoAmendType.DeliveryInfo }
     *     
     */
    public void setDeliveryInfo(AdditionalInfoAmendType.DeliveryInfo value) {
        this.deliveryInfo = value;
    }

    /**
     * Gets the value of the messageInfo property.
     * 
     * @return
     *     possible object is
     *     {@link AdditionalInfoAmendType.MessageInfo }
     *     
     */
    public AdditionalInfoAmendType.MessageInfo getMessageInfo() {
        return messageInfo;
    }

    /**
     * Sets the value of the messageInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link AdditionalInfoAmendType.MessageInfo }
     *     
     */
    public void setMessageInfo(AdditionalInfoAmendType.MessageInfo value) {
        this.messageInfo = value;
    }

    /**
     * Gets the value of the matchInfo property.
     * 
     * @return
     *     possible object is
     *     {@link AdditionalInfoAmendType.MatchInfo }
     *     
     */
    public AdditionalInfoAmendType.MatchInfo getMatchInfo() {
        return matchInfo;
    }

    /**
     * Sets the value of the matchInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link AdditionalInfoAmendType.MatchInfo }
     *     
     */
    public void setMatchInfo(AdditionalInfoAmendType.MatchInfo value) {
        this.matchInfo = value;
    }

    /**
     * Gets the value of the userComments property.
     * 
     * @return
     *     possible object is
     *     {@link AdditionalInfoAmendType.UserComments }
     *     
     */
    public AdditionalInfoAmendType.UserComments getUserComments() {
        return userComments;
    }

    /**
     * Sets the value of the userComments property.
     * 
     * @param value
     *     allowed object is
     *     {@link AdditionalInfoAmendType.UserComments }
     *     
     */
    public void setUserComments(AdditionalInfoAmendType.UserComments value) {
        this.userComments = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;simpleContent>
     *     &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>StringLength0to58">
     *       &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
     *     &lt;/extension>
     *   &lt;/simpleContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class CustomsInfo {

        @XmlValue
        protected String value;
        @XmlAttribute(name = "Delete")
        protected Boolean delete;

        /**
         * Used for Character Strings, length 0 to 58
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setValue(String value) {
            this.value = value;
        }

        /**
         * Gets the value of the delete property.
         * 
         * @return
         *     possible object is
         *     {@link Boolean }
         *     
         */
        public boolean isDelete() {
            if (delete == null) {
                return false;
            } else {
                return delete;
            }
        }

        /**
         * Sets the value of the delete property.
         * 
         * @param value
         *     allowed object is
         *     {@link Boolean }
         *     
         */
        public void setDelete(Boolean value) {
            this.delete = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="Text" type="{http://sita.aero/wtr/common/3/0}StringLength0to2000AmendType"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "text"
    })
    public static class DeliveryInfo {

        @XmlElement(name = "Text", required = true)
        protected StringLength0To2000AmendType text;

        /**
         * Gets the value of the text property.
         * 
         * @return
         *     possible object is
         *     {@link StringLength0To2000AmendType }
         *     
         */
        public StringLength0To2000AmendType getText() {
            return text;
        }

        /**
         * Sets the value of the text property.
         * 
         * @param value
         *     allowed object is
         *     {@link StringLength0To2000AmendType }
         *     
         */
        public void setText(StringLength0To2000AmendType value) {
            this.text = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;simpleContent>
     *     &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>StringLength0to58">
     *       &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
     *     &lt;/extension>
     *   &lt;/simpleContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class FurtherInfo {

        @XmlValue
        protected String value;
        @XmlAttribute(name = "Delete")
        protected Boolean delete;

        /**
         * Used for Character Strings, length 0 to 58
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setValue(String value) {
            this.value = value;
        }

        /**
         * Gets the value of the delete property.
         * 
         * @return
         *     possible object is
         *     {@link Boolean }
         *     
         */
        public boolean isDelete() {
            if (delete == null) {
                return false;
            } else {
                return delete;
            }
        }

        /**
         * Sets the value of the delete property.
         * 
         * @param value
         *     allowed object is
         *     {@link Boolean }
         *     
         */
        public void setDelete(Boolean value) {
            this.delete = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="Text" type="{http://sita.aero/wtr/common/3/0}StringLength0to2000AmendType"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "text"
    })
    public static class MatchInfo {

        @XmlElement(name = "Text", required = true)
        protected StringLength0To2000AmendType text;

        /**
         * Gets the value of the text property.
         * 
         * @return
         *     possible object is
         *     {@link StringLength0To2000AmendType }
         *     
         */
        public StringLength0To2000AmendType getText() {
            return text;
        }

        /**
         * Sets the value of the text property.
         * 
         * @param value
         *     allowed object is
         *     {@link StringLength0To2000AmendType }
         *     
         */
        public void setText(StringLength0To2000AmendType value) {
            this.text = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="Text" type="{http://sita.aero/wtr/common/3/0}StringLength0to2000AmendType"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "text"
    })
    public static class MessageInfo {

        @XmlElement(name = "Text", required = true)
        protected StringLength0To2000AmendType text;

        /**
         * Gets the value of the text property.
         * 
         * @return
         *     possible object is
         *     {@link StringLength0To2000AmendType }
         *     
         */
        public StringLength0To2000AmendType getText() {
            return text;
        }

        /**
         * Sets the value of the text property.
         * 
         * @param value
         *     allowed object is
         *     {@link StringLength0To2000AmendType }
         *     
         */
        public void setText(StringLength0To2000AmendType value) {
            this.text = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="TextLine" type="{http://sita.aero/wtr/common/3/0}StringLength0to58AmendType" maxOccurs="99"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "textLine"
    })
    public static class MiscInfo {

        @XmlElement(name = "TextLine", required = true)
        protected List<StringLength0To58AmendType> textLine;

        /**
         * Gets the value of the textLine property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the textLine property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getTextLine().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link StringLength0To58AmendType }
         * 
         * 
         */
        public List<StringLength0To58AmendType> getTextLine() {
            if (textLine == null) {
                textLine = new ArrayList<StringLength0To58AmendType>();
            }
            return this.textLine;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="TextLine" type="{http://sita.aero/wtr/common/3/0}StringLength0to58AmendType" maxOccurs="2"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "textLine"
    })
    public static class SupplimentalInfo {

        @XmlElement(name = "TextLine", required = true)
        protected List<StringLength0To58AmendType> textLine;

        /**
         * Gets the value of the textLine property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the textLine property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getTextLine().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link StringLength0To58AmendType }
         * 
         * 
         */
        public List<StringLength0To58AmendType> getTextLine() {
            if (textLine == null) {
                textLine = new ArrayList<StringLength0To58AmendType>();
            }
            return this.textLine;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="TextLine" type="{http://sita.aero/wtr/common/3/0}StringLength0to58AmendType" maxOccurs="99"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "textLine"
    })
    public static class UserComments {

        @XmlElement(name = "TextLine", required = true)
        protected List<StringLength0To58AmendType> textLine;

        /**
         * Gets the value of the textLine property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the textLine property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getTextLine().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link StringLength0To58AmendType }
         * 
         * 
         */
        public List<StringLength0To58AmendType> getTextLine() {
            if (textLine == null) {
                textLine = new ArrayList<StringLength0To58AmendType>();
            }
            return this.textLine;
        }

    }

}

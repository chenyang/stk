
package aero.sita.wtr.common._3._0;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DelayedBagRecordType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DelayedBagRecordType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Passengers" type="{http://sita.aero/wtr/common/3/0}PassengerItineraryType"/>
 *         &lt;element name="DelayedBagGroup" type="{http://sita.aero/wtr/common/3/0}DelayedBagGroupType"/>
 *         &lt;element name="Claim" type="{http://sita.aero/wtr/common/3/0}ClaimType"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DelayedBagRecordType", propOrder = {
    "passengers",
    "delayedBagGroup",
    "claim"
})
public class DelayedBagRecordType {

    @XmlElement(name = "Passengers", required = true)
    protected PassengerItineraryType passengers;
    @XmlElement(name = "DelayedBagGroup", required = true)
    protected DelayedBagGroupType delayedBagGroup;
    @XmlElement(name = "Claim", required = true)
    protected ClaimType claim;

    /**
     * Gets the value of the passengers property.
     * 
     * @return
     *     possible object is
     *     {@link PassengerItineraryType }
     *     
     */
    public PassengerItineraryType getPassengers() {
        return passengers;
    }

    /**
     * Sets the value of the passengers property.
     * 
     * @param value
     *     allowed object is
     *     {@link PassengerItineraryType }
     *     
     */
    public void setPassengers(PassengerItineraryType value) {
        this.passengers = value;
    }

    /**
     * Gets the value of the delayedBagGroup property.
     * 
     * @return
     *     possible object is
     *     {@link DelayedBagGroupType }
     *     
     */
    public DelayedBagGroupType getDelayedBagGroup() {
        return delayedBagGroup;
    }

    /**
     * Sets the value of the delayedBagGroup property.
     * 
     * @param value
     *     allowed object is
     *     {@link DelayedBagGroupType }
     *     
     */
    public void setDelayedBagGroup(DelayedBagGroupType value) {
        this.delayedBagGroup = value;
    }

    /**
     * Gets the value of the claim property.
     * 
     * @return
     *     possible object is
     *     {@link ClaimType }
     *     
     */
    public ClaimType getClaim() {
        return claim;
    }

    /**
     * Sets the value of the claim property.
     * 
     * @param value
     *     allowed object is
     *     {@link ClaimType }
     *     
     */
    public void setClaim(ClaimType value) {
        this.claim = value;
    }

}

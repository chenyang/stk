
package aero.sita.wtr.common._3._0;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for LicenseNumberType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="LicenseNumberType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;attribute name="TagType" type="{http://sita.aero/wtr/common/3/0}NumericLength1" />
 *       &lt;attribute name="IssuerCode" use="required" type="{http://sita.aero/wtr/common/3/0}IssuerCodeType" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "LicenseNumberType")
public class LicenseNumberType {

    @XmlAttribute(name = "TagType")
    protected Integer tagType;
    @XmlAttribute(name = "IssuerCode", required = true)
    protected String issuerCode;

    /**
     * Gets the value of the tagType property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getTagType() {
        return tagType;
    }

    /**
     * Sets the value of the tagType property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setTagType(Integer value) {
        this.tagType = value;
    }

    /**
     * Gets the value of the issuerCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIssuerCode() {
        return issuerCode;
    }

    /**
     * Sets the value of the issuerCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIssuerCode(String value) {
        this.issuerCode = value;
    }

}

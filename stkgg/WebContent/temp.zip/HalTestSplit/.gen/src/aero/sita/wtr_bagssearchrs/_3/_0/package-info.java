@javax.xml.bind.annotation.XmlSchema(namespace = "http://sita.aero/WTR_BagsSearchRS/3/0", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package aero.sita.wtr_bagssearchrs._3._0;

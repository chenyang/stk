
package aero.sita.wtr.common._3._0;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for OnHandBagRecordType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="OnHandBagRecordType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="OnHandBag" type="{http://sita.aero/wtr/common/3/0}OnHandBagType"/>
 *         &lt;element name="Passengers" type="{http://sita.aero/wtr/common/3/0}PassengerItineraryType"/>
 *         &lt;element name="Claim" type="{http://sita.aero/wtr/common/3/0}ClaimType"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "OnHandBagRecordType", propOrder = {
    "onHandBag",
    "passengers",
    "claim"
})
public class OnHandBagRecordType {

    @XmlElement(name = "OnHandBag", required = true)
    protected OnHandBagType onHandBag;
    @XmlElement(name = "Passengers", required = true)
    protected PassengerItineraryType passengers;
    @XmlElement(name = "Claim", required = true)
    protected ClaimType claim;

    /**
     * Gets the value of the onHandBag property.
     * 
     * @return
     *     possible object is
     *     {@link OnHandBagType }
     *     
     */
    public OnHandBagType getOnHandBag() {
        return onHandBag;
    }

    /**
     * Sets the value of the onHandBag property.
     * 
     * @param value
     *     allowed object is
     *     {@link OnHandBagType }
     *     
     */
    public void setOnHandBag(OnHandBagType value) {
        this.onHandBag = value;
    }

    /**
     * Gets the value of the passengers property.
     * 
     * @return
     *     possible object is
     *     {@link PassengerItineraryType }
     *     
     */
    public PassengerItineraryType getPassengers() {
        return passengers;
    }

    /**
     * Sets the value of the passengers property.
     * 
     * @param value
     *     allowed object is
     *     {@link PassengerItineraryType }
     *     
     */
    public void setPassengers(PassengerItineraryType value) {
        this.passengers = value;
    }

    /**
     * Gets the value of the claim property.
     * 
     * @return
     *     possible object is
     *     {@link ClaimType }
     *     
     */
    public ClaimType getClaim() {
        return claim;
    }

    /**
     * Sets the value of the claim property.
     * 
     * @param value
     *     allowed object is
     *     {@link ClaimType }
     *     
     */
    public void setClaim(ClaimType value) {
        this.claim = value;
    }

}


package aero.sita.wtr.common._3._0;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AdditionalInfoType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AdditionalInfoType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="MiscInfo" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="TextLine" type="{http://sita.aero/wtr/common/3/0}StringLength0to58" maxOccurs="99"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="FurtherInfo" type="{http://sita.aero/wtr/common/3/0}StringLength1to58" minOccurs="0"/>
 *         &lt;element name="SupplimentalInfo" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="TextLine" type="{http://sita.aero/wtr/common/3/0}StringLength0to58" maxOccurs="2"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="CustomsInfo" type="{http://sita.aero/wtr/common/3/0}StringLength1to58" minOccurs="0"/>
 *         &lt;element name="UserComments" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="TextLine" type="{http://sita.aero/wtr/common/3/0}StringLength0to58" maxOccurs="99"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AdditionalInfoType", propOrder = {
    "miscInfo",
    "furtherInfo",
    "supplimentalInfo",
    "customsInfo",
    "userComments"
})
public class AdditionalInfoType {

    @XmlElement(name = "MiscInfo")
    protected AdditionalInfoType.MiscInfo miscInfo;
    @XmlElement(name = "FurtherInfo")
    protected String furtherInfo;
    @XmlElement(name = "SupplimentalInfo")
    protected AdditionalInfoType.SupplimentalInfo supplimentalInfo;
    @XmlElement(name = "CustomsInfo")
    protected String customsInfo;
    @XmlElement(name = "UserComments")
    protected AdditionalInfoType.UserComments userComments;

    /**
     * Gets the value of the miscInfo property.
     * 
     * @return
     *     possible object is
     *     {@link AdditionalInfoType.MiscInfo }
     *     
     */
    public AdditionalInfoType.MiscInfo getMiscInfo() {
        return miscInfo;
    }

    /**
     * Sets the value of the miscInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link AdditionalInfoType.MiscInfo }
     *     
     */
    public void setMiscInfo(AdditionalInfoType.MiscInfo value) {
        this.miscInfo = value;
    }

    /**
     * Gets the value of the furtherInfo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFurtherInfo() {
        return furtherInfo;
    }

    /**
     * Sets the value of the furtherInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFurtherInfo(String value) {
        this.furtherInfo = value;
    }

    /**
     * Gets the value of the supplimentalInfo property.
     * 
     * @return
     *     possible object is
     *     {@link AdditionalInfoType.SupplimentalInfo }
     *     
     */
    public AdditionalInfoType.SupplimentalInfo getSupplimentalInfo() {
        return supplimentalInfo;
    }

    /**
     * Sets the value of the supplimentalInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link AdditionalInfoType.SupplimentalInfo }
     *     
     */
    public void setSupplimentalInfo(AdditionalInfoType.SupplimentalInfo value) {
        this.supplimentalInfo = value;
    }

    /**
     * Gets the value of the customsInfo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustomsInfo() {
        return customsInfo;
    }

    /**
     * Sets the value of the customsInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustomsInfo(String value) {
        this.customsInfo = value;
    }

    /**
     * Gets the value of the userComments property.
     * 
     * @return
     *     possible object is
     *     {@link AdditionalInfoType.UserComments }
     *     
     */
    public AdditionalInfoType.UserComments getUserComments() {
        return userComments;
    }

    /**
     * Sets the value of the userComments property.
     * 
     * @param value
     *     allowed object is
     *     {@link AdditionalInfoType.UserComments }
     *     
     */
    public void setUserComments(AdditionalInfoType.UserComments value) {
        this.userComments = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="TextLine" type="{http://sita.aero/wtr/common/3/0}StringLength0to58" maxOccurs="99"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "textLine"
    })
    public static class MiscInfo {

        @XmlElement(name = "TextLine", required = true)
        protected List<String> textLine;

        /**
         * Gets the value of the textLine property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the textLine property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getTextLine().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getTextLine() {
            if (textLine == null) {
                textLine = new ArrayList<String>();
            }
            return this.textLine;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="TextLine" type="{http://sita.aero/wtr/common/3/0}StringLength0to58" maxOccurs="2"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "textLine"
    })
    public static class SupplimentalInfo {

        @XmlElement(name = "TextLine", required = true)
        protected List<String> textLine;

        /**
         * Gets the value of the textLine property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the textLine property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getTextLine().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getTextLine() {
            if (textLine == null) {
                textLine = new ArrayList<String>();
            }
            return this.textLine;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="TextLine" type="{http://sita.aero/wtr/common/3/0}StringLength0to58" maxOccurs="99"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "textLine"
    })
    public static class UserComments {

        @XmlElement(name = "TextLine", required = true)
        protected List<String> textLine;

        /**
         * Gets the value of the textLine property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the textLine property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getTextLine().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getTextLine() {
            if (textLine == null) {
                textLine = new ArrayList<String>();
            }
            return this.textLine;
        }

    }

}

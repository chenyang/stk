
package aero.sita.wtr.common._3._0;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * Contians history about the Worldtracer bag record history
 * 
 * <p>Java class for RecordHistoryType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="RecordHistoryType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="History" type="{http://sita.aero/wtr/common/3/0}StringLength1to2000" maxOccurs="unbounded"/>
 *         &lt;element name="MatchHistory" type="{http://sita.aero/wtr/common/3/0}StringLength1to2000" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RecordHistoryType", propOrder = {
    "history",
    "matchHistory"
})
public class RecordHistoryType {

    @XmlElement(name = "History", required = true)
    protected List<String> history;
    @XmlElement(name = "MatchHistory")
    protected List<String> matchHistory;

    /**
     * Gets the value of the history property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the history property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getHistory().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getHistory() {
        if (history == null) {
            history = new ArrayList<String>();
        }
        return this.history;
    }

    /**
     * Gets the value of the matchHistory property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the matchHistory property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getMatchHistory().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getMatchHistory() {
        if (matchHistory == null) {
            matchHistory = new ArrayList<String>();
        }
        return this.matchHistory;
    }

}

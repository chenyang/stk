
package aero.sita.wtr.common._3._0;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for FileStatusType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="FileStatusType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}NMTOKEN">
 *     &lt;enumeration value="CLOSED"/>
 *     &lt;enumeration value="EXTENDED"/>
 *     &lt;enumeration value="SUSPENDED"/>
 *     &lt;enumeration value="OPEN"/>
 *     &lt;enumeration value="ALL"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "FileStatusType")
@XmlEnum
public enum FileStatusType {

    CLOSED,
    EXTENDED,
    SUSPENDED,
    OPEN,
    ALL;

    public String value() {
        return name();
    }

    public static FileStatusType fromValue(String v) {
        return valueOf(v);
    }

}

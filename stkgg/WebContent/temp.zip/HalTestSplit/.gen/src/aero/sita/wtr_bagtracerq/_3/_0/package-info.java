@javax.xml.bind.annotation.XmlSchema(namespace = "http://sita.aero/WTR_BagTraceRQ/3/0", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package aero.sita.wtr_bagtracerq._3._0;

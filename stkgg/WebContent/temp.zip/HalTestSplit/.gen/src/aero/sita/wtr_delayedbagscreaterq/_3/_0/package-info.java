@javax.xml.bind.annotation.XmlSchema(namespace = "http://sita.aero/WTR_DelayedBagsCreateRQ/3/0", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package aero.sita.wtr_delayedbagscreaterq._3._0;

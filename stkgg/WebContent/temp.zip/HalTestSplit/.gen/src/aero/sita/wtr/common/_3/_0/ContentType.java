
package aero.sita.wtr.common._3._0;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * Contains category and description. Description can contain upto 90 characters in length or 91 characters with 46th char being a space. To make the description compatible with type A input, the size is made 91 characters. Type A takes 2 lines of 45 characters each and that is converted to single line with a space in between when converted to xml. A description with 91 characters in length and does not have a space at 46th postion would be rejected by WTR with an error.
 * 
 * <p>Java class for ContentType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ContentType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Category" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;union memberTypes=" {http://sita.aero/wtr/common/3/0}StandardCategoryType {http://sita.aero/wtr/common/3/0}AlphaLength1to12">
 *             &lt;/union>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Description" type="{http://sita.aero/wtr/common/3/0}StringLength1to91" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ContentType", propOrder = {
    "category",
    "description"
})
@XmlSeeAlso({
    aero.sita.wtr.common._3._0.ContentsAmendType.Content.class
})
public class ContentType {

    @XmlElement(name = "Category")
    protected String category;
    @XmlElement(name = "Description")
    protected String description;

    /**
     * Gets the value of the category property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCategory() {
        return category;
    }

    /**
     * Sets the value of the category property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCategory(String value) {
        this.category = value;
    }

    /**
     * Gets the value of the description property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescription(String value) {
        this.description = value;
    }

}

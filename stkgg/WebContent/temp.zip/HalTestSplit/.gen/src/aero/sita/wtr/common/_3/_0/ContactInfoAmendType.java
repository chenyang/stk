
package aero.sita.wtr.common._3._0;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for ContactInfoAmendType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ContactInfoAmendType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="PermanentAddress" type="{http://sita.aero/wtr/common/3/0}WTR_AddressAmendType" minOccurs="0"/>
 *         &lt;element name="TempAddress" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="Address" type="{http://sita.aero/wtr/common/3/0}WTR_AddressAmendType" minOccurs="0"/>
 *                   &lt;element name="ValidityDate" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;simpleContent>
 *                         &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema>date">
 *                           &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
 *                         &lt;/extension>
 *                       &lt;/simpleContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="PermPhones" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="Phone" type="{http://sita.aero/wtr/common/3/0}PhoneAmendType" maxOccurs="2"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="CellPhones" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="Phone" type="{http://sita.aero/wtr/common/3/0}PhoneAmendType" maxOccurs="2"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="TempPhones" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="Phone" type="{http://sita.aero/wtr/common/3/0}PhoneAmendType" maxOccurs="2"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="Emails" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="Email" type="{http://sita.aero/wtr/common/3/0}StringLength0to58AmendType" maxOccurs="2"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="Faxes" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="Fax" type="{http://sita.aero/wtr/common/3/0}PhoneAmendType" maxOccurs="2"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="Country" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;choice>
 *                   &lt;element name="CountryCode" type="{http://www.iata.org/IATA/2007/00}ISO3166" minOccurs="0"/>
 *                   &lt;element name="CountryName" type="{http://sita.aero/wtr/common/3/0}StringLength1to30" minOccurs="0"/>
 *                 &lt;/choice>
 *                 &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="State" minOccurs="0">
 *           &lt;complexType>
 *             &lt;simpleContent>
 *               &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>AlphaStringLength0to2">
 *                 &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
 *               &lt;/extension>
 *             &lt;/simpleContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="ZipCode" minOccurs="0">
 *           &lt;complexType>
 *             &lt;simpleContent>
 *               &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>StringLength0to12">
 *                 &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
 *               &lt;/extension>
 *             &lt;/simpleContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ContactInfoAmendType", propOrder = {
    "permanentAddress",
    "tempAddress",
    "permPhones",
    "cellPhones",
    "tempPhones",
    "emails",
    "faxes",
    "country",
    "state",
    "zipCode"
})
public class ContactInfoAmendType {

    @XmlElement(name = "PermanentAddress")
    protected WTRAddressAmendType permanentAddress;
    @XmlElement(name = "TempAddress")
    protected ContactInfoAmendType.TempAddress tempAddress;
    @XmlElement(name = "PermPhones")
    protected ContactInfoAmendType.PermPhones permPhones;
    @XmlElement(name = "CellPhones")
    protected ContactInfoAmendType.CellPhones cellPhones;
    @XmlElement(name = "TempPhones")
    protected ContactInfoAmendType.TempPhones tempPhones;
    @XmlElement(name = "Emails")
    protected ContactInfoAmendType.Emails emails;
    @XmlElement(name = "Faxes")
    protected ContactInfoAmendType.Faxes faxes;
    @XmlElement(name = "Country")
    protected ContactInfoAmendType.Country country;
    @XmlElement(name = "State")
    protected ContactInfoAmendType.State state;
    @XmlElement(name = "ZipCode")
    protected ContactInfoAmendType.ZipCode zipCode;

    /**
     * Gets the value of the permanentAddress property.
     * 
     * @return
     *     possible object is
     *     {@link WTRAddressAmendType }
     *     
     */
    public WTRAddressAmendType getPermanentAddress() {
        return permanentAddress;
    }

    /**
     * Sets the value of the permanentAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link WTRAddressAmendType }
     *     
     */
    public void setPermanentAddress(WTRAddressAmendType value) {
        this.permanentAddress = value;
    }

    /**
     * Gets the value of the tempAddress property.
     * 
     * @return
     *     possible object is
     *     {@link ContactInfoAmendType.TempAddress }
     *     
     */
    public ContactInfoAmendType.TempAddress getTempAddress() {
        return tempAddress;
    }

    /**
     * Sets the value of the tempAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link ContactInfoAmendType.TempAddress }
     *     
     */
    public void setTempAddress(ContactInfoAmendType.TempAddress value) {
        this.tempAddress = value;
    }

    /**
     * Gets the value of the permPhones property.
     * 
     * @return
     *     possible object is
     *     {@link ContactInfoAmendType.PermPhones }
     *     
     */
    public ContactInfoAmendType.PermPhones getPermPhones() {
        return permPhones;
    }

    /**
     * Sets the value of the permPhones property.
     * 
     * @param value
     *     allowed object is
     *     {@link ContactInfoAmendType.PermPhones }
     *     
     */
    public void setPermPhones(ContactInfoAmendType.PermPhones value) {
        this.permPhones = value;
    }

    /**
     * Gets the value of the cellPhones property.
     * 
     * @return
     *     possible object is
     *     {@link ContactInfoAmendType.CellPhones }
     *     
     */
    public ContactInfoAmendType.CellPhones getCellPhones() {
        return cellPhones;
    }

    /**
     * Sets the value of the cellPhones property.
     * 
     * @param value
     *     allowed object is
     *     {@link ContactInfoAmendType.CellPhones }
     *     
     */
    public void setCellPhones(ContactInfoAmendType.CellPhones value) {
        this.cellPhones = value;
    }

    /**
     * Gets the value of the tempPhones property.
     * 
     * @return
     *     possible object is
     *     {@link ContactInfoAmendType.TempPhones }
     *     
     */
    public ContactInfoAmendType.TempPhones getTempPhones() {
        return tempPhones;
    }

    /**
     * Sets the value of the tempPhones property.
     * 
     * @param value
     *     allowed object is
     *     {@link ContactInfoAmendType.TempPhones }
     *     
     */
    public void setTempPhones(ContactInfoAmendType.TempPhones value) {
        this.tempPhones = value;
    }

    /**
     * Gets the value of the emails property.
     * 
     * @return
     *     possible object is
     *     {@link ContactInfoAmendType.Emails }
     *     
     */
    public ContactInfoAmendType.Emails getEmails() {
        return emails;
    }

    /**
     * Sets the value of the emails property.
     * 
     * @param value
     *     allowed object is
     *     {@link ContactInfoAmendType.Emails }
     *     
     */
    public void setEmails(ContactInfoAmendType.Emails value) {
        this.emails = value;
    }

    /**
     * Gets the value of the faxes property.
     * 
     * @return
     *     possible object is
     *     {@link ContactInfoAmendType.Faxes }
     *     
     */
    public ContactInfoAmendType.Faxes getFaxes() {
        return faxes;
    }

    /**
     * Sets the value of the faxes property.
     * 
     * @param value
     *     allowed object is
     *     {@link ContactInfoAmendType.Faxes }
     *     
     */
    public void setFaxes(ContactInfoAmendType.Faxes value) {
        this.faxes = value;
    }

    /**
     * Gets the value of the country property.
     * 
     * @return
     *     possible object is
     *     {@link ContactInfoAmendType.Country }
     *     
     */
    public ContactInfoAmendType.Country getCountry() {
        return country;
    }

    /**
     * Sets the value of the country property.
     * 
     * @param value
     *     allowed object is
     *     {@link ContactInfoAmendType.Country }
     *     
     */
    public void setCountry(ContactInfoAmendType.Country value) {
        this.country = value;
    }

    /**
     * Gets the value of the state property.
     * 
     * @return
     *     possible object is
     *     {@link ContactInfoAmendType.State }
     *     
     */
    public ContactInfoAmendType.State getState() {
        return state;
    }

    /**
     * Sets the value of the state property.
     * 
     * @param value
     *     allowed object is
     *     {@link ContactInfoAmendType.State }
     *     
     */
    public void setState(ContactInfoAmendType.State value) {
        this.state = value;
    }

    /**
     * Gets the value of the zipCode property.
     * 
     * @return
     *     possible object is
     *     {@link ContactInfoAmendType.ZipCode }
     *     
     */
    public ContactInfoAmendType.ZipCode getZipCode() {
        return zipCode;
    }

    /**
     * Sets the value of the zipCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link ContactInfoAmendType.ZipCode }
     *     
     */
    public void setZipCode(ContactInfoAmendType.ZipCode value) {
        this.zipCode = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="Phone" type="{http://sita.aero/wtr/common/3/0}PhoneAmendType" maxOccurs="2"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "phone"
    })
    public static class CellPhones {

        @XmlElement(name = "Phone", required = true)
        protected List<PhoneAmendType> phone;

        /**
         * Gets the value of the phone property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the phone property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getPhone().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link PhoneAmendType }
         * 
         * 
         */
        public List<PhoneAmendType> getPhone() {
            if (phone == null) {
                phone = new ArrayList<PhoneAmendType>();
            }
            return this.phone;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;choice>
     *         &lt;element name="CountryCode" type="{http://www.iata.org/IATA/2007/00}ISO3166" minOccurs="0"/>
     *         &lt;element name="CountryName" type="{http://sita.aero/wtr/common/3/0}StringLength1to30" minOccurs="0"/>
     *       &lt;/choice>
     *       &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "countryCode",
        "countryName"
    })
    public static class Country {

        @XmlElement(name = "CountryCode")
        protected String countryCode;
        @XmlElement(name = "CountryName")
        protected String countryName;
        @XmlAttribute(name = "Delete")
        protected Boolean delete;

        /**
         * Gets the value of the countryCode property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getCountryCode() {
            return countryCode;
        }

        /**
         * Sets the value of the countryCode property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setCountryCode(String value) {
            this.countryCode = value;
        }

        /**
         * Gets the value of the countryName property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getCountryName() {
            return countryName;
        }

        /**
         * Sets the value of the countryName property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setCountryName(String value) {
            this.countryName = value;
        }

        /**
         * Gets the value of the delete property.
         * 
         * @return
         *     possible object is
         *     {@link Boolean }
         *     
         */
        public boolean isDelete() {
            if (delete == null) {
                return false;
            } else {
                return delete;
            }
        }

        /**
         * Sets the value of the delete property.
         * 
         * @param value
         *     allowed object is
         *     {@link Boolean }
         *     
         */
        public void setDelete(Boolean value) {
            this.delete = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="Email" type="{http://sita.aero/wtr/common/3/0}StringLength0to58AmendType" maxOccurs="2"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "email"
    })
    public static class Emails {

        @XmlElement(name = "Email", required = true)
        protected List<StringLength0To58AmendType> email;

        /**
         * Gets the value of the email property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the email property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getEmail().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link StringLength0To58AmendType }
         * 
         * 
         */
        public List<StringLength0To58AmendType> getEmail() {
            if (email == null) {
                email = new ArrayList<StringLength0To58AmendType>();
            }
            return this.email;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="Fax" type="{http://sita.aero/wtr/common/3/0}PhoneAmendType" maxOccurs="2"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "fax"
    })
    public static class Faxes {

        @XmlElement(name = "Fax", required = true)
        protected List<PhoneAmendType> fax;

        /**
         * Gets the value of the fax property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the fax property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getFax().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link PhoneAmendType }
         * 
         * 
         */
        public List<PhoneAmendType> getFax() {
            if (fax == null) {
                fax = new ArrayList<PhoneAmendType>();
            }
            return this.fax;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="Phone" type="{http://sita.aero/wtr/common/3/0}PhoneAmendType" maxOccurs="2"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "phone"
    })
    public static class PermPhones {

        @XmlElement(name = "Phone", required = true)
        protected List<PhoneAmendType> phone;

        /**
         * Gets the value of the phone property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the phone property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getPhone().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link PhoneAmendType }
         * 
         * 
         */
        public List<PhoneAmendType> getPhone() {
            if (phone == null) {
                phone = new ArrayList<PhoneAmendType>();
            }
            return this.phone;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;simpleContent>
     *     &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>AlphaStringLength0to2">
     *       &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
     *     &lt;/extension>
     *   &lt;/simpleContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class State {

        @XmlValue
        protected String value;
        @XmlAttribute(name = "Delete")
        protected Boolean delete;

        /**
         * Alpha string length 0 to 2
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setValue(String value) {
            this.value = value;
        }

        /**
         * Gets the value of the delete property.
         * 
         * @return
         *     possible object is
         *     {@link Boolean }
         *     
         */
        public boolean isDelete() {
            if (delete == null) {
                return false;
            } else {
                return delete;
            }
        }

        /**
         * Sets the value of the delete property.
         * 
         * @param value
         *     allowed object is
         *     {@link Boolean }
         *     
         */
        public void setDelete(Boolean value) {
            this.delete = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="Address" type="{http://sita.aero/wtr/common/3/0}WTR_AddressAmendType" minOccurs="0"/>
     *         &lt;element name="ValidityDate" minOccurs="0">
     *           &lt;complexType>
     *             &lt;simpleContent>
     *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema>date">
     *                 &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
     *               &lt;/extension>
     *             &lt;/simpleContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "address",
        "validityDate"
    })
    public static class TempAddress {

        @XmlElement(name = "Address")
        protected WTRAddressAmendType address;
        @XmlElement(name = "ValidityDate")
        protected ContactInfoAmendType.TempAddress.ValidityDate validityDate;

        /**
         * Gets the value of the address property.
         * 
         * @return
         *     possible object is
         *     {@link WTRAddressAmendType }
         *     
         */
        public WTRAddressAmendType getAddress() {
            return address;
        }

        /**
         * Sets the value of the address property.
         * 
         * @param value
         *     allowed object is
         *     {@link WTRAddressAmendType }
         *     
         */
        public void setAddress(WTRAddressAmendType value) {
            this.address = value;
        }

        /**
         * Gets the value of the validityDate property.
         * 
         * @return
         *     possible object is
         *     {@link ContactInfoAmendType.TempAddress.ValidityDate }
         *     
         */
        public ContactInfoAmendType.TempAddress.ValidityDate getValidityDate() {
            return validityDate;
        }

        /**
         * Sets the value of the validityDate property.
         * 
         * @param value
         *     allowed object is
         *     {@link ContactInfoAmendType.TempAddress.ValidityDate }
         *     
         */
        public void setValidityDate(ContactInfoAmendType.TempAddress.ValidityDate value) {
            this.validityDate = value;
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;simpleContent>
         *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema>date">
         *       &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
         *     &lt;/extension>
         *   &lt;/simpleContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "value"
        })
        public static class ValidityDate {

            @XmlValue
            @XmlSchemaType(name = "date")
            protected XMLGregorianCalendar value;
            @XmlAttribute(name = "Delete")
            protected Boolean delete;

            /**
             * Gets the value of the value property.
             * 
             * @return
             *     possible object is
             *     {@link XMLGregorianCalendar }
             *     
             */
            public XMLGregorianCalendar getValue() {
                return value;
            }

            /**
             * Sets the value of the value property.
             * 
             * @param value
             *     allowed object is
             *     {@link XMLGregorianCalendar }
             *     
             */
            public void setValue(XMLGregorianCalendar value) {
                this.value = value;
            }

            /**
             * Gets the value of the delete property.
             * 
             * @return
             *     possible object is
             *     {@link Boolean }
             *     
             */
            public boolean isDelete() {
                if (delete == null) {
                    return false;
                } else {
                    return delete;
                }
            }

            /**
             * Sets the value of the delete property.
             * 
             * @param value
             *     allowed object is
             *     {@link Boolean }
             *     
             */
            public void setDelete(Boolean value) {
                this.delete = value;
            }

        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="Phone" type="{http://sita.aero/wtr/common/3/0}PhoneAmendType" maxOccurs="2"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "phone"
    })
    public static class TempPhones {

        @XmlElement(name = "Phone", required = true)
        protected List<PhoneAmendType> phone;

        /**
         * Gets the value of the phone property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the phone property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getPhone().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link PhoneAmendType }
         * 
         * 
         */
        public List<PhoneAmendType> getPhone() {
            if (phone == null) {
                phone = new ArrayList<PhoneAmendType>();
            }
            return this.phone;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;simpleContent>
     *     &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>StringLength0to12">
     *       &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
     *     &lt;/extension>
     *   &lt;/simpleContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class ZipCode {

        @XmlValue
        protected String value;
        @XmlAttribute(name = "Delete")
        protected Boolean delete;

        /**
         * Used for Character Strings, length 0 to 12
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setValue(String value) {
            this.value = value;
        }

        /**
         * Gets the value of the delete property.
         * 
         * @return
         *     possible object is
         *     {@link Boolean }
         *     
         */
        public boolean isDelete() {
            if (delete == null) {
                return false;
            } else {
                return delete;
            }
        }

        /**
         * Sets the value of the delete property.
         * 
         * @param value
         *     allowed object is
         *     {@link Boolean }
         *     
         */
        public void setDelete(Boolean value) {
            this.delete = value;
        }

    }

}

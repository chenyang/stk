
package aero.sita.wtr.common._3._0;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for BagElmsType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="BagElmsType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="B"/>
 *     &lt;enumeration value="K"/>
 *     &lt;enumeration value="C"/>
 *     &lt;enumeration value="H"/>
 *     &lt;enumeration value="S"/>
 *     &lt;enumeration value="W"/>
 *     &lt;enumeration value="X"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "BagElmsType")
@XmlEnum
public enum BagElmsType {

    B,
    K,
    C,
    H,
    S,
    W,
    X;

    public String value() {
        return name();
    }

    public static BagElmsType fromValue(String v) {
        return valueOf(v);
    }

}

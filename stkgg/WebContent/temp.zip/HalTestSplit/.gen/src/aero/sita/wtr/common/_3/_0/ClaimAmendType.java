
package aero.sita.wtr.common._3._0;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * Contains the claim data
 * 
 * <p>Java class for ClaimAmendType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ClaimAmendType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ClaimAmout" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;choice minOccurs="0">
 *                   &lt;element name="Unknown" type="{http://sita.aero/wtr/common/3/0}EmptyType"/>
 *                   &lt;element name="Amount" type="{http://sita.aero/wtr/common/3/0}AmountType"/>
 *                 &lt;/choice>
 *                 &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="CostRemarks" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="TextLine" type="{http://sita.aero/wtr/common/3/0}StringLength0to58AmendType" maxOccurs="5"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="PassengerPayments" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="PassengerPayment" type="{http://sita.aero/wtr/common/3/0}PassengerPaymentAmendType" maxOccurs="5"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="ClaimDate" minOccurs="0">
 *           &lt;complexType>
 *             &lt;simpleContent>
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema>date">
 *                 &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
 *               &lt;/extension>
 *             &lt;/simpleContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="DateNotified" minOccurs="0">
 *           &lt;complexType>
 *             &lt;simpleContent>
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema>date">
 *                 &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
 *               &lt;/extension>
 *             &lt;/simpleContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="QuestionnaireDate" minOccurs="0">
 *           &lt;complexType>
 *             &lt;simpleContent>
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema>date">
 *                 &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
 *               &lt;/extension>
 *             &lt;/simpleContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="FaultStationCode" minOccurs="0">
 *           &lt;complexType>
 *             &lt;simpleContent>
 *               &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>AlphaLength0to4">
 *                 &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
 *               &lt;/extension>
 *             &lt;/simpleContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="FaultTerminal" minOccurs="0">
 *           &lt;complexType>
 *             &lt;simpleContent>
 *               &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>AlphaNumericStringLength0to2">
 *                 &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
 *               &lt;/extension>
 *             &lt;/simpleContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="Insurance" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;attribute name="Value" type="{http://sita.aero/wtr/common/3/0}YesNoType" />
 *                 &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="LiabilityTag" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;extension base="{http://sita.aero/wtr/common/3/0}EmptyType">
 *                 &lt;attribute name="Value" type="{http://sita.aero/wtr/common/3/0}YesNoType" />
 *                 &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
 *               &lt;/extension>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="MissingBags" minOccurs="0">
 *           &lt;complexType>
 *             &lt;simpleContent>
 *               &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>NumericLength2">
 *                 &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
 *               &lt;/extension>
 *             &lt;/simpleContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="PartnerCode" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;choice minOccurs="0">
 *                   &lt;element name="CarrierCode">
 *                     &lt;simpleType>
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                         &lt;pattern value="[a-zA-Z0-9]{2,3}"/>
 *                       &lt;/restriction>
 *                     &lt;/simpleType>
 *                   &lt;/element>
 *                   &lt;element name="None" type="{http://sita.aero/wtr/common/3/0}EmptyType"/>
 *                 &lt;/choice>
 *                 &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="LossComments" minOccurs="0">
 *           &lt;complexType>
 *             &lt;simpleContent>
 *               &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>StringLength0to58">
 *                 &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
 *               &lt;/extension>
 *             &lt;/simpleContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ClaimAmendType", propOrder = {
    "claimAmout",
    "costRemarks",
    "passengerPayments",
    "claimDate",
    "dateNotified",
    "questionnaireDate",
    "faultStationCode",
    "faultTerminal",
    "insurance",
    "liabilityTag",
    "missingBags",
    "partnerCode",
    "lossComments"
})
@XmlSeeAlso({
    DamageClaimAmendType.class,
    DelayedClaimAmendType.class
})
public class ClaimAmendType {

    @XmlElement(name = "ClaimAmout")
    protected ClaimAmendType.ClaimAmout claimAmout;
    @XmlElement(name = "CostRemarks")
    protected ClaimAmendType.CostRemarks costRemarks;
    @XmlElement(name = "PassengerPayments")
    protected ClaimAmendType.PassengerPayments passengerPayments;
    @XmlElement(name = "ClaimDate")
    protected ClaimAmendType.ClaimDate claimDate;
    @XmlElement(name = "DateNotified")
    protected ClaimAmendType.DateNotified dateNotified;
    @XmlElement(name = "QuestionnaireDate")
    protected ClaimAmendType.QuestionnaireDate questionnaireDate;
    @XmlElement(name = "FaultStationCode")
    protected ClaimAmendType.FaultStationCode faultStationCode;
    @XmlElement(name = "FaultTerminal")
    protected ClaimAmendType.FaultTerminal faultTerminal;
    @XmlElement(name = "Insurance")
    protected ClaimAmendType.Insurance insurance;
    @XmlElement(name = "LiabilityTag")
    protected ClaimAmendType.LiabilityTag liabilityTag;
    @XmlElement(name = "MissingBags")
    protected ClaimAmendType.MissingBags missingBags;
    @XmlElement(name = "PartnerCode")
    protected ClaimAmendType.PartnerCode partnerCode;
    @XmlElement(name = "LossComments")
    protected ClaimAmendType.LossComments lossComments;

    /**
     * Gets the value of the claimAmout property.
     * 
     * @return
     *     possible object is
     *     {@link ClaimAmendType.ClaimAmout }
     *     
     */
    public ClaimAmendType.ClaimAmout getClaimAmout() {
        return claimAmout;
    }

    /**
     * Sets the value of the claimAmout property.
     * 
     * @param value
     *     allowed object is
     *     {@link ClaimAmendType.ClaimAmout }
     *     
     */
    public void setClaimAmout(ClaimAmendType.ClaimAmout value) {
        this.claimAmout = value;
    }

    /**
     * Gets the value of the costRemarks property.
     * 
     * @return
     *     possible object is
     *     {@link ClaimAmendType.CostRemarks }
     *     
     */
    public ClaimAmendType.CostRemarks getCostRemarks() {
        return costRemarks;
    }

    /**
     * Sets the value of the costRemarks property.
     * 
     * @param value
     *     allowed object is
     *     {@link ClaimAmendType.CostRemarks }
     *     
     */
    public void setCostRemarks(ClaimAmendType.CostRemarks value) {
        this.costRemarks = value;
    }

    /**
     * Gets the value of the passengerPayments property.
     * 
     * @return
     *     possible object is
     *     {@link ClaimAmendType.PassengerPayments }
     *     
     */
    public ClaimAmendType.PassengerPayments getPassengerPayments() {
        return passengerPayments;
    }

    /**
     * Sets the value of the passengerPayments property.
     * 
     * @param value
     *     allowed object is
     *     {@link ClaimAmendType.PassengerPayments }
     *     
     */
    public void setPassengerPayments(ClaimAmendType.PassengerPayments value) {
        this.passengerPayments = value;
    }

    /**
     * Gets the value of the claimDate property.
     * 
     * @return
     *     possible object is
     *     {@link ClaimAmendType.ClaimDate }
     *     
     */
    public ClaimAmendType.ClaimDate getClaimDate() {
        return claimDate;
    }

    /**
     * Sets the value of the claimDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link ClaimAmendType.ClaimDate }
     *     
     */
    public void setClaimDate(ClaimAmendType.ClaimDate value) {
        this.claimDate = value;
    }

    /**
     * Gets the value of the dateNotified property.
     * 
     * @return
     *     possible object is
     *     {@link ClaimAmendType.DateNotified }
     *     
     */
    public ClaimAmendType.DateNotified getDateNotified() {
        return dateNotified;
    }

    /**
     * Sets the value of the dateNotified property.
     * 
     * @param value
     *     allowed object is
     *     {@link ClaimAmendType.DateNotified }
     *     
     */
    public void setDateNotified(ClaimAmendType.DateNotified value) {
        this.dateNotified = value;
    }

    /**
     * Gets the value of the questionnaireDate property.
     * 
     * @return
     *     possible object is
     *     {@link ClaimAmendType.QuestionnaireDate }
     *     
     */
    public ClaimAmendType.QuestionnaireDate getQuestionnaireDate() {
        return questionnaireDate;
    }

    /**
     * Sets the value of the questionnaireDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link ClaimAmendType.QuestionnaireDate }
     *     
     */
    public void setQuestionnaireDate(ClaimAmendType.QuestionnaireDate value) {
        this.questionnaireDate = value;
    }

    /**
     * Gets the value of the faultStationCode property.
     * 
     * @return
     *     possible object is
     *     {@link ClaimAmendType.FaultStationCode }
     *     
     */
    public ClaimAmendType.FaultStationCode getFaultStationCode() {
        return faultStationCode;
    }

    /**
     * Sets the value of the faultStationCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link ClaimAmendType.FaultStationCode }
     *     
     */
    public void setFaultStationCode(ClaimAmendType.FaultStationCode value) {
        this.faultStationCode = value;
    }

    /**
     * Gets the value of the faultTerminal property.
     * 
     * @return
     *     possible object is
     *     {@link ClaimAmendType.FaultTerminal }
     *     
     */
    public ClaimAmendType.FaultTerminal getFaultTerminal() {
        return faultTerminal;
    }

    /**
     * Sets the value of the faultTerminal property.
     * 
     * @param value
     *     allowed object is
     *     {@link ClaimAmendType.FaultTerminal }
     *     
     */
    public void setFaultTerminal(ClaimAmendType.FaultTerminal value) {
        this.faultTerminal = value;
    }

    /**
     * Gets the value of the insurance property.
     * 
     * @return
     *     possible object is
     *     {@link ClaimAmendType.Insurance }
     *     
     */
    public ClaimAmendType.Insurance getInsurance() {
        return insurance;
    }

    /**
     * Sets the value of the insurance property.
     * 
     * @param value
     *     allowed object is
     *     {@link ClaimAmendType.Insurance }
     *     
     */
    public void setInsurance(ClaimAmendType.Insurance value) {
        this.insurance = value;
    }

    /**
     * Gets the value of the liabilityTag property.
     * 
     * @return
     *     possible object is
     *     {@link ClaimAmendType.LiabilityTag }
     *     
     */
    public ClaimAmendType.LiabilityTag getLiabilityTag() {
        return liabilityTag;
    }

    /**
     * Sets the value of the liabilityTag property.
     * 
     * @param value
     *     allowed object is
     *     {@link ClaimAmendType.LiabilityTag }
     *     
     */
    public void setLiabilityTag(ClaimAmendType.LiabilityTag value) {
        this.liabilityTag = value;
    }

    /**
     * Gets the value of the missingBags property.
     * 
     * @return
     *     possible object is
     *     {@link ClaimAmendType.MissingBags }
     *     
     */
    public ClaimAmendType.MissingBags getMissingBags() {
        return missingBags;
    }

    /**
     * Sets the value of the missingBags property.
     * 
     * @param value
     *     allowed object is
     *     {@link ClaimAmendType.MissingBags }
     *     
     */
    public void setMissingBags(ClaimAmendType.MissingBags value) {
        this.missingBags = value;
    }

    /**
     * Gets the value of the partnerCode property.
     * 
     * @return
     *     possible object is
     *     {@link ClaimAmendType.PartnerCode }
     *     
     */
    public ClaimAmendType.PartnerCode getPartnerCode() {
        return partnerCode;
    }

    /**
     * Sets the value of the partnerCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link ClaimAmendType.PartnerCode }
     *     
     */
    public void setPartnerCode(ClaimAmendType.PartnerCode value) {
        this.partnerCode = value;
    }

    /**
     * Gets the value of the lossComments property.
     * 
     * @return
     *     possible object is
     *     {@link ClaimAmendType.LossComments }
     *     
     */
    public ClaimAmendType.LossComments getLossComments() {
        return lossComments;
    }

    /**
     * Sets the value of the lossComments property.
     * 
     * @param value
     *     allowed object is
     *     {@link ClaimAmendType.LossComments }
     *     
     */
    public void setLossComments(ClaimAmendType.LossComments value) {
        this.lossComments = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;choice minOccurs="0">
     *         &lt;element name="Unknown" type="{http://sita.aero/wtr/common/3/0}EmptyType"/>
     *         &lt;element name="Amount" type="{http://sita.aero/wtr/common/3/0}AmountType"/>
     *       &lt;/choice>
     *       &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "unknown",
        "amount"
    })
    public static class ClaimAmout {

        @XmlElement(name = "Unknown")
        protected EmptyType unknown;
        @XmlElement(name = "Amount")
        protected AmountType amount;
        @XmlAttribute(name = "Delete")
        protected Boolean delete;

        /**
         * Gets the value of the unknown property.
         * 
         * @return
         *     possible object is
         *     {@link EmptyType }
         *     
         */
        public EmptyType getUnknown() {
            return unknown;
        }

        /**
         * Sets the value of the unknown property.
         * 
         * @param value
         *     allowed object is
         *     {@link EmptyType }
         *     
         */
        public void setUnknown(EmptyType value) {
            this.unknown = value;
        }

        /**
         * Gets the value of the amount property.
         * 
         * @return
         *     possible object is
         *     {@link AmountType }
         *     
         */
        public AmountType getAmount() {
            return amount;
        }

        /**
         * Sets the value of the amount property.
         * 
         * @param value
         *     allowed object is
         *     {@link AmountType }
         *     
         */
        public void setAmount(AmountType value) {
            this.amount = value;
        }

        /**
         * Gets the value of the delete property.
         * 
         * @return
         *     possible object is
         *     {@link Boolean }
         *     
         */
        public boolean isDelete() {
            if (delete == null) {
                return false;
            } else {
                return delete;
            }
        }

        /**
         * Sets the value of the delete property.
         * 
         * @param value
         *     allowed object is
         *     {@link Boolean }
         *     
         */
        public void setDelete(Boolean value) {
            this.delete = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;simpleContent>
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema>date">
     *       &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
     *     &lt;/extension>
     *   &lt;/simpleContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class ClaimDate {

        @XmlValue
        @XmlSchemaType(name = "date")
        protected XMLGregorianCalendar value;
        @XmlAttribute(name = "Delete")
        protected Boolean delete;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link XMLGregorianCalendar }
         *     
         */
        public XMLGregorianCalendar getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link XMLGregorianCalendar }
         *     
         */
        public void setValue(XMLGregorianCalendar value) {
            this.value = value;
        }

        /**
         * Gets the value of the delete property.
         * 
         * @return
         *     possible object is
         *     {@link Boolean }
         *     
         */
        public boolean isDelete() {
            if (delete == null) {
                return false;
            } else {
                return delete;
            }
        }

        /**
         * Sets the value of the delete property.
         * 
         * @param value
         *     allowed object is
         *     {@link Boolean }
         *     
         */
        public void setDelete(Boolean value) {
            this.delete = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="TextLine" type="{http://sita.aero/wtr/common/3/0}StringLength0to58AmendType" maxOccurs="5"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "textLine"
    })
    public static class CostRemarks {

        @XmlElement(name = "TextLine", required = true)
        protected List<StringLength0To58AmendType> textLine;

        /**
         * Gets the value of the textLine property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the textLine property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getTextLine().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link StringLength0To58AmendType }
         * 
         * 
         */
        public List<StringLength0To58AmendType> getTextLine() {
            if (textLine == null) {
                textLine = new ArrayList<StringLength0To58AmendType>();
            }
            return this.textLine;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;simpleContent>
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema>date">
     *       &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
     *     &lt;/extension>
     *   &lt;/simpleContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class DateNotified {

        @XmlValue
        @XmlSchemaType(name = "date")
        protected XMLGregorianCalendar value;
        @XmlAttribute(name = "Delete")
        protected Boolean delete;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link XMLGregorianCalendar }
         *     
         */
        public XMLGregorianCalendar getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link XMLGregorianCalendar }
         *     
         */
        public void setValue(XMLGregorianCalendar value) {
            this.value = value;
        }

        /**
         * Gets the value of the delete property.
         * 
         * @return
         *     possible object is
         *     {@link Boolean }
         *     
         */
        public boolean isDelete() {
            if (delete == null) {
                return false;
            } else {
                return delete;
            }
        }

        /**
         * Sets the value of the delete property.
         * 
         * @param value
         *     allowed object is
         *     {@link Boolean }
         *     
         */
        public void setDelete(Boolean value) {
            this.delete = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;simpleContent>
     *     &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>AlphaLength0to4">
     *       &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
     *     &lt;/extension>
     *   &lt;/simpleContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class FaultStationCode {

        @XmlValue
        protected String value;
        @XmlAttribute(name = "Delete")
        protected Boolean delete;

        /**
         * Used for Character Strings, length 0 to 4
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setValue(String value) {
            this.value = value;
        }

        /**
         * Gets the value of the delete property.
         * 
         * @return
         *     possible object is
         *     {@link Boolean }
         *     
         */
        public boolean isDelete() {
            if (delete == null) {
                return false;
            } else {
                return delete;
            }
        }

        /**
         * Sets the value of the delete property.
         * 
         * @param value
         *     allowed object is
         *     {@link Boolean }
         *     
         */
        public void setDelete(Boolean value) {
            this.delete = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;simpleContent>
     *     &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>AlphaNumericStringLength0to2">
     *       &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
     *     &lt;/extension>
     *   &lt;/simpleContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class FaultTerminal {

        @XmlValue
        protected String value;
        @XmlAttribute(name = "Delete")
        protected Boolean delete;

        /**
         * Used for Alpha Numeric Strings, length 0 and 2
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setValue(String value) {
            this.value = value;
        }

        /**
         * Gets the value of the delete property.
         * 
         * @return
         *     possible object is
         *     {@link Boolean }
         *     
         */
        public boolean isDelete() {
            if (delete == null) {
                return false;
            } else {
                return delete;
            }
        }

        /**
         * Sets the value of the delete property.
         * 
         * @param value
         *     allowed object is
         *     {@link Boolean }
         *     
         */
        public void setDelete(Boolean value) {
            this.delete = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;attribute name="Value" type="{http://sita.aero/wtr/common/3/0}YesNoType" />
     *       &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "")
    public static class Insurance {

        @XmlAttribute(name = "Value")
        protected YesNoType value;
        @XmlAttribute(name = "Delete")
        protected Boolean delete;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link YesNoType }
         *     
         */
        public YesNoType getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link YesNoType }
         *     
         */
        public void setValue(YesNoType value) {
            this.value = value;
        }

        /**
         * Gets the value of the delete property.
         * 
         * @return
         *     possible object is
         *     {@link Boolean }
         *     
         */
        public boolean isDelete() {
            if (delete == null) {
                return false;
            } else {
                return delete;
            }
        }

        /**
         * Sets the value of the delete property.
         * 
         * @param value
         *     allowed object is
         *     {@link Boolean }
         *     
         */
        public void setDelete(Boolean value) {
            this.delete = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;extension base="{http://sita.aero/wtr/common/3/0}EmptyType">
     *       &lt;attribute name="Value" type="{http://sita.aero/wtr/common/3/0}YesNoType" />
     *       &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
     *     &lt;/extension>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "")
    public static class LiabilityTag
        extends EmptyType
    {

        @XmlAttribute(name = "Value")
        protected YesNoType value;
        @XmlAttribute(name = "Delete")
        protected Boolean delete;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link YesNoType }
         *     
         */
        public YesNoType getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link YesNoType }
         *     
         */
        public void setValue(YesNoType value) {
            this.value = value;
        }

        /**
         * Gets the value of the delete property.
         * 
         * @return
         *     possible object is
         *     {@link Boolean }
         *     
         */
        public boolean isDelete() {
            if (delete == null) {
                return false;
            } else {
                return delete;
            }
        }

        /**
         * Sets the value of the delete property.
         * 
         * @param value
         *     allowed object is
         *     {@link Boolean }
         *     
         */
        public void setDelete(Boolean value) {
            this.delete = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;simpleContent>
     *     &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>StringLength0to58">
     *       &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
     *     &lt;/extension>
     *   &lt;/simpleContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class LossComments {

        @XmlValue
        protected String value;
        @XmlAttribute(name = "Delete")
        protected Boolean delete;

        /**
         * Used for Character Strings, length 0 to 58
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setValue(String value) {
            this.value = value;
        }

        /**
         * Gets the value of the delete property.
         * 
         * @return
         *     possible object is
         *     {@link Boolean }
         *     
         */
        public boolean isDelete() {
            if (delete == null) {
                return false;
            } else {
                return delete;
            }
        }

        /**
         * Sets the value of the delete property.
         * 
         * @param value
         *     allowed object is
         *     {@link Boolean }
         *     
         */
        public void setDelete(Boolean value) {
            this.delete = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;simpleContent>
     *     &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>NumericLength2">
     *       &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
     *     &lt;/extension>
     *   &lt;/simpleContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class MissingBags {

        @XmlValue
        protected short value;
        @XmlAttribute(name = "Delete")
        protected Boolean delete;

        /**
         * Contiains a number with up to 2 digits
         * 
         */
        public short getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         */
        public void setValue(short value) {
            this.value = value;
        }

        /**
         * Gets the value of the delete property.
         * 
         * @return
         *     possible object is
         *     {@link Boolean }
         *     
         */
        public boolean isDelete() {
            if (delete == null) {
                return false;
            } else {
                return delete;
            }
        }

        /**
         * Sets the value of the delete property.
         * 
         * @param value
         *     allowed object is
         *     {@link Boolean }
         *     
         */
        public void setDelete(Boolean value) {
            this.delete = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;choice minOccurs="0">
     *         &lt;element name="CarrierCode">
     *           &lt;simpleType>
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *               &lt;pattern value="[a-zA-Z0-9]{2,3}"/>
     *             &lt;/restriction>
     *           &lt;/simpleType>
     *         &lt;/element>
     *         &lt;element name="None" type="{http://sita.aero/wtr/common/3/0}EmptyType"/>
     *       &lt;/choice>
     *       &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "carrierCode",
        "none"
    })
    public static class PartnerCode {

        @XmlElement(name = "CarrierCode")
        protected String carrierCode;
        @XmlElement(name = "None")
        protected EmptyType none;
        @XmlAttribute(name = "Delete")
        protected Boolean delete;

        /**
         * Gets the value of the carrierCode property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getCarrierCode() {
            return carrierCode;
        }

        /**
         * Sets the value of the carrierCode property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setCarrierCode(String value) {
            this.carrierCode = value;
        }

        /**
         * Gets the value of the none property.
         * 
         * @return
         *     possible object is
         *     {@link EmptyType }
         *     
         */
        public EmptyType getNone() {
            return none;
        }

        /**
         * Sets the value of the none property.
         * 
         * @param value
         *     allowed object is
         *     {@link EmptyType }
         *     
         */
        public void setNone(EmptyType value) {
            this.none = value;
        }

        /**
         * Gets the value of the delete property.
         * 
         * @return
         *     possible object is
         *     {@link Boolean }
         *     
         */
        public boolean isDelete() {
            if (delete == null) {
                return false;
            } else {
                return delete;
            }
        }

        /**
         * Sets the value of the delete property.
         * 
         * @param value
         *     allowed object is
         *     {@link Boolean }
         *     
         */
        public void setDelete(Boolean value) {
            this.delete = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="PassengerPayment" type="{http://sita.aero/wtr/common/3/0}PassengerPaymentAmendType" maxOccurs="5"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "passengerPayment"
    })
    public static class PassengerPayments {

        @XmlElement(name = "PassengerPayment", required = true)
        protected List<PassengerPaymentAmendType> passengerPayment;

        /**
         * Gets the value of the passengerPayment property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the passengerPayment property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getPassengerPayment().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link PassengerPaymentAmendType }
         * 
         * 
         */
        public List<PassengerPaymentAmendType> getPassengerPayment() {
            if (passengerPayment == null) {
                passengerPayment = new ArrayList<PassengerPaymentAmendType>();
            }
            return this.passengerPayment;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;simpleContent>
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema>date">
     *       &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
     *     &lt;/extension>
     *   &lt;/simpleContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class QuestionnaireDate {

        @XmlValue
        @XmlSchemaType(name = "date")
        protected XMLGregorianCalendar value;
        @XmlAttribute(name = "Delete")
        protected Boolean delete;

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link XMLGregorianCalendar }
         *     
         */
        public XMLGregorianCalendar getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link XMLGregorianCalendar }
         *     
         */
        public void setValue(XMLGregorianCalendar value) {
            this.value = value;
        }

        /**
         * Gets the value of the delete property.
         * 
         * @return
         *     possible object is
         *     {@link Boolean }
         *     
         */
        public boolean isDelete() {
            if (delete == null) {
                return false;
            } else {
                return delete;
            }
        }

        /**
         * Sets the value of the delete property.
         * 
         * @param value
         *     allowed object is
         *     {@link Boolean }
         *     
         */
        public void setDelete(Boolean value) {
            this.delete = value;
        }

    }

}


package aero.sita.wtr.common._3._0;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for FoundItemType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FoundItemType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Id" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="Content" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="Category" type="{http://sita.aero/wtr/common/3/0}StringLength1to58"/>
 *                   &lt;element name="Description" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="TextLine" type="{http://sita.aero/wtr/common/3/0}StringLength0to58AmendFPType" maxOccurs="2"/>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="DateFound" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="DateRegistered" type="{http://www.iata.org/IATA/2007/00}DateOrDateTimeType" minOccurs="0"/>
 *         &lt;element name="SupplimentalInfo" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="TextLine" type="{http://sita.aero/wtr/common/3/0}StringLength0to58AmendFPType" maxOccurs="2"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="DisposalDate" minOccurs="0">
 *           &lt;complexType>
 *             &lt;simpleContent>
 *               &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>StringLength0to30">
 *                 &lt;attribute name="Date" use="required" type="{http://www.w3.org/2001/XMLSchema}date" />
 *               &lt;/extension>
 *             &lt;/simpleContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="AdditionalInfo" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="TextLine" type="{http://sita.aero/wtr/common/3/0}StringLength1to58" maxOccurs="2"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="AgentID" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;attribute name="CreatedBy" type="{http://sita.aero/wtr/common/3/0}StringLength1to12" />
 *                 &lt;attribute name="UpdatedBy" type="{http://sita.aero/wtr/common/3/0}StringLength1to12" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="LastUpdateDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FoundItemType", propOrder = {
    "id",
    "content",
    "dateFound",
    "dateRegistered",
    "supplimentalInfo",
    "disposalDate",
    "additionalInfo",
    "agentID",
    "lastUpdateDate"
})
public class FoundItemType {

    @XmlElement(name = "Id")
    protected Integer id;
    @XmlElement(name = "Content")
    protected FoundItemType.Content content;
    @XmlElement(name = "DateFound")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateFound;
    @XmlElement(name = "DateRegistered")
    protected String dateRegistered;
    @XmlElement(name = "SupplimentalInfo")
    protected FoundItemType.SupplimentalInfo supplimentalInfo;
    @XmlElement(name = "DisposalDate")
    protected FoundItemType.DisposalDate disposalDate;
    @XmlElement(name = "AdditionalInfo")
    protected FoundItemType.AdditionalInfo additionalInfo;
    @XmlElement(name = "AgentID")
    protected FoundItemType.AgentID agentID;
    @XmlElement(name = "LastUpdateDate")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar lastUpdateDate;

    /**
     * Gets the value of the id property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setId(Integer value) {
        this.id = value;
    }

    /**
     * Gets the value of the content property.
     * 
     * @return
     *     possible object is
     *     {@link FoundItemType.Content }
     *     
     */
    public FoundItemType.Content getContent() {
        return content;
    }

    /**
     * Sets the value of the content property.
     * 
     * @param value
     *     allowed object is
     *     {@link FoundItemType.Content }
     *     
     */
    public void setContent(FoundItemType.Content value) {
        this.content = value;
    }

    /**
     * Gets the value of the dateFound property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateFound() {
        return dateFound;
    }

    /**
     * Sets the value of the dateFound property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateFound(XMLGregorianCalendar value) {
        this.dateFound = value;
    }

    /**
     * Gets the value of the dateRegistered property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDateRegistered() {
        return dateRegistered;
    }

    /**
     * Sets the value of the dateRegistered property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDateRegistered(String value) {
        this.dateRegistered = value;
    }

    /**
     * Gets the value of the supplimentalInfo property.
     * 
     * @return
     *     possible object is
     *     {@link FoundItemType.SupplimentalInfo }
     *     
     */
    public FoundItemType.SupplimentalInfo getSupplimentalInfo() {
        return supplimentalInfo;
    }

    /**
     * Sets the value of the supplimentalInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link FoundItemType.SupplimentalInfo }
     *     
     */
    public void setSupplimentalInfo(FoundItemType.SupplimentalInfo value) {
        this.supplimentalInfo = value;
    }

    /**
     * Gets the value of the disposalDate property.
     * 
     * @return
     *     possible object is
     *     {@link FoundItemType.DisposalDate }
     *     
     */
    public FoundItemType.DisposalDate getDisposalDate() {
        return disposalDate;
    }

    /**
     * Sets the value of the disposalDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link FoundItemType.DisposalDate }
     *     
     */
    public void setDisposalDate(FoundItemType.DisposalDate value) {
        this.disposalDate = value;
    }

    /**
     * Gets the value of the additionalInfo property.
     * 
     * @return
     *     possible object is
     *     {@link FoundItemType.AdditionalInfo }
     *     
     */
    public FoundItemType.AdditionalInfo getAdditionalInfo() {
        return additionalInfo;
    }

    /**
     * Sets the value of the additionalInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link FoundItemType.AdditionalInfo }
     *     
     */
    public void setAdditionalInfo(FoundItemType.AdditionalInfo value) {
        this.additionalInfo = value;
    }

    /**
     * Gets the value of the agentID property.
     * 
     * @return
     *     possible object is
     *     {@link FoundItemType.AgentID }
     *     
     */
    public FoundItemType.AgentID getAgentID() {
        return agentID;
    }

    /**
     * Sets the value of the agentID property.
     * 
     * @param value
     *     allowed object is
     *     {@link FoundItemType.AgentID }
     *     
     */
    public void setAgentID(FoundItemType.AgentID value) {
        this.agentID = value;
    }

    /**
     * Gets the value of the lastUpdateDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getLastUpdateDate() {
        return lastUpdateDate;
    }

    /**
     * Sets the value of the lastUpdateDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setLastUpdateDate(XMLGregorianCalendar value) {
        this.lastUpdateDate = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="TextLine" type="{http://sita.aero/wtr/common/3/0}StringLength1to58" maxOccurs="2"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "textLine"
    })
    public static class AdditionalInfo {

        @XmlElement(name = "TextLine", required = true)
        protected List<String> textLine;

        /**
         * Gets the value of the textLine property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the textLine property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getTextLine().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getTextLine() {
            if (textLine == null) {
                textLine = new ArrayList<String>();
            }
            return this.textLine;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;attribute name="CreatedBy" type="{http://sita.aero/wtr/common/3/0}StringLength1to12" />
     *       &lt;attribute name="UpdatedBy" type="{http://sita.aero/wtr/common/3/0}StringLength1to12" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "")
    public static class AgentID {

        @XmlAttribute(name = "CreatedBy")
        protected String createdBy;
        @XmlAttribute(name = "UpdatedBy")
        protected String updatedBy;

        /**
         * Gets the value of the createdBy property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getCreatedBy() {
            return createdBy;
        }

        /**
         * Sets the value of the createdBy property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setCreatedBy(String value) {
            this.createdBy = value;
        }

        /**
         * Gets the value of the updatedBy property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getUpdatedBy() {
            return updatedBy;
        }

        /**
         * Sets the value of the updatedBy property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setUpdatedBy(String value) {
            this.updatedBy = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="Category" type="{http://sita.aero/wtr/common/3/0}StringLength1to58"/>
     *         &lt;element name="Description" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="TextLine" type="{http://sita.aero/wtr/common/3/0}StringLength0to58AmendFPType" maxOccurs="2"/>
     *                 &lt;/sequence>
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "category",
        "description"
    })
    public static class Content {

        @XmlElement(name = "Category", required = true)
        protected String category;
        @XmlElement(name = "Description")
        protected FoundItemType.Content.Description description;

        /**
         * Gets the value of the category property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getCategory() {
            return category;
        }

        /**
         * Sets the value of the category property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setCategory(String value) {
            this.category = value;
        }

        /**
         * Gets the value of the description property.
         * 
         * @return
         *     possible object is
         *     {@link FoundItemType.Content.Description }
         *     
         */
        public FoundItemType.Content.Description getDescription() {
            return description;
        }

        /**
         * Sets the value of the description property.
         * 
         * @param value
         *     allowed object is
         *     {@link FoundItemType.Content.Description }
         *     
         */
        public void setDescription(FoundItemType.Content.Description value) {
            this.description = value;
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="TextLine" type="{http://sita.aero/wtr/common/3/0}StringLength0to58AmendFPType" maxOccurs="2"/>
         *       &lt;/sequence>
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "textLine"
        })
        public static class Description {

            @XmlElement(name = "TextLine", required = true)
            protected List<StringLength0To58AmendFPType> textLine;

            /**
             * Gets the value of the textLine property.
             * 
             * <p>
             * This accessor method returns a reference to the live list,
             * not a snapshot. Therefore any modification you make to the
             * returned list will be present inside the JAXB object.
             * This is why there is not a <CODE>set</CODE> method for the textLine property.
             * 
             * <p>
             * For example, to add a new item, do as follows:
             * <pre>
             *    getTextLine().add(newItem);
             * </pre>
             * 
             * 
             * <p>
             * Objects of the following type(s) are allowed in the list
             * {@link StringLength0To58AmendFPType }
             * 
             * 
             */
            public List<StringLength0To58AmendFPType> getTextLine() {
                if (textLine == null) {
                    textLine = new ArrayList<StringLength0To58AmendFPType>();
                }
                return this.textLine;
            }

        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;simpleContent>
     *     &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>StringLength0to30">
     *       &lt;attribute name="Date" use="required" type="{http://www.w3.org/2001/XMLSchema}date" />
     *     &lt;/extension>
     *   &lt;/simpleContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class DisposalDate {

        @XmlValue
        protected String value;
        @XmlAttribute(name = "Date", required = true)
        @XmlSchemaType(name = "date")
        protected XMLGregorianCalendar date;

        /**
         * Used for Character Strings, length 0 to 30
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setValue(String value) {
            this.value = value;
        }

        /**
         * Gets the value of the date property.
         * 
         * @return
         *     possible object is
         *     {@link XMLGregorianCalendar }
         *     
         */
        public XMLGregorianCalendar getDate() {
            return date;
        }

        /**
         * Sets the value of the date property.
         * 
         * @param value
         *     allowed object is
         *     {@link XMLGregorianCalendar }
         *     
         */
        public void setDate(XMLGregorianCalendar value) {
            this.date = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="TextLine" type="{http://sita.aero/wtr/common/3/0}StringLength0to58AmendFPType" maxOccurs="2"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "textLine"
    })
    public static class SupplimentalInfo {

        @XmlElement(name = "TextLine", required = true)
        protected List<StringLength0To58AmendFPType> textLine;

        /**
         * Gets the value of the textLine property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the textLine property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getTextLine().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link StringLength0To58AmendFPType }
         * 
         * 
         */
        public List<StringLength0To58AmendFPType> getTextLine() {
            if (textLine == null) {
                textLine = new ArrayList<StringLength0To58AmendFPType>();
            }
            return this.textLine;
        }

    }

}

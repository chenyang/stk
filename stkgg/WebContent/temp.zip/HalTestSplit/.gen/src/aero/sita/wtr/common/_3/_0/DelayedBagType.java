
package aero.sita.wtr.common._3._0;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DelayedBagType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DelayedBagType">
 *   &lt;complexContent>
 *     &lt;extension base="{http://sita.aero/wtr/common/3/0}BagType">
 *       &lt;sequence>
 *         &lt;element name="BagContents" type="{http://sita.aero/wtr/common/3/0}ContentsType" minOccurs="0"/>
 *         &lt;element name="BagDetails" type="{http://sita.aero/wtr/common/3/0}StringLength1to58" minOccurs="0"/>
 *         &lt;element name="ContentsDesc" type="{http://sita.aero/wtr/common/3/0}StringLength1to58" minOccurs="0"/>
 *         &lt;element name="Remarks" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="Remark" type="{http://sita.aero/wtr/common/3/0}StringLength1to58" maxOccurs="3"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="AssociatedRecord" type="{http://sita.aero/wtr/common/3/0}RecordIdentifierType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DelayedBagType", propOrder = {
    "bagContents",
    "bagDetails",
    "contentsDesc",
    "remarks",
    "associatedRecord"
})
public class DelayedBagType
    extends BagType
{

    @XmlElement(name = "BagContents")
    protected ContentsType bagContents;
    @XmlElement(name = "BagDetails")
    protected String bagDetails;
    @XmlElement(name = "ContentsDesc")
    protected String contentsDesc;
    @XmlElement(name = "Remarks")
    protected DelayedBagType.Remarks remarks;
    @XmlElement(name = "AssociatedRecord")
    protected RecordIdentifierType associatedRecord;

    /**
     * Gets the value of the bagContents property.
     * 
     * @return
     *     possible object is
     *     {@link ContentsType }
     *     
     */
    public ContentsType getBagContents() {
        return bagContents;
    }

    /**
     * Sets the value of the bagContents property.
     * 
     * @param value
     *     allowed object is
     *     {@link ContentsType }
     *     
     */
    public void setBagContents(ContentsType value) {
        this.bagContents = value;
    }

    /**
     * Gets the value of the bagDetails property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBagDetails() {
        return bagDetails;
    }

    /**
     * Sets the value of the bagDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBagDetails(String value) {
        this.bagDetails = value;
    }

    /**
     * Gets the value of the contentsDesc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContentsDesc() {
        return contentsDesc;
    }

    /**
     * Sets the value of the contentsDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContentsDesc(String value) {
        this.contentsDesc = value;
    }

    /**
     * Gets the value of the remarks property.
     * 
     * @return
     *     possible object is
     *     {@link DelayedBagType.Remarks }
     *     
     */
    public DelayedBagType.Remarks getRemarks() {
        return remarks;
    }

    /**
     * Sets the value of the remarks property.
     * 
     * @param value
     *     allowed object is
     *     {@link DelayedBagType.Remarks }
     *     
     */
    public void setRemarks(DelayedBagType.Remarks value) {
        this.remarks = value;
    }

    /**
     * Gets the value of the associatedRecord property.
     * 
     * @return
     *     possible object is
     *     {@link RecordIdentifierType }
     *     
     */
    public RecordIdentifierType getAssociatedRecord() {
        return associatedRecord;
    }

    /**
     * Sets the value of the associatedRecord property.
     * 
     * @param value
     *     allowed object is
     *     {@link RecordIdentifierType }
     *     
     */
    public void setAssociatedRecord(RecordIdentifierType value) {
        this.associatedRecord = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="Remark" type="{http://sita.aero/wtr/common/3/0}StringLength1to58" maxOccurs="3"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "remark"
    })
    public static class Remarks {

        @XmlElement(name = "Remark", required = true)
        protected List<String> remark;

        /**
         * Gets the value of the remark property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the remark property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getRemark().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getRemark() {
            if (remark == null) {
                remark = new ArrayList<String>();
            }
            return this.remark;
        }

    }

}

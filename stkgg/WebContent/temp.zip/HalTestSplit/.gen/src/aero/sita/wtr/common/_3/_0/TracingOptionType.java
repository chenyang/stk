
package aero.sita.wtr.common._3._0;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for TracingOptionType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="TracingOptionType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}NMTOKEN">
 *     &lt;enumeration value="NON_TRACING"/>
 *     &lt;enumeration value="ONLINE_TRACING"/>
 *     &lt;enumeration value="SUSPENDED"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "TracingOptionType")
@XmlEnum
public enum TracingOptionType {

    NON_TRACING,
    ONLINE_TRACING,
    SUSPENDED;

    public String value() {
        return name();
    }

    public static TracingOptionType fromValue(String v) {
        return valueOf(v);
    }

}

@javax.xml.bind.annotation.XmlSchema(namespace = "http://sita.aero/hal")
package aero.sita.hal;

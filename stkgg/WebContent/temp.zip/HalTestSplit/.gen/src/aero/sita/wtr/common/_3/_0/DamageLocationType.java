
package aero.sita.wtr.common._3._0;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DamageLocationType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="DamageLocationType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}NMTOKEN">
 *     &lt;enumeration value="SIDE"/>
 *     &lt;enumeration value="TOP"/>
 *     &lt;enumeration value="END"/>
 *     &lt;enumeration value="BOTTOM"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "DamageLocationType")
@XmlEnum
public enum DamageLocationType {

    SIDE,
    TOP,
    END,
    BOTTOM;

    public String value() {
        return name();
    }

    public static DamageLocationType fromValue(String v) {
        return valueOf(v);
    }

}

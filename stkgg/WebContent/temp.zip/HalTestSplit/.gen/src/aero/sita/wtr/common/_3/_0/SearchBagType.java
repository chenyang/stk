
package aero.sita.wtr.common._3._0;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for SearchBagType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SearchBagType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="CreateDate" type="{http://sita.aero/wtr/common/3/0}DateRangeType" minOccurs="0"/>
 *         &lt;element name="ControlDate" type="{http://sita.aero/wtr/common/3/0}DateRangeType" minOccurs="0"/>
 *         &lt;element name="BagTag" type="{http://sita.aero/wtr/common/3/0}BagTagType" minOccurs="0"/>
 *         &lt;element name="Brand" type="{http://sita.aero/wtr/common/3/0}StringLength1to58" minOccurs="0"/>
 *         &lt;element name="ColorType" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="Color" type="{http://sita.aero/wtr/common/3/0}ColorCodeType" minOccurs="0"/>
 *                   &lt;element name="BagType" type="{http://sita.aero/wtr/common/3/0}BagTypeCodeType" minOccurs="0"/>
 *                   &lt;element name="BagDesc" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="MtrlElement" type="{http://sita.aero/wtr/common/3/0}BagMatrlType" minOccurs="0"/>
 *                             &lt;element name="OtherElement" type="{http://sita.aero/wtr/common/3/0}BagElmsType" maxOccurs="2" minOccurs="0"/>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="Contents" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="Content" type="{http://sita.aero/wtr/common/3/0}ContentType" maxOccurs="5"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="UniqueID" type="{http://sita.aero/wtr/common/3/0}UniqueIDType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SearchBagType", propOrder = {
    "createDate",
    "controlDate",
    "bagTag",
    "brand",
    "colorType",
    "contents",
    "uniqueID"
})
public class SearchBagType {

    @XmlElement(name = "CreateDate")
    protected DateRangeType createDate;
    @XmlElement(name = "ControlDate")
    protected DateRangeType controlDate;
    @XmlElement(name = "BagTag")
    protected BagTagType bagTag;
    @XmlElement(name = "Brand")
    protected String brand;
    @XmlElement(name = "ColorType")
    protected SearchBagType.ColorType colorType;
    @XmlElement(name = "Contents")
    protected SearchBagType.Contents contents;
    @XmlElement(name = "UniqueID")
    protected String uniqueID;

    /**
     * Gets the value of the createDate property.
     * 
     * @return
     *     possible object is
     *     {@link DateRangeType }
     *     
     */
    public DateRangeType getCreateDate() {
        return createDate;
    }

    /**
     * Sets the value of the createDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link DateRangeType }
     *     
     */
    public void setCreateDate(DateRangeType value) {
        this.createDate = value;
    }

    /**
     * Gets the value of the controlDate property.
     * 
     * @return
     *     possible object is
     *     {@link DateRangeType }
     *     
     */
    public DateRangeType getControlDate() {
        return controlDate;
    }

    /**
     * Sets the value of the controlDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link DateRangeType }
     *     
     */
    public void setControlDate(DateRangeType value) {
        this.controlDate = value;
    }

    /**
     * Gets the value of the bagTag property.
     * 
     * @return
     *     possible object is
     *     {@link BagTagType }
     *     
     */
    public BagTagType getBagTag() {
        return bagTag;
    }

    /**
     * Sets the value of the bagTag property.
     * 
     * @param value
     *     allowed object is
     *     {@link BagTagType }
     *     
     */
    public void setBagTag(BagTagType value) {
        this.bagTag = value;
    }

    /**
     * Gets the value of the brand property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBrand() {
        return brand;
    }

    /**
     * Sets the value of the brand property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBrand(String value) {
        this.brand = value;
    }

    /**
     * Gets the value of the colorType property.
     * 
     * @return
     *     possible object is
     *     {@link SearchBagType.ColorType }
     *     
     */
    public SearchBagType.ColorType getColorType() {
        return colorType;
    }

    /**
     * Sets the value of the colorType property.
     * 
     * @param value
     *     allowed object is
     *     {@link SearchBagType.ColorType }
     *     
     */
    public void setColorType(SearchBagType.ColorType value) {
        this.colorType = value;
    }

    /**
     * Gets the value of the contents property.
     * 
     * @return
     *     possible object is
     *     {@link SearchBagType.Contents }
     *     
     */
    public SearchBagType.Contents getContents() {
        return contents;
    }

    /**
     * Sets the value of the contents property.
     * 
     * @param value
     *     allowed object is
     *     {@link SearchBagType.Contents }
     *     
     */
    public void setContents(SearchBagType.Contents value) {
        this.contents = value;
    }

    /**
     * Gets the value of the uniqueID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUniqueID() {
        return uniqueID;
    }

    /**
     * Sets the value of the uniqueID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUniqueID(String value) {
        this.uniqueID = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="Color" type="{http://sita.aero/wtr/common/3/0}ColorCodeType" minOccurs="0"/>
     *         &lt;element name="BagType" type="{http://sita.aero/wtr/common/3/0}BagTypeCodeType" minOccurs="0"/>
     *         &lt;element name="BagDesc" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="MtrlElement" type="{http://sita.aero/wtr/common/3/0}BagMatrlType" minOccurs="0"/>
     *                   &lt;element name="OtherElement" type="{http://sita.aero/wtr/common/3/0}BagElmsType" maxOccurs="2" minOccurs="0"/>
     *                 &lt;/sequence>
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "color",
        "bagType",
        "bagDesc"
    })
    public static class ColorType {

        @XmlElement(name = "Color")
        protected ColorCodeType color;
        @XmlElement(name = "BagType")
        protected Integer bagType;
        @XmlElement(name = "BagDesc")
        protected SearchBagType.ColorType.BagDesc bagDesc;

        /**
         * Gets the value of the color property.
         * 
         * @return
         *     possible object is
         *     {@link ColorCodeType }
         *     
         */
        public ColorCodeType getColor() {
            return color;
        }

        /**
         * Sets the value of the color property.
         * 
         * @param value
         *     allowed object is
         *     {@link ColorCodeType }
         *     
         */
        public void setColor(ColorCodeType value) {
            this.color = value;
        }

        /**
         * Gets the value of the bagType property.
         * 
         * @return
         *     possible object is
         *     {@link Integer }
         *     
         */
        public Integer getBagType() {
            return bagType;
        }

        /**
         * Sets the value of the bagType property.
         * 
         * @param value
         *     allowed object is
         *     {@link Integer }
         *     
         */
        public void setBagType(Integer value) {
            this.bagType = value;
        }

        /**
         * Gets the value of the bagDesc property.
         * 
         * @return
         *     possible object is
         *     {@link SearchBagType.ColorType.BagDesc }
         *     
         */
        public SearchBagType.ColorType.BagDesc getBagDesc() {
            return bagDesc;
        }

        /**
         * Sets the value of the bagDesc property.
         * 
         * @param value
         *     allowed object is
         *     {@link SearchBagType.ColorType.BagDesc }
         *     
         */
        public void setBagDesc(SearchBagType.ColorType.BagDesc value) {
            this.bagDesc = value;
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="MtrlElement" type="{http://sita.aero/wtr/common/3/0}BagMatrlType" minOccurs="0"/>
         *         &lt;element name="OtherElement" type="{http://sita.aero/wtr/common/3/0}BagElmsType" maxOccurs="2" minOccurs="0"/>
         *       &lt;/sequence>
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "mtrlElement",
            "otherElement"
        })
        public static class BagDesc {

            @XmlElement(name = "MtrlElement")
            protected BagMatrlType mtrlElement;
            @XmlElement(name = "OtherElement")
            protected List<BagElmsType> otherElement;

            /**
             * Gets the value of the mtrlElement property.
             * 
             * @return
             *     possible object is
             *     {@link BagMatrlType }
             *     
             */
            public BagMatrlType getMtrlElement() {
                return mtrlElement;
            }

            /**
             * Sets the value of the mtrlElement property.
             * 
             * @param value
             *     allowed object is
             *     {@link BagMatrlType }
             *     
             */
            public void setMtrlElement(BagMatrlType value) {
                this.mtrlElement = value;
            }

            /**
             * Gets the value of the otherElement property.
             * 
             * <p>
             * This accessor method returns a reference to the live list,
             * not a snapshot. Therefore any modification you make to the
             * returned list will be present inside the JAXB object.
             * This is why there is not a <CODE>set</CODE> method for the otherElement property.
             * 
             * <p>
             * For example, to add a new item, do as follows:
             * <pre>
             *    getOtherElement().add(newItem);
             * </pre>
             * 
             * 
             * <p>
             * Objects of the following type(s) are allowed in the list
             * {@link BagElmsType }
             * 
             * 
             */
            public List<BagElmsType> getOtherElement() {
                if (otherElement == null) {
                    otherElement = new ArrayList<BagElmsType>();
                }
                return this.otherElement;
            }

        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="Content" type="{http://sita.aero/wtr/common/3/0}ContentType" maxOccurs="5"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "content"
    })
    public static class Contents {

        @XmlElement(name = "Content", required = true)
        protected List<ContentType> content;

        /**
         * Gets the value of the content property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the content property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getContent().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link ContentType }
         * 
         * 
         */
        public List<ContentType> getContent() {
            if (content == null) {
                content = new ArrayList<ContentType>();
            }
            return this.content;
        }

    }

}


package aero.sita.wtr.common._3._0;

import java.math.BigDecimal;
import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DamageClaimType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DamageClaimType">
 *   &lt;complexContent>
 *     &lt;extension base="{http://sita.aero/wtr/common/3/0}ClaimType">
 *       &lt;sequence>
 *         &lt;element name="LossReasonCode" type="{http://sita.aero/wtr/common/3/0}LossReasonCodeType"/>
 *         &lt;element name="ReplacementBag" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="RepairBag" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="ExcessValue" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;attGroup ref="{http://www.iata.org/IATA/2007/00}CurrencyAmountGroup"/>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DamageClaimType", propOrder = {
    "lossReasonCode",
    "replacementBag",
    "repairBag",
    "excessValue"
})
public class DamageClaimType
    extends ClaimType
{

    @XmlElement(name = "LossReasonCode")
    protected int lossReasonCode;
    @XmlElement(name = "ReplacementBag")
    protected Boolean replacementBag;
    @XmlElement(name = "RepairBag")
    protected Boolean repairBag;
    @XmlElement(name = "ExcessValue")
    protected DamageClaimType.ExcessValue excessValue;

    /**
     * Gets the value of the lossReasonCode property.
     * 
     */
    public int getLossReasonCode() {
        return lossReasonCode;
    }

    /**
     * Sets the value of the lossReasonCode property.
     * 
     */
    public void setLossReasonCode(int value) {
        this.lossReasonCode = value;
    }

    /**
     * Gets the value of the replacementBag property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isReplacementBag() {
        return replacementBag;
    }

    /**
     * Sets the value of the replacementBag property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setReplacementBag(Boolean value) {
        this.replacementBag = value;
    }

    /**
     * Gets the value of the repairBag property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isRepairBag() {
        return repairBag;
    }

    /**
     * Sets the value of the repairBag property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setRepairBag(Boolean value) {
        this.repairBag = value;
    }

    /**
     * Gets the value of the excessValue property.
     * 
     * @return
     *     possible object is
     *     {@link DamageClaimType.ExcessValue }
     *     
     */
    public DamageClaimType.ExcessValue getExcessValue() {
        return excessValue;
    }

    /**
     * Sets the value of the excessValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link DamageClaimType.ExcessValue }
     *     
     */
    public void setExcessValue(DamageClaimType.ExcessValue value) {
        this.excessValue = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;attGroup ref="{http://www.iata.org/IATA/2007/00}CurrencyAmountGroup"/>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "")
    public static class ExcessValue {

        @XmlAttribute(name = "Amount")
        protected BigDecimal amount;
        @XmlAttribute(name = "CurrencyCode")
        protected String currencyCode;
        @XmlAttribute(name = "DecimalPlaces")
        @XmlSchemaType(name = "nonNegativeInteger")
        protected BigInteger decimalPlaces;

        /**
         * Gets the value of the amount property.
         * 
         * @return
         *     possible object is
         *     {@link BigDecimal }
         *     
         */
        public BigDecimal getAmount() {
            return amount;
        }

        /**
         * Sets the value of the amount property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigDecimal }
         *     
         */
        public void setAmount(BigDecimal value) {
            this.amount = value;
        }

        /**
         * Gets the value of the currencyCode property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getCurrencyCode() {
            return currencyCode;
        }

        /**
         * Sets the value of the currencyCode property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setCurrencyCode(String value) {
            this.currencyCode = value;
        }

        /**
         * Gets the value of the decimalPlaces property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getDecimalPlaces() {
            return decimalPlaces;
        }

        /**
         * Sets the value of the decimalPlaces property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setDecimalPlaces(BigInteger value) {
            this.decimalPlaces = value;
        }

    }

}

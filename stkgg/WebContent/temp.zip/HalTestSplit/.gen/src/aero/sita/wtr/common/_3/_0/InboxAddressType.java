
package aero.sita.wtr.common._3._0;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * XF - Inbox Address(Action file address)
 * 
 * <p>Java class for InboxAddressType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="InboxAddressType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="StationAirline" type="{http://sita.aero/wtr/common/3/0}StationAirlineType"/>
 *         &lt;element name="Area" type="{http://sita.aero/wtr/common/3/0}InboxAreaType"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "InboxAddressType", propOrder = {
    "stationAirline",
    "area"
})
public class InboxAddressType {

    @XmlElement(name = "StationAirline", required = true)
    protected StationAirlineType stationAirline;
    @XmlElement(name = "Area", required = true)
    protected InboxAreaType area;

    /**
     * Gets the value of the stationAirline property.
     * 
     * @return
     *     possible object is
     *     {@link StationAirlineType }
     *     
     */
    public StationAirlineType getStationAirline() {
        return stationAirline;
    }

    /**
     * Sets the value of the stationAirline property.
     * 
     * @param value
     *     allowed object is
     *     {@link StationAirlineType }
     *     
     */
    public void setStationAirline(StationAirlineType value) {
        this.stationAirline = value;
    }

    /**
     * Gets the value of the area property.
     * 
     * @return
     *     possible object is
     *     {@link InboxAreaType }
     *     
     */
    public InboxAreaType getArea() {
        return area;
    }

    /**
     * Sets the value of the area property.
     * 
     * @param value
     *     allowed object is
     *     {@link InboxAreaType }
     *     
     */
    public void setArea(InboxAreaType value) {
        this.area = value;
    }

}

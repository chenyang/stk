
package aero.sita.wtr.common._3._0;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the aero.sita.wtr.common._3._0 package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: aero.sita.wtr.common._3._0
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link DelayedBagIDType.BagID }
     * 
     */
    public DelayedBagIDType.BagID createDelayedBagIDTypeBagID() {
        return new DelayedBagIDType.BagID();
    }

    /**
     * Create an instance of {@link RushBagGroupType.RushFlights.FlightDateOrARNK }
     * 
     */
    public RushBagGroupType.RushFlights.FlightDateOrARNK createRushBagGroupTypeRushFlightsFlightDateOrARNK() {
        return new RushBagGroupType.RushFlights.FlightDateOrARNK();
    }

    /**
     * Create an instance of {@link ClaimAmendType.PartnerCode }
     * 
     */
    public ClaimAmendType.PartnerCode createClaimAmendTypePartnerCode() {
        return new ClaimAmendType.PartnerCode();
    }

    /**
     * Create an instance of {@link BagRecordSummaryType.OriginalBags }
     * 
     */
    public BagRecordSummaryType.OriginalBags createBagRecordSummaryTypeOriginalBags() {
        return new BagRecordSummaryType.OriginalBags();
    }

    /**
     * Create an instance of {@link DamagedBagGroupAmendType.ContentsDamageDesc }
     * 
     */
    public DamagedBagGroupAmendType.ContentsDamageDesc createDamagedBagGroupAmendTypeContentsDamageDesc() {
        return new DamagedBagGroupAmendType.ContentsDamageDesc();
    }

    /**
     * Create an instance of {@link OnHandBagType.Itinerary }
     * 
     */
    public OnHandBagType.Itinerary createOnHandBagTypeItinerary() {
        return new OnHandBagType.Itinerary();
    }

    /**
     * Create an instance of {@link FoundItemType.AgentID }
     * 
     */
    public FoundItemType.AgentID createFoundItemTypeAgentID() {
        return new FoundItemType.AgentID();
    }

    /**
     * Create an instance of {@link DelayedBagGroupAmendType.BaggageItinerary }
     * 
     */
    public DelayedBagGroupAmendType.BaggageItinerary createDelayedBagGroupAmendTypeBaggageItinerary() {
        return new DelayedBagGroupAmendType.BaggageItinerary();
    }

    /**
     * Create an instance of {@link BagRecordSummaryType }
     * 
     */
    public BagRecordSummaryType createBagRecordSummaryType() {
        return new BagRecordSummaryType();
    }

    /**
     * Create an instance of {@link DiaryInfoType }
     * 
     */
    public DiaryInfoType createDiaryInfoType() {
        return new DiaryInfoType();
    }

    /**
     * Create an instance of {@link DamagedBagGroupAmendType }
     * 
     */
    public DamagedBagGroupAmendType createDamagedBagGroupAmendType() {
        return new DamagedBagGroupAmendType();
    }

    /**
     * Create an instance of {@link BagTagType }
     * 
     */
    public BagTagType createBagTagType() {
        return new BagTagType();
    }

    /**
     * Create an instance of {@link FoundItemType.SupplimentalInfo }
     * 
     */
    public FoundItemType.SupplimentalInfo createFoundItemTypeSupplimentalInfo() {
        return new FoundItemType.SupplimentalInfo();
    }

    /**
     * Create an instance of {@link BagType }
     * 
     */
    public BagType createBagType() {
        return new BagType();
    }

    /**
     * Create an instance of {@link StringLength1To58AmendType }
     * 
     */
    public StringLength1To58AmendType createStringLength1To58AmendType() {
        return new StringLength1To58AmendType();
    }

    /**
     * Create an instance of {@link ClaimType.ClaimAmout }
     * 
     */
    public ClaimType.ClaimAmout createClaimTypeClaimAmout() {
        return new ClaimType.ClaimAmout();
    }

    /**
     * Create an instance of {@link StringLength0To58AmendType }
     * 
     */
    public StringLength0To58AmendType createStringLength0To58AmendType() {
        return new StringLength0To58AmendType();
    }

    /**
     * Create an instance of {@link ClaimAmendType.FaultStationCode }
     * 
     */
    public ClaimAmendType.FaultStationCode createClaimAmendTypeFaultStationCode() {
        return new ClaimAmendType.FaultStationCode();
    }

    /**
     * Create an instance of {@link OnHandBagAmendType.ContentsGender }
     * 
     */
    public OnHandBagAmendType.ContentsGender createOnHandBagAmendTypeContentsGender() {
        return new OnHandBagAmendType.ContentsGender();
    }

    /**
     * Create an instance of {@link OriginDestinationType }
     * 
     */
    public OriginDestinationType createOriginDestinationType() {
        return new OriginDestinationType();
    }

    /**
     * Create an instance of {@link DelayedClaimAmendType }
     * 
     */
    public DelayedClaimAmendType createDelayedClaimAmendType() {
        return new DelayedClaimAmendType();
    }

    /**
     * Create an instance of {@link DelayedClaimType.ToiletKits }
     * 
     */
    public DelayedClaimType.ToiletKits createDelayedClaimTypeToiletKits() {
        return new DelayedClaimType.ToiletKits();
    }

    /**
     * Create an instance of {@link ClaimAmendType.Insurance }
     * 
     */
    public ClaimAmendType.Insurance createClaimAmendTypeInsurance() {
        return new ClaimAmendType.Insurance();
    }

    /**
     * Create an instance of {@link DelayedClaimAmendType.LossReasonCode }
     * 
     */
    public DelayedClaimAmendType.LossReasonCode createDelayedClaimAmendTypeLossReasonCode() {
        return new DelayedClaimAmendType.LossReasonCode();
    }

    /**
     * Create an instance of {@link PassengerAmendType.Initials }
     * 
     */
    public PassengerAmendType.Initials createPassengerAmendTypeInitials() {
        return new PassengerAmendType.Initials();
    }

    /**
     * Create an instance of {@link PassengerAmendType.PassportInfo }
     * 
     */
    public PassengerAmendType.PassportInfo createPassengerAmendTypePassportInfo() {
        return new PassengerAmendType.PassportInfo();
    }

    /**
     * Create an instance of {@link PassengerItineraryAmendType.Itinerary.FlightSegments }
     * 
     */
    public PassengerItineraryAmendType.Itinerary.FlightSegments createPassengerItineraryAmendTypeItineraryFlightSegments() {
        return new PassengerItineraryAmendType.Itinerary.FlightSegments();
    }

    /**
     * Create an instance of {@link RushBagGroupType.RushBags }
     * 
     */
    public RushBagGroupType.RushBags createRushBagGroupTypeRushBags() {
        return new RushBagGroupType.RushBags();
    }

    /**
     * Create an instance of {@link BagRecordSummaryType.Initials }
     * 
     */
    public BagRecordSummaryType.Initials createBagRecordSummaryTypeInitials() {
        return new BagRecordSummaryType.Initials();
    }

    /**
     * Create an instance of {@link DamagedBagAmendType.BagDetails }
     * 
     */
    public DamagedBagAmendType.BagDetails createDamagedBagAmendTypeBagDetails() {
        return new DamagedBagAmendType.BagDetails();
    }

    /**
     * Create an instance of {@link DeliveryType.LocalDlvInfo }
     * 
     */
    public DeliveryType.LocalDlvInfo createDeliveryTypeLocalDlvInfo() {
        return new DeliveryType.LocalDlvInfo();
    }

    /**
     * Create an instance of {@link ClaimAmendType.MissingBags }
     * 
     */
    public ClaimAmendType.MissingBags createClaimAmendTypeMissingBags() {
        return new ClaimAmendType.MissingBags();
    }

    /**
     * Create an instance of {@link ContactInfoType.TempAddress }
     * 
     */
    public ContactInfoType.TempAddress createContactInfoTypeTempAddress() {
        return new ContactInfoType.TempAddress();
    }

    /**
     * Create an instance of {@link SearchNameType }
     * 
     */
    public SearchNameType createSearchNameType() {
        return new SearchNameType();
    }

    /**
     * Create an instance of {@link AdditionalInfoType }
     * 
     */
    public AdditionalInfoType createAdditionalInfoType() {
        return new AdditionalInfoType();
    }

    /**
     * Create an instance of {@link PassengerItineraryAmendType.PooledTktNumber }
     * 
     */
    public PassengerItineraryAmendType.PooledTktNumber createPassengerItineraryAmendTypePooledTktNumber() {
        return new PassengerItineraryAmendType.PooledTktNumber();
    }

    /**
     * Create an instance of {@link OnHandBagAmendType.BagPhones.Phone }
     * 
     */
    public OnHandBagAmendType.BagPhones.Phone createOnHandBagAmendTypeBagPhonesPhone() {
        return new OnHandBagAmendType.BagPhones.Phone();
    }

    /**
     * Create an instance of {@link OnHandBagType.Remarks }
     * 
     */
    public OnHandBagType.Remarks createOnHandBagTypeRemarks() {
        return new OnHandBagType.Remarks();
    }

    /**
     * Create an instance of {@link InboxAddressType }
     * 
     */
    public InboxAddressType createInboxAddressType() {
        return new InboxAddressType();
    }

    /**
     * Create an instance of {@link DelayedClaimAmendType.ExcessValue }
     * 
     */
    public DelayedClaimAmendType.ExcessValue createDelayedClaimAmendTypeExcessValue() {
        return new DelayedClaimAmendType.ExcessValue();
    }

    /**
     * Create an instance of {@link BagRecordSummaryType.Names }
     * 
     */
    public BagRecordSummaryType.Names createBagRecordSummaryTypeNames() {
        return new BagRecordSummaryType.Names();
    }

    /**
     * Create an instance of {@link RushBagGroupType.RushDestinations }
     * 
     */
    public RushBagGroupType.RushDestinations createRushBagGroupTypeRushDestinations() {
        return new RushBagGroupType.RushDestinations();
    }

    /**
     * Create an instance of {@link ContactInfoAmendType.PermPhones }
     * 
     */
    public ContactInfoAmendType.PermPhones createContactInfoAmendTypePermPhones() {
        return new ContactInfoAmendType.PermPhones();
    }

    /**
     * Create an instance of {@link DelayedBagGroupType.BagTagDestinations }
     * 
     */
    public DelayedBagGroupType.BagTagDestinations createDelayedBagGroupTypeBagTagDestinations() {
        return new DelayedBagGroupType.BagTagDestinations();
    }

    /**
     * Create an instance of {@link AdditionalInfoAmendType.SupplimentalInfo }
     * 
     */
    public AdditionalInfoAmendType.SupplimentalInfo createAdditionalInfoAmendTypeSupplimentalInfo() {
        return new AdditionalInfoAmendType.SupplimentalInfo();
    }

    /**
     * Create an instance of {@link ContactInfoAmendType.Country }
     * 
     */
    public ContactInfoAmendType.Country createContactInfoAmendTypeCountry() {
        return new ContactInfoAmendType.Country();
    }

    /**
     * Create an instance of {@link DamageClaimAmendType }
     * 
     */
    public DamageClaimAmendType createDamageClaimAmendType() {
        return new DamageClaimAmendType();
    }

    /**
     * Create an instance of {@link DamageClaimAmendType.LossReasonCode }
     * 
     */
    public DamageClaimAmendType.LossReasonCode createDamageClaimAmendTypeLossReasonCode() {
        return new DamageClaimAmendType.LossReasonCode();
    }

    /**
     * Create an instance of {@link BagGroupAmendType.BagPhones }
     * 
     */
    public BagGroupAmendType.BagPhones createBagGroupAmendTypeBagPhones() {
        return new BagGroupAmendType.BagPhones();
    }

    /**
     * Create an instance of {@link ContactInfoType.TempPhones }
     * 
     */
    public ContactInfoType.TempPhones createContactInfoTypeTempPhones() {
        return new ContactInfoType.TempPhones();
    }

    /**
     * Create an instance of {@link BagAmendType.BagDelivery.Status.TrackingUpdate }
     * 
     */
    public BagAmendType.BagDelivery.Status.TrackingUpdate createBagAmendTypeBagDeliveryStatusTrackingUpdate() {
        return new BagAmendType.BagDelivery.Status.TrackingUpdate();
    }

    /**
     * Create an instance of {@link SearchBagType.ColorType.BagDesc }
     * 
     */
    public SearchBagType.ColorType.BagDesc createSearchBagTypeColorTypeBagDesc() {
        return new SearchBagType.ColorType.BagDesc();
    }

    /**
     * Create an instance of {@link DelayedBagGroupAmendType.DelayedBags }
     * 
     */
    public DelayedBagGroupAmendType.DelayedBags createDelayedBagGroupAmendTypeDelayedBags() {
        return new DelayedBagGroupAmendType.DelayedBags();
    }

    /**
     * Create an instance of {@link InboxMessageSearchType.MessageRange }
     * 
     */
    public InboxMessageSearchType.MessageRange createInboxMessageSearchTypeMessageRange() {
        return new InboxMessageSearchType.MessageRange();
    }

    /**
     * Create an instance of {@link RushBagType }
     * 
     */
    public RushBagType createRushBagType() {
        return new RushBagType();
    }

    /**
     * Create an instance of {@link DelayedBagAmendType }
     * 
     */
    public DelayedBagAmendType createDelayedBagAmendType() {
        return new DelayedBagAmendType();
    }

    /**
     * Create an instance of {@link StringLength0To205AmendType }
     * 
     */
    public StringLength0To205AmendType createStringLength0To205AmendType() {
        return new StringLength0To205AmendType();
    }

    /**
     * Create an instance of {@link DelayedBagGroupAmendType.BagTagDestinations }
     * 
     */
    public DelayedBagGroupAmendType.BagTagDestinations createDelayedBagGroupAmendTypeBagTagDestinations() {
        return new DelayedBagGroupAmendType.BagTagDestinations();
    }

    /**
     * Create an instance of {@link FoundItemType.AdditionalInfo }
     * 
     */
    public FoundItemType.AdditionalInfo createFoundItemTypeAdditionalInfo() {
        return new FoundItemType.AdditionalInfo();
    }

    /**
     * Create an instance of {@link ContactInfoType.CellPhones }
     * 
     */
    public ContactInfoType.CellPhones createContactInfoTypeCellPhones() {
        return new ContactInfoType.CellPhones();
    }

    /**
     * Create an instance of {@link OnHandBagAmendType }
     * 
     */
    public OnHandBagAmendType createOnHandBagAmendType() {
        return new OnHandBagAmendType();
    }

    /**
     * Create an instance of {@link DamagedBagType.DamageTypes }
     * 
     */
    public DamagedBagType.DamageTypes createDamagedBagTypeDamageTypes() {
        return new DamagedBagType.DamageTypes();
    }

    /**
     * Create an instance of {@link RushBagGroupType.Names }
     * 
     */
    public RushBagGroupType.Names createRushBagGroupTypeNames() {
        return new RushBagGroupType.Names();
    }

    /**
     * Create an instance of {@link ContactInfoAmendType.State }
     * 
     */
    public ContactInfoAmendType.State createContactInfoAmendTypeState() {
        return new ContactInfoAmendType.State();
    }

    /**
     * Create an instance of {@link BagGroupType.BagPhones }
     * 
     */
    public BagGroupType.BagPhones createBagGroupTypeBagPhones() {
        return new BagGroupType.BagPhones();
    }

    /**
     * Create an instance of {@link InitialType }
     * 
     */
    public InitialType createInitialType() {
        return new InitialType();
    }

    /**
     * Create an instance of {@link OnHandBagTracingAmendType.NewFlights }
     * 
     */
    public OnHandBagTracingAmendType.NewFlights createOnHandBagTracingAmendTypeNewFlights() {
        return new OnHandBagTracingAmendType.NewFlights();
    }

    /**
     * Create an instance of {@link RushBagGroupType.RushFlights }
     * 
     */
    public RushBagGroupType.RushFlights createRushBagGroupTypeRushFlights() {
        return new RushBagGroupType.RushFlights();
    }

    /**
     * Create an instance of {@link FoundItemType.DisposalDate }
     * 
     */
    public FoundItemType.DisposalDate createFoundItemTypeDisposalDate() {
        return new FoundItemType.DisposalDate();
    }

    /**
     * Create an instance of {@link PassengerItineraryAmendType }
     * 
     */
    public PassengerItineraryAmendType createPassengerItineraryAmendType() {
        return new PassengerItineraryAmendType();
    }

    /**
     * Create an instance of {@link DelayedBagType }
     * 
     */
    public DelayedBagType createDelayedBagType() {
        return new DelayedBagType();
    }

    /**
     * Create an instance of {@link WTRGenericRQType }
     * 
     */
    public WTRGenericRQType createWTRGenericRQType() {
        return new WTRGenericRQType();
    }

    /**
     * Create an instance of {@link DelayedBagType.Remarks }
     * 
     */
    public DelayedBagType.Remarks createDelayedBagTypeRemarks() {
        return new DelayedBagType.Remarks();
    }

    /**
     * Create an instance of {@link ClaimAmendType.LiabilityTag }
     * 
     */
    public ClaimAmendType.LiabilityTag createClaimAmendTypeLiabilityTag() {
        return new ClaimAmendType.LiabilityTag();
    }

    /**
     * Create an instance of {@link SearchBagType.ColorType }
     * 
     */
    public SearchBagType.ColorType createSearchBagTypeColorType() {
        return new SearchBagType.ColorType();
    }

    /**
     * Create an instance of {@link DelayedClaimType }
     * 
     */
    public DelayedClaimType createDelayedClaimType() {
        return new DelayedClaimType();
    }

    /**
     * Create an instance of {@link ContactInfoAmendType.Faxes }
     * 
     */
    public ContactInfoAmendType.Faxes createContactInfoAmendTypeFaxes() {
        return new ContactInfoAmendType.Faxes();
    }

    /**
     * Create an instance of {@link OnHandBagTracingType.NewRouting }
     * 
     */
    public OnHandBagTracingType.NewRouting createOnHandBagTracingTypeNewRouting() {
        return new OnHandBagTracingType.NewRouting();
    }

    /**
     * Create an instance of {@link PassengerType }
     * 
     */
    public PassengerType createPassengerType() {
        return new PassengerType();
    }

    /**
     * Create an instance of {@link OnHandBagTracingAmendType.NewRouting }
     * 
     */
    public OnHandBagTracingAmendType.NewRouting createOnHandBagTracingAmendTypeNewRouting() {
        return new OnHandBagTracingAmendType.NewRouting();
    }

    /**
     * Create an instance of {@link DiaryInfoType.CrossReferenceRecords }
     * 
     */
    public DiaryInfoType.CrossReferenceRecords createDiaryInfoTypeCrossReferenceRecords() {
        return new DiaryInfoType.CrossReferenceRecords();
    }

    /**
     * Create an instance of {@link DelayedBagGroupAmendType.ExcessBaggage }
     * 
     */
    public DelayedBagGroupAmendType.ExcessBaggage createDelayedBagGroupAmendTypeExcessBaggage() {
        return new DelayedBagGroupAmendType.ExcessBaggage();
    }

    /**
     * Create an instance of {@link FlightOptionalDateOrARNKType }
     * 
     */
    public FlightOptionalDateOrARNKType createFlightOptionalDateOrARNKType() {
        return new FlightOptionalDateOrARNKType();
    }

    /**
     * Create an instance of {@link BagSummaryType.ColorType }
     * 
     */
    public BagSummaryType.ColorType createBagSummaryTypeColorType() {
        return new BagSummaryType.ColorType();
    }

    /**
     * Create an instance of {@link DamagedBagGroupAmendType.DamagedBags }
     * 
     */
    public DamagedBagGroupAmendType.DamagedBags createDamagedBagGroupAmendTypeDamagedBags() {
        return new DamagedBagGroupAmendType.DamagedBags();
    }

    /**
     * Create an instance of {@link ClaimType.PassengerPayments }
     * 
     */
    public ClaimType.PassengerPayments createClaimTypePassengerPayments() {
        return new ClaimType.PassengerPayments();
    }

    /**
     * Create an instance of {@link DeliveryAmendType }
     * 
     */
    public DeliveryAmendType createDeliveryAmendType() {
        return new DeliveryAmendType();
    }

    /**
     * Create an instance of {@link PassengerAmendType.Names.Name }
     * 
     */
    public PassengerAmendType.Names.Name createPassengerAmendTypeNamesName() {
        return new PassengerAmendType.Names.Name();
    }

    /**
     * Create an instance of {@link BagAmendType.BagDelivery.BagReceived }
     * 
     */
    public BagAmendType.BagDelivery.BagReceived createBagAmendTypeBagDeliveryBagReceived() {
        return new BagAmendType.BagDelivery.BagReceived();
    }

    /**
     * Create an instance of {@link ClaimAmendType.DateNotified }
     * 
     */
    public ClaimAmendType.DateNotified createClaimAmendTypeDateNotified() {
        return new ClaimAmendType.DateNotified();
    }

    /**
     * Create an instance of {@link AdditionalInfoType.SupplimentalInfo }
     * 
     */
    public AdditionalInfoType.SupplimentalInfo createAdditionalInfoTypeSupplimentalInfo() {
        return new AdditionalInfoType.SupplimentalInfo();
    }

    /**
     * Create an instance of {@link DelayedBagRecordType }
     * 
     */
    public DelayedBagRecordType createDelayedBagRecordType() {
        return new DelayedBagRecordType();
    }

    /**
     * Create an instance of {@link HandledStationType }
     * 
     */
    public HandledStationType createHandledStationType() {
        return new HandledStationType();
    }

    /**
     * Create an instance of {@link PassengerItineraryAmendType.Itinerary }
     * 
     */
    public PassengerItineraryAmendType.Itinerary createPassengerItineraryAmendTypeItinerary() {
        return new PassengerItineraryAmendType.Itinerary();
    }

    /**
     * Create an instance of {@link WTRAddressType }
     * 
     */
    public WTRAddressType createWTRAddressType() {
        return new WTRAddressType();
    }

    /**
     * Create an instance of {@link PropertyType.Values }
     * 
     */
    public PropertyType.Values createPropertyTypeValues() {
        return new PropertyType.Values();
    }

    /**
     * Create an instance of {@link RushBagRecordType }
     * 
     */
    public RushBagRecordType createRushBagRecordType() {
        return new RushBagRecordType();
    }

    /**
     * Create an instance of {@link BagType.BrandInfo }
     * 
     */
    public BagType.BrandInfo createBagTypeBrandInfo() {
        return new BagType.BrandInfo();
    }

    /**
     * Create an instance of {@link ColorTypeDescAmendType }
     * 
     */
    public ColorTypeDescAmendType createColorTypeDescAmendType() {
        return new ColorTypeDescAmendType();
    }

    /**
     * Create an instance of {@link AdditionalInfoAmendType.UserComments }
     * 
     */
    public AdditionalInfoAmendType.UserComments createAdditionalInfoAmendTypeUserComments() {
        return new AdditionalInfoAmendType.UserComments();
    }

    /**
     * Create an instance of {@link DamagedBagGroupAmendType.DamagedBags.DamagedBag }
     * 
     */
    public DamagedBagGroupAmendType.DamagedBags.DamagedBag createDamagedBagGroupAmendTypeDamagedBagsDamagedBag() {
        return new DamagedBagGroupAmendType.DamagedBags.DamagedBag();
    }

    /**
     * Create an instance of {@link BagType.UniqueID }
     * 
     */
    public BagType.UniqueID createBagTypeUniqueID() {
        return new BagType.UniqueID();
    }

    /**
     * Create an instance of {@link InboxMessageSearchType.MessageRange.Range }
     * 
     */
    public InboxMessageSearchType.MessageRange.Range createInboxMessageSearchTypeMessageRangeRange() {
        return new InboxMessageSearchType.MessageRange.Range();
    }

    /**
     * Create an instance of {@link BagAmendType.BrandInfo }
     * 
     */
    public BagAmendType.BrandInfo createBagAmendTypeBrandInfo() {
        return new BagAmendType.BrandInfo();
    }

    /**
     * Create an instance of {@link DamagedBagType }
     * 
     */
    public DamagedBagType createDamagedBagType() {
        return new DamagedBagType();
    }

    /**
     * Create an instance of {@link RecordIdentifierType }
     * 
     */
    public RecordIdentifierType createRecordIdentifierType() {
        return new RecordIdentifierType();
    }

    /**
     * Create an instance of {@link PassengerAmendType.TicketNumber }
     * 
     */
    public PassengerAmendType.TicketNumber createPassengerAmendTypeTicketNumber() {
        return new PassengerAmendType.TicketNumber();
    }

    /**
     * Create an instance of {@link OnHandBagTracingType }
     * 
     */
    public OnHandBagTracingType createOnHandBagTracingType() {
        return new OnHandBagTracingType();
    }

    /**
     * Create an instance of {@link DelayedBagAmendType.BagDetails }
     * 
     */
    public DelayedBagAmendType.BagDetails createDelayedBagAmendTypeBagDetails() {
        return new DelayedBagAmendType.BagDetails();
    }

    /**
     * Create an instance of {@link BagAmendType.BagDelivery.Status }
     * 
     */
    public BagAmendType.BagDelivery.Status createBagAmendTypeBagDeliveryStatus() {
        return new BagAmendType.BagDelivery.Status();
    }

    /**
     * Create an instance of {@link ARNKSegmentType }
     * 
     */
    public ARNKSegmentType createARNKSegmentType() {
        return new ARNKSegmentType();
    }

    /**
     * Create an instance of {@link ClaimType.PartnerCode }
     * 
     */
    public ClaimType.PartnerCode createClaimTypePartnerCode() {
        return new ClaimType.PartnerCode();
    }

    /**
     * Create an instance of {@link AdditionalInfoAmendType.DeliveryInfo }
     * 
     */
    public AdditionalInfoAmendType.DeliveryInfo createAdditionalInfoAmendTypeDeliveryInfo() {
        return new AdditionalInfoAmendType.DeliveryInfo();
    }

    /**
     * Create an instance of {@link DamagedBagGroupType.DamagedBags }
     * 
     */
    public DamagedBagGroupType.DamagedBags createDamagedBagGroupTypeDamagedBags() {
        return new DamagedBagGroupType.DamagedBags();
    }

    /**
     * Create an instance of {@link ClaimAmendType.FaultTerminal }
     * 
     */
    public ClaimAmendType.FaultTerminal createClaimAmendTypeFaultTerminal() {
        return new ClaimAmendType.FaultTerminal();
    }

    /**
     * Create an instance of {@link PhoneAmendType }
     * 
     */
    public PhoneAmendType createPhoneAmendType() {
        return new PhoneAmendType();
    }

    /**
     * Create an instance of {@link DelayedBagGroupAmendType }
     * 
     */
    public DelayedBagGroupAmendType createDelayedBagGroupAmendType() {
        return new DelayedBagGroupAmendType();
    }

    /**
     * Create an instance of {@link HandledPageType.Handling }
     * 
     */
    public HandledPageType.Handling createHandledPageTypeHandling() {
        return new HandledPageType.Handling();
    }

    /**
     * Create an instance of {@link BagAmendType.BagDelivery.BagReceivedDate }
     * 
     */
    public BagAmendType.BagDelivery.BagReceivedDate createBagAmendTypeBagDeliveryBagReceivedDate() {
        return new BagAmendType.BagDelivery.BagReceivedDate();
    }

    /**
     * Create an instance of {@link WTRGenericPageRQType }
     * 
     */
    public WTRGenericPageRQType createWTRGenericPageRQType() {
        return new WTRGenericPageRQType();
    }

    /**
     * Create an instance of {@link PassengerPaymentType }
     * 
     */
    public PassengerPaymentType createPassengerPaymentType() {
        return new PassengerPaymentType();
    }

    /**
     * Create an instance of {@link RushBagGroupTypeTracing }
     * 
     */
    public RushBagGroupTypeTracing createRushBagGroupTypeTracing() {
        return new RushBagGroupTypeTracing();
    }

    /**
     * Create an instance of {@link ReportStationAirlineType }
     * 
     */
    public ReportStationAirlineType createReportStationAirlineType() {
        return new ReportStationAirlineType();
    }

    /**
     * Create an instance of {@link FlightDateType }
     * 
     */
    public FlightDateType createFlightDateType() {
        return new FlightDateType();
    }

    /**
     * Create an instance of {@link BagDescType }
     * 
     */
    public BagDescType createBagDescType() {
        return new BagDescType();
    }

    /**
     * Create an instance of {@link FlightOptionalDateType }
     * 
     */
    public FlightOptionalDateType createFlightOptionalDateType() {
        return new FlightOptionalDateType();
    }

    /**
     * Create an instance of {@link AdditionalInfoType.MiscInfo }
     * 
     */
    public AdditionalInfoType.MiscInfo createAdditionalInfoTypeMiscInfo() {
        return new AdditionalInfoType.MiscInfo();
    }

    /**
     * Create an instance of {@link BagTagAmendType }
     * 
     */
    public BagTagAmendType createBagTagAmendType() {
        return new BagTagAmendType();
    }

    /**
     * Create an instance of {@link RushBagGroupType.OriginalFlights }
     * 
     */
    public RushBagGroupType.OriginalFlights createRushBagGroupTypeOriginalFlights() {
        return new RushBagGroupType.OriginalFlights();
    }

    /**
     * Create an instance of {@link ContentType }
     * 
     */
    public ContentType createContentType() {
        return new ContentType();
    }

    /**
     * Create an instance of {@link BagAmendType.LockCode }
     * 
     */
    public BagAmendType.LockCode createBagAmendTypeLockCode() {
        return new BagAmendType.LockCode();
    }

    /**
     * Create an instance of {@link BagAmendType.BagDelivery }
     * 
     */
    public BagAmendType.BagDelivery createBagAmendTypeBagDelivery() {
        return new BagAmendType.BagDelivery();
    }

    /**
     * Create an instance of {@link ClaimType.CostRemarks }
     * 
     */
    public ClaimType.CostRemarks createClaimTypeCostRemarks() {
        return new ClaimType.CostRemarks();
    }

    /**
     * Create an instance of {@link DelayedClaimAmendType.TracingFinalized }
     * 
     */
    public DelayedClaimAmendType.TracingFinalized createDelayedClaimAmendTypeTracingFinalized() {
        return new DelayedClaimAmendType.TracingFinalized();
    }

    /**
     * Create an instance of {@link StationAirlineType }
     * 
     */
    public StationAirlineType createStationAirlineType() {
        return new StationAirlineType();
    }

    /**
     * Create an instance of {@link AmountType }
     * 
     */
    public AmountType createAmountType() {
        return new AmountType();
    }

    /**
     * Create an instance of {@link RushBagGroupTypeTracing.NewRouting }
     * 
     */
    public RushBagGroupTypeTracing.NewRouting createRushBagGroupTypeTracingNewRouting() {
        return new RushBagGroupTypeTracing.NewRouting();
    }

    /**
     * Create an instance of {@link BagDeliveryType }
     * 
     */
    public BagDeliveryType createBagDeliveryType() {
        return new BagDeliveryType();
    }

    /**
     * Create an instance of {@link ContactInfoType }
     * 
     */
    public ContactInfoType createContactInfoType() {
        return new ContactInfoType();
    }

    /**
     * Create an instance of {@link OnHandBagType }
     * 
     */
    public OnHandBagType createOnHandBagType() {
        return new OnHandBagType();
    }

    /**
     * Create an instance of {@link NameType }
     * 
     */
    public NameType createNameType() {
        return new NameType();
    }

    /**
     * Create an instance of {@link AdditionalInfoType.UserComments }
     * 
     */
    public AdditionalInfoType.UserComments createAdditionalInfoTypeUserComments() {
        return new AdditionalInfoType.UserComments();
    }

    /**
     * Create an instance of {@link OnHandBagAmendType.Itinerary }
     * 
     */
    public OnHandBagAmendType.Itinerary createOnHandBagAmendTypeItinerary() {
        return new OnHandBagAmendType.Itinerary();
    }

    /**
     * Create an instance of {@link RushBagGroupTypeTracing.OriginalRouting }
     * 
     */
    public RushBagGroupTypeTracing.OriginalRouting createRushBagGroupTypeTracingOriginalRouting() {
        return new RushBagGroupTypeTracing.OriginalRouting();
    }

    /**
     * Create an instance of {@link RushBagGroupTypeTracing.NewFlights }
     * 
     */
    public RushBagGroupTypeTracing.NewFlights createRushBagGroupTypeTracingNewFlights() {
        return new RushBagGroupTypeTracing.NewFlights();
    }

    /**
     * Create an instance of {@link DeliveryAmendType.DeliveryWeight }
     * 
     */
    public DeliveryAmendType.DeliveryWeight createDeliveryAmendTypeDeliveryWeight() {
        return new DeliveryAmendType.DeliveryWeight();
    }

    /**
     * Create an instance of {@link PropertyType }
     * 
     */
    public PropertyType createPropertyType() {
        return new PropertyType();
    }

    /**
     * Create an instance of {@link AmendBagDescType }
     * 
     */
    public AmendBagDescType createAmendBagDescType() {
        return new AmendBagDescType();
    }

    /**
     * Create an instance of {@link DamagedBagGroupType.BaggageItinerary }
     * 
     */
    public DamagedBagGroupType.BaggageItinerary createDamagedBagGroupTypeBaggageItinerary() {
        return new DamagedBagGroupType.BaggageItinerary();
    }

    /**
     * Create an instance of {@link OptionalDateType }
     * 
     */
    public OptionalDateType createOptionalDateType() {
        return new OptionalDateType();
    }

    /**
     * Create an instance of {@link ContactInfoAmendType.CellPhones }
     * 
     */
    public ContactInfoAmendType.CellPhones createContactInfoAmendTypeCellPhones() {
        return new ContactInfoAmendType.CellPhones();
    }

    /**
     * Create an instance of {@link StringLength0To58AmendFPType }
     * 
     */
    public StringLength0To58AmendFPType createStringLength0To58AmendFPType() {
        return new StringLength0To58AmendFPType();
    }

    /**
     * Create an instance of {@link BagAmendType.StorageLocation }
     * 
     */
    public BagAmendType.StorageLocation createBagAmendTypeStorageLocation() {
        return new BagAmendType.StorageLocation();
    }

    /**
     * Create an instance of {@link DelayedClaimAmendType.ToiletKits }
     * 
     */
    public DelayedClaimAmendType.ToiletKits createDelayedClaimAmendTypeToiletKits() {
        return new DelayedClaimAmendType.ToiletKits();
    }

    /**
     * Create an instance of {@link ContactInfoAmendType.TempAddress.ValidityDate }
     * 
     */
    public ContactInfoAmendType.TempAddress.ValidityDate createContactInfoAmendTypeTempAddressValidityDate() {
        return new ContactInfoAmendType.TempAddress.ValidityDate();
    }

    /**
     * Create an instance of {@link DamageClaimType.ExcessValue }
     * 
     */
    public DamageClaimType.ExcessValue createDamageClaimTypeExcessValue() {
        return new DamageClaimType.ExcessValue();
    }

    /**
     * Create an instance of {@link OnHandBagTracingAmendType }
     * 
     */
    public OnHandBagTracingAmendType createOnHandBagTracingAmendType() {
        return new OnHandBagTracingAmendType();
    }

    /**
     * Create an instance of {@link PassengerAmendType.Title }
     * 
     */
    public PassengerAmendType.Title createPassengerAmendTypeTitle() {
        return new PassengerAmendType.Title();
    }

    /**
     * Create an instance of {@link DelayedBagIDType }
     * 
     */
    public DelayedBagIDType createDelayedBagIDType() {
        return new DelayedBagIDType();
    }

    /**
     * Create an instance of {@link PassengerAmendType.PNR }
     * 
     */
    public PassengerAmendType.PNR createPassengerAmendTypePNR() {
        return new PassengerAmendType.PNR();
    }

    /**
     * Create an instance of {@link ColorTypeDescType }
     * 
     */
    public ColorTypeDescType createColorTypeDescType() {
        return new ColorTypeDescType();
    }

    /**
     * Create an instance of {@link DelayedBagAmendType.ContentsDesc }
     * 
     */
    public DelayedBagAmendType.ContentsDesc createDelayedBagAmendTypeContentsDesc() {
        return new DelayedBagAmendType.ContentsDesc();
    }

    /**
     * Create an instance of {@link OnHandBagAmendType.Itinerary.Routes }
     * 
     */
    public OnHandBagAmendType.Itinerary.Routes createOnHandBagAmendTypeItineraryRoutes() {
        return new OnHandBagAmendType.Itinerary.Routes();
    }

    /**
     * Create an instance of {@link FoundItemType.Content.Description }
     * 
     */
    public FoundItemType.Content.Description createFoundItemTypeContentDescription() {
        return new FoundItemType.Content.Description();
    }

    /**
     * Create an instance of {@link DamagedBagGroupAmendType.MissingWeight }
     * 
     */
    public DamagedBagGroupAmendType.MissingWeight createDamagedBagGroupAmendTypeMissingWeight() {
        return new DamagedBagGroupAmendType.MissingWeight();
    }

    /**
     * Create an instance of {@link OnHandBagType.Itinerary.Routes }
     * 
     */
    public OnHandBagType.Itinerary.Routes createOnHandBagTypeItineraryRoutes() {
        return new OnHandBagType.Itinerary.Routes();
    }

    /**
     * Create an instance of {@link BagAmendType }
     * 
     */
    public BagAmendType createBagAmendType() {
        return new BagAmendType();
    }

    /**
     * Create an instance of {@link RushBagGroupType }
     * 
     */
    public RushBagGroupType createRushBagGroupType() {
        return new RushBagGroupType();
    }

    /**
     * Create an instance of {@link HandledPageType }
     * 
     */
    public HandledPageType createHandledPageType() {
        return new HandledPageType();
    }

    /**
     * Create an instance of {@link OnHandBagRecordType }
     * 
     */
    public OnHandBagRecordType createOnHandBagRecordType() {
        return new OnHandBagRecordType();
    }

    /**
     * Create an instance of {@link BagAmendType.BagReceivedFromCustoms }
     * 
     */
    public BagAmendType.BagReceivedFromCustoms createBagAmendTypeBagReceivedFromCustoms() {
        return new BagAmendType.BagReceivedFromCustoms();
    }

    /**
     * Create an instance of {@link DamageClaimType }
     * 
     */
    public DamageClaimType createDamageClaimType() {
        return new DamageClaimType();
    }

    /**
     * Create an instance of {@link BagSummaryType }
     * 
     */
    public BagSummaryType createBagSummaryType() {
        return new BagSummaryType();
    }

    /**
     * Create an instance of {@link InboxMessageSearchType }
     * 
     */
    public InboxMessageSearchType createInboxMessageSearchType() {
        return new InboxMessageSearchType();
    }

    /**
     * Create an instance of {@link BagAmendType.BagDelivery.Status.UnableToDeliver }
     * 
     */
    public BagAmendType.BagDelivery.Status.UnableToDeliver createBagAmendTypeBagDeliveryStatusUnableToDeliver() {
        return new BagAmendType.BagDelivery.Status.UnableToDeliver();
    }

    /**
     * Create an instance of {@link BagAmendType.BagSentToCustoms }
     * 
     */
    public BagAmendType.BagSentToCustoms createBagAmendTypeBagSentToCustoms() {
        return new BagAmendType.BagSentToCustoms();
    }

    /**
     * Create an instance of {@link DeliveryType }
     * 
     */
    public DeliveryType createDeliveryType() {
        return new DeliveryType();
    }

    /**
     * Create an instance of {@link WTRAddressAmendType }
     * 
     */
    public WTRAddressAmendType createWTRAddressAmendType() {
        return new WTRAddressAmendType();
    }

    /**
     * Create an instance of {@link ContactInfoType.Emails }
     * 
     */
    public ContactInfoType.Emails createContactInfoTypeEmails() {
        return new ContactInfoType.Emails();
    }

    /**
     * Create an instance of {@link AdditionalInfoAmendType.MessageInfo }
     * 
     */
    public AdditionalInfoAmendType.MessageInfo createAdditionalInfoAmendTypeMessageInfo() {
        return new AdditionalInfoAmendType.MessageInfo();
    }

    /**
     * Create an instance of {@link ContactInfoType.PermPhones }
     * 
     */
    public ContactInfoType.PermPhones createContactInfoTypePermPhones() {
        return new ContactInfoType.PermPhones();
    }

    /**
     * Create an instance of {@link PassengerItineraryAmendType.Itinerary.AdditionalRoutes }
     * 
     */
    public PassengerItineraryAmendType.Itinerary.AdditionalRoutes createPassengerItineraryAmendTypeItineraryAdditionalRoutes() {
        return new PassengerItineraryAmendType.Itinerary.AdditionalRoutes();
    }

    /**
     * Create an instance of {@link WTRAddressAmendType.State }
     * 
     */
    public WTRAddressAmendType.State createWTRAddressAmendTypeState() {
        return new WTRAddressAmendType.State();
    }

    /**
     * Create an instance of {@link CustomsDate }
     * 
     */
    public CustomsDate createCustomsDate() {
        return new CustomsDate();
    }

    /**
     * Create an instance of {@link BagAmendType.BagDelivery.DeliveredTime }
     * 
     */
    public BagAmendType.BagDelivery.DeliveredTime createBagAmendTypeBagDeliveryDeliveredTime() {
        return new BagAmendType.BagDelivery.DeliveredTime();
    }

    /**
     * Create an instance of {@link FoundItemType.Content }
     * 
     */
    public FoundItemType.Content createFoundItemTypeContent() {
        return new FoundItemType.Content();
    }

    /**
     * Create an instance of {@link OnHandBagAmendType.ContentsDesc }
     * 
     */
    public OnHandBagAmendType.ContentsDesc createOnHandBagAmendTypeContentsDesc() {
        return new OnHandBagAmendType.ContentsDesc();
    }

    /**
     * Create an instance of {@link OnHandBagAmendType.Itinerary.FlightSegments }
     * 
     */
    public OnHandBagAmendType.Itinerary.FlightSegments createOnHandBagAmendTypeItineraryFlightSegments() {
        return new OnHandBagAmendType.Itinerary.FlightSegments();
    }

    /**
     * Create an instance of {@link PassengerItineraryType.Itinerary }
     * 
     */
    public PassengerItineraryType.Itinerary createPassengerItineraryTypeItinerary() {
        return new PassengerItineraryType.Itinerary();
    }

    /**
     * Create an instance of {@link OnHandBagTracingType.NewFlights }
     * 
     */
    public OnHandBagTracingType.NewFlights createOnHandBagTracingTypeNewFlights() {
        return new OnHandBagTracingType.NewFlights();
    }

    /**
     * Create an instance of {@link AdditionalInfoAmendType.MatchInfo }
     * 
     */
    public AdditionalInfoAmendType.MatchInfo createAdditionalInfoAmendTypeMatchInfo() {
        return new AdditionalInfoAmendType.MatchInfo();
    }

    /**
     * Create an instance of {@link FlightSegmentOrARNKType }
     * 
     */
    public FlightSegmentOrARNKType createFlightSegmentOrARNKType() {
        return new FlightSegmentOrARNKType();
    }

    /**
     * Create an instance of {@link RecordReferenceType }
     * 
     */
    public RecordReferenceType createRecordReferenceType() {
        return new RecordReferenceType();
    }

    /**
     * Create an instance of {@link LicenseNumberType }
     * 
     */
    public LicenseNumberType createLicenseNumberType() {
        return new LicenseNumberType();
    }

    /**
     * Create an instance of {@link ContactInfoAmendType.Emails }
     * 
     */
    public ContactInfoAmendType.Emails createContactInfoAmendTypeEmails() {
        return new ContactInfoAmendType.Emails();
    }

    /**
     * Create an instance of {@link DelayedBagGroupAmendType.DelayedBags.DelayedBag }
     * 
     */
    public DelayedBagGroupAmendType.DelayedBags.DelayedBag createDelayedBagGroupAmendTypeDelayedBagsDelayedBag() {
        return new DelayedBagGroupAmendType.DelayedBags.DelayedBag();
    }

    /**
     * Create an instance of {@link ContactInfoType.Country }
     * 
     */
    public ContactInfoType.Country createContactInfoTypeCountry() {
        return new ContactInfoType.Country();
    }

    /**
     * Create an instance of {@link WTRAddressType.Country }
     * 
     */
    public WTRAddressType.Country createWTRAddressTypeCountry() {
        return new WTRAddressType.Country();
    }

    /**
     * Create an instance of {@link FoundItemType }
     * 
     */
    public FoundItemType createFoundItemType() {
        return new FoundItemType();
    }

    /**
     * Create an instance of {@link PassengersBoardedType }
     * 
     */
    public PassengersBoardedType createPassengersBoardedType() {
        return new PassengersBoardedType();
    }

    /**
     * Create an instance of {@link PassengerAmendType.NoOfPassengers }
     * 
     */
    public PassengerAmendType.NoOfPassengers createPassengerAmendTypeNoOfPassengers() {
        return new PassengerAmendType.NoOfPassengers();
    }

    /**
     * Create an instance of {@link ClaimAmendType }
     * 
     */
    public ClaimAmendType createClaimAmendType() {
        return new ClaimAmendType();
    }

    /**
     * Create an instance of {@link ClaimType.ClaimAmout.Amount }
     * 
     */
    public ClaimType.ClaimAmout.Amount createClaimTypeClaimAmoutAmount() {
        return new ClaimType.ClaimAmout.Amount();
    }

    /**
     * Create an instance of {@link ClaimAmendType.ClaimDate }
     * 
     */
    public ClaimAmendType.ClaimDate createClaimAmendTypeClaimDate() {
        return new ClaimAmendType.ClaimDate();
    }

    /**
     * Create an instance of {@link DamagedBagAmendType.DamageTypes }
     * 
     */
    public DamagedBagAmendType.DamageTypes createDamagedBagAmendTypeDamageTypes() {
        return new DamagedBagAmendType.DamageTypes();
    }

    /**
     * Create an instance of {@link BagGroupAmendType.ContentsGender }
     * 
     */
    public BagGroupAmendType.ContentsGender createBagGroupAmendTypeContentsGender() {
        return new BagGroupAmendType.ContentsGender();
    }

    /**
     * Create an instance of {@link DelayedBagGroupAmendType.BagLastSeen }
     * 
     */
    public DelayedBagGroupAmendType.BagLastSeen createDelayedBagGroupAmendTypeBagLastSeen() {
        return new DelayedBagGroupAmendType.BagLastSeen();
    }

    /**
     * Create an instance of {@link PassengerType.Initials }
     * 
     */
    public PassengerType.Initials createPassengerTypeInitials() {
        return new PassengerType.Initials();
    }

    /**
     * Create an instance of {@link FlightType }
     * 
     */
    public FlightType createFlightType() {
        return new FlightType();
    }

    /**
     * Create an instance of {@link PassengerAmendType.Names }
     * 
     */
    public PassengerAmendType.Names createPassengerAmendTypeNames() {
        return new PassengerAmendType.Names();
    }

    /**
     * Create an instance of {@link DamageClaimAmendType.ReplacementBag }
     * 
     */
    public DamageClaimAmendType.ReplacementBag createDamageClaimAmendTypeReplacementBag() {
        return new DamageClaimAmendType.ReplacementBag();
    }

    /**
     * Create an instance of {@link BagGroupAmendType }
     * 
     */
    public BagGroupAmendType createBagGroupAmendType() {
        return new BagGroupAmendType();
    }

    /**
     * Create an instance of {@link DelayedBagGroupType.DelayedBags }
     * 
     */
    public DelayedBagGroupType.DelayedBags createDelayedBagGroupTypeDelayedBags() {
        return new DelayedBagGroupType.DelayedBags();
    }

    /**
     * Create an instance of {@link OnHandBagAmendType.BagPhones }
     * 
     */
    public OnHandBagAmendType.BagPhones createOnHandBagAmendTypeBagPhones() {
        return new OnHandBagAmendType.BagPhones();
    }

    /**
     * Create an instance of {@link DelayedBagGroupAmendType.KeysCollected }
     * 
     */
    public DelayedBagGroupAmendType.KeysCollected createDelayedBagGroupAmendTypeKeysCollected() {
        return new DelayedBagGroupAmendType.KeysCollected();
    }

    /**
     * Create an instance of {@link BagGroupType }
     * 
     */
    public BagGroupType createBagGroupType() {
        return new BagGroupType();
    }

    /**
     * Create an instance of {@link DelayedClaimType.ExcessValue }
     * 
     */
    public DelayedClaimType.ExcessValue createDelayedClaimTypeExcessValue() {
        return new DelayedClaimType.ExcessValue();
    }

    /**
     * Create an instance of {@link EmptyType }
     * 
     */
    public EmptyType createEmptyType() {
        return new EmptyType();
    }

    /**
     * Create an instance of {@link ContactInfoAmendType.ZipCode }
     * 
     */
    public ContactInfoAmendType.ZipCode createContactInfoAmendTypeZipCode() {
        return new ContactInfoAmendType.ZipCode();
    }

    /**
     * Create an instance of {@link PassengerType.Names }
     * 
     */
    public PassengerType.Names createPassengerTypeNames() {
        return new PassengerType.Names();
    }

    /**
     * Create an instance of {@link PassengersBoardedType.StationInput }
     * 
     */
    public PassengersBoardedType.StationInput createPassengersBoardedTypeStationInput() {
        return new PassengersBoardedType.StationInput();
    }

    /**
     * Create an instance of {@link DamagedBagAmendType }
     * 
     */
    public DamagedBagAmendType createDamagedBagAmendType() {
        return new DamagedBagAmendType();
    }

    /**
     * Create an instance of {@link BagDeliveryType.Status }
     * 
     */
    public BagDeliveryType.Status createBagDeliveryTypeStatus() {
        return new BagDeliveryType.Status();
    }

    /**
     * Create an instance of {@link PassengerItineraryType.Itinerary.AdditionalRoutes }
     * 
     */
    public PassengerItineraryType.Itinerary.AdditionalRoutes createPassengerItineraryTypeItineraryAdditionalRoutes() {
        return new PassengerItineraryType.Itinerary.AdditionalRoutes();
    }

    /**
     * Create an instance of {@link DelayedBagGroupAmendType.MatchWindow }
     * 
     */
    public DelayedBagGroupAmendType.MatchWindow createDelayedBagGroupAmendTypeMatchWindow() {
        return new DelayedBagGroupAmendType.MatchWindow();
    }

    /**
     * Create an instance of {@link ContactInfoAmendType }
     * 
     */
    public ContactInfoAmendType createContactInfoAmendType() {
        return new ContactInfoAmendType();
    }

    /**
     * Create an instance of {@link AdditionalInfoAmendType }
     * 
     */
    public AdditionalInfoAmendType createAdditionalInfoAmendType() {
        return new AdditionalInfoAmendType();
    }

    /**
     * Create an instance of {@link PassengerItineraryType }
     * 
     */
    public PassengerItineraryType createPassengerItineraryType() {
        return new PassengerItineraryType();
    }

    /**
     * Create an instance of {@link DelayedBagAmendType.Remarks }
     * 
     */
    public DelayedBagAmendType.Remarks createDelayedBagAmendTypeRemarks() {
        return new DelayedBagAmendType.Remarks();
    }

    /**
     * Create an instance of {@link StringLength0To2000AmendType }
     * 
     */
    public StringLength0To2000AmendType createStringLength0To2000AmendType() {
        return new StringLength0To2000AmendType();
    }

    /**
     * Create an instance of {@link ClaimAmendType.CostRemarks }
     * 
     */
    public ClaimAmendType.CostRemarks createClaimAmendTypeCostRemarks() {
        return new ClaimAmendType.CostRemarks();
    }

    /**
     * Create an instance of {@link PassengerItineraryAmendType.FareBasis }
     * 
     */
    public PassengerItineraryAmendType.FareBasis createPassengerItineraryAmendTypeFareBasis() {
        return new PassengerItineraryAmendType.FareBasis();
    }

    /**
     * Create an instance of {@link ContentsAmendType.Content }
     * 
     */
    public ContentsAmendType.Content createContentsAmendTypeContent() {
        return new ContentsAmendType.Content();
    }

    /**
     * Create an instance of {@link SearchBagType.Contents }
     * 
     */
    public SearchBagType.Contents createSearchBagTypeContents() {
        return new SearchBagType.Contents();
    }

    /**
     * Create an instance of {@link ContentsAmendType }
     * 
     */
    public ContentsAmendType createContentsAmendType() {
        return new ContentsAmendType();
    }

    /**
     * Create an instance of {@link PassengerAmendType.Initials.Intial }
     * 
     */
    public PassengerAmendType.Initials.Intial createPassengerAmendTypeInitialsIntial() {
        return new PassengerAmendType.Initials.Intial();
    }

    /**
     * Create an instance of {@link DamageClaimAmendType.ExcessValue }
     * 
     */
    public DamageClaimAmendType.ExcessValue createDamageClaimAmendTypeExcessValue() {
        return new DamageClaimAmendType.ExcessValue();
    }

    /**
     * Create an instance of {@link WTRAddressType.PostalCode }
     * 
     */
    public WTRAddressType.PostalCode createWTRAddressTypePostalCode() {
        return new WTRAddressType.PostalCode();
    }

    /**
     * Create an instance of {@link AdditionalInfoAmendType.MiscInfo }
     * 
     */
    public AdditionalInfoAmendType.MiscInfo createAdditionalInfoAmendTypeMiscInfo() {
        return new AdditionalInfoAmendType.MiscInfo();
    }

    /**
     * Create an instance of {@link DamageTypeType }
     * 
     */
    public DamageTypeType createDamageTypeType() {
        return new DamageTypeType();
    }

    /**
     * Create an instance of {@link FlightDateOrARNKType }
     * 
     */
    public FlightDateOrARNKType createFlightDateOrARNKType() {
        return new FlightDateOrARNKType();
    }

    /**
     * Create an instance of {@link OnHandBagType.BagPhones }
     * 
     */
    public OnHandBagType.BagPhones createOnHandBagTypeBagPhones() {
        return new OnHandBagType.BagPhones();
    }

    /**
     * Create an instance of {@link ClaimType.LiabilityTag }
     * 
     */
    public ClaimType.LiabilityTag createClaimTypeLiabilityTag() {
        return new ClaimType.LiabilityTag();
    }

    /**
     * Create an instance of {@link DamagedBagGroupType.LostContents }
     * 
     */
    public DamagedBagGroupType.LostContents createDamagedBagGroupTypeLostContents() {
        return new DamagedBagGroupType.LostContents();
    }

    /**
     * Create an instance of {@link PassengerItineraryAmendType.Status }
     * 
     */
    public PassengerItineraryAmendType.Status createPassengerItineraryAmendTypeStatus() {
        return new PassengerItineraryAmendType.Status();
    }

    /**
     * Create an instance of {@link ClaimAmendType.ClaimAmout }
     * 
     */
    public ClaimAmendType.ClaimAmout createClaimAmendTypeClaimAmout() {
        return new ClaimAmendType.ClaimAmout();
    }

    /**
     * Create an instance of {@link OnHandBagType.Itinerary.FlightSegments }
     * 
     */
    public OnHandBagType.Itinerary.FlightSegments createOnHandBagTypeItineraryFlightSegments() {
        return new OnHandBagType.Itinerary.FlightSegments();
    }

    /**
     * Create an instance of {@link ClaimType }
     * 
     */
    public ClaimType createClaimType() {
        return new ClaimType();
    }

    /**
     * Create an instance of {@link ClaimAmendType.PassengerPayments }
     * 
     */
    public ClaimAmendType.PassengerPayments createClaimAmendTypePassengerPayments() {
        return new ClaimAmendType.PassengerPayments();
    }

    /**
     * Create an instance of {@link FlightSegmentOrARNKAmendType }
     * 
     */
    public FlightSegmentOrARNKAmendType createFlightSegmentOrARNKAmendType() {
        return new FlightSegmentOrARNKAmendType();
    }

    /**
     * Create an instance of {@link PersonNameType }
     * 
     */
    public PersonNameType createPersonNameType() {
        return new PersonNameType();
    }

    /**
     * Create an instance of {@link ClaimType.Insurance }
     * 
     */
    public ClaimType.Insurance createClaimTypeInsurance() {
        return new ClaimType.Insurance();
    }

    /**
     * Create an instance of {@link ContentsType }
     * 
     */
    public ContentsType createContentsType() {
        return new ContentsType();
    }

    /**
     * Create an instance of {@link DamagedBagGroupType }
     * 
     */
    public DamagedBagGroupType createDamagedBagGroupType() {
        return new DamagedBagGroupType();
    }

    /**
     * Create an instance of {@link OnHandBagAmendType.LossComments }
     * 
     */
    public OnHandBagAmendType.LossComments createOnHandBagAmendTypeLossComments() {
        return new OnHandBagAmendType.LossComments();
    }

    /**
     * Create an instance of {@link ContactInfoAmendType.TempAddress }
     * 
     */
    public ContactInfoAmendType.TempAddress createContactInfoAmendTypeTempAddress() {
        return new ContactInfoAmendType.TempAddress();
    }

    /**
     * Create an instance of {@link PassengerItineraryType.Itinerary.FlightSegments }
     * 
     */
    public PassengerItineraryType.Itinerary.FlightSegments createPassengerItineraryTypeItineraryFlightSegments() {
        return new PassengerItineraryType.Itinerary.FlightSegments();
    }

    /**
     * Create an instance of {@link BagAmendType.UniqueID }
     * 
     */
    public BagAmendType.UniqueID createBagAmendTypeUniqueID() {
        return new BagAmendType.UniqueID();
    }

    /**
     * Create an instance of {@link WTRAddressAmendType.PostalCode }
     * 
     */
    public WTRAddressAmendType.PostalCode createWTRAddressAmendTypePostalCode() {
        return new WTRAddressAmendType.PostalCode();
    }

    /**
     * Create an instance of {@link DateRangeType }
     * 
     */
    public DateRangeType createDateRangeType() {
        return new DateRangeType();
    }

    /**
     * Create an instance of {@link PassengerAmendType.FrequentFlyerID }
     * 
     */
    public PassengerAmendType.FrequentFlyerID createPassengerAmendTypeFrequentFlyerID() {
        return new PassengerAmendType.FrequentFlyerID();
    }

    /**
     * Create an instance of {@link ContactInfoType.Faxes }
     * 
     */
    public ContactInfoType.Faxes createContactInfoTypeFaxes() {
        return new ContactInfoType.Faxes();
    }

    /**
     * Create an instance of {@link DamagedBagGroupAmendType.LostContents }
     * 
     */
    public DamagedBagGroupAmendType.LostContents createDamagedBagGroupAmendTypeLostContents() {
        return new DamagedBagGroupAmendType.LostContents();
    }

    /**
     * Create an instance of {@link DamagedBagGroupAmendType.ExcessBaggage }
     * 
     */
    public DamagedBagGroupAmendType.ExcessBaggage createDamagedBagGroupAmendTypeExcessBaggage() {
        return new DamagedBagGroupAmendType.ExcessBaggage();
    }

    /**
     * Create an instance of {@link ContactInfoAmendType.TempPhones }
     * 
     */
    public ContactInfoAmendType.TempPhones createContactInfoAmendTypeTempPhones() {
        return new ContactInfoAmendType.TempPhones();
    }

    /**
     * Create an instance of {@link RecordIdentifierAmendType }
     * 
     */
    public RecordIdentifierAmendType createRecordIdentifierAmendType() {
        return new RecordIdentifierAmendType();
    }

    /**
     * Create an instance of {@link BagGroupAmendType.BaggageWeight }
     * 
     */
    public BagGroupAmendType.BaggageWeight createBagGroupAmendTypeBaggageWeight() {
        return new BagGroupAmendType.BaggageWeight();
    }

    /**
     * Create an instance of {@link PassengerAmendType }
     * 
     */
    public PassengerAmendType createPassengerAmendType() {
        return new PassengerAmendType();
    }

    /**
     * Create an instance of {@link FrequentFlyerType }
     * 
     */
    public FrequentFlyerType createFrequentFlyerType() {
        return new FrequentFlyerType();
    }

    /**
     * Create an instance of {@link DelayedBagGroupType.BaggageItinerary }
     * 
     */
    public DelayedBagGroupType.BaggageItinerary createDelayedBagGroupTypeBaggageItinerary() {
        return new DelayedBagGroupType.BaggageItinerary();
    }

    /**
     * Create an instance of {@link PassengerAmendType.Language }
     * 
     */
    public PassengerAmendType.Language createPassengerAmendTypeLanguage() {
        return new PassengerAmendType.Language();
    }

    /**
     * Create an instance of {@link ClaimAmendType.QuestionnaireDate }
     * 
     */
    public ClaimAmendType.QuestionnaireDate createClaimAmendTypeQuestionnaireDate() {
        return new ClaimAmendType.QuestionnaireDate();
    }

    /**
     * Create an instance of {@link DelayedBagGroupType }
     * 
     */
    public DelayedBagGroupType createDelayedBagGroupType() {
        return new DelayedBagGroupType();
    }

    /**
     * Create an instance of {@link PassengerPaymentAmendType }
     * 
     */
    public PassengerPaymentAmendType createPassengerPaymentAmendType() {
        return new PassengerPaymentAmendType();
    }

    /**
     * Create an instance of {@link WTRGenericPageRQType.Page }
     * 
     */
    public WTRGenericPageRQType.Page createWTRGenericPageRQTypePage() {
        return new WTRGenericPageRQType.Page();
    }

    /**
     * Create an instance of {@link FlightSegmentType }
     * 
     */
    public FlightSegmentType createFlightSegmentType() {
        return new FlightSegmentType();
    }

    /**
     * Create an instance of {@link ItemRangeType }
     * 
     */
    public ItemRangeType createItemRangeType() {
        return new ItemRangeType();
    }

    /**
     * Create an instance of {@link DeliveryAmendType.LocalDlvInfo }
     * 
     */
    public DeliveryAmendType.LocalDlvInfo createDeliveryAmendTypeLocalDlvInfo() {
        return new DeliveryAmendType.LocalDlvInfo();
    }

    /**
     * Create an instance of {@link DelayedBagGroupAmendType.MissingWeight }
     * 
     */
    public DelayedBagGroupAmendType.MissingWeight createDelayedBagGroupAmendTypeMissingWeight() {
        return new DelayedBagGroupAmendType.MissingWeight();
    }

    /**
     * Create an instance of {@link BagAmendType.BagDelivery.Status.OutForDelivery }
     * 
     */
    public BagAmendType.BagDelivery.Status.OutForDelivery createBagAmendTypeBagDeliveryStatusOutForDelivery() {
        return new BagAmendType.BagDelivery.Status.OutForDelivery();
    }

    /**
     * Create an instance of {@link SearchBagType }
     * 
     */
    public SearchBagType createSearchBagType() {
        return new SearchBagType();
    }

    /**
     * Create an instance of {@link BagReceivedType }
     * 
     */
    public BagReceivedType createBagReceivedType() {
        return new BagReceivedType();
    }

    /**
     * Create an instance of {@link AdditionalInfoAmendType.CustomsInfo }
     * 
     */
    public AdditionalInfoAmendType.CustomsInfo createAdditionalInfoAmendTypeCustomsInfo() {
        return new AdditionalInfoAmendType.CustomsInfo();
    }

    /**
     * Create an instance of {@link DamageClaimAmendType.RepairBag }
     * 
     */
    public DamageClaimAmendType.RepairBag createDamageClaimAmendTypeRepairBag() {
        return new DamageClaimAmendType.RepairBag();
    }

    /**
     * Create an instance of {@link DamagedBagGroupAmendType.BaggageItinerary }
     * 
     */
    public DamagedBagGroupAmendType.BaggageItinerary createDamagedBagGroupAmendTypeBaggageItinerary() {
        return new DamagedBagGroupAmendType.BaggageItinerary();
    }

    /**
     * Create an instance of {@link WTRAddressAmendType.Country }
     * 
     */
    public WTRAddressAmendType.Country createWTRAddressAmendTypeCountry() {
        return new WTRAddressAmendType.Country();
    }

    /**
     * Create an instance of {@link BusinessAddressType }
     * 
     */
    public BusinessAddressType createBusinessAddressType() {
        return new BusinessAddressType();
    }

    /**
     * Create an instance of {@link ClaimAmendType.LossComments }
     * 
     */
    public ClaimAmendType.LossComments createClaimAmendTypeLossComments() {
        return new ClaimAmendType.LossComments();
    }

    /**
     * Create an instance of {@link AdditionalInfoAmendType.FurtherInfo }
     * 
     */
    public AdditionalInfoAmendType.FurtherInfo createAdditionalInfoAmendTypeFurtherInfo() {
        return new AdditionalInfoAmendType.FurtherInfo();
    }

    /**
     * Create an instance of {@link OnHandBagAmendType.BaggageWeight }
     * 
     */
    public OnHandBagAmendType.BaggageWeight createOnHandBagAmendTypeBaggageWeight() {
        return new OnHandBagAmendType.BaggageWeight();
    }

    /**
     * Create an instance of {@link OnHandBagAmendType.Remarks }
     * 
     */
    public OnHandBagAmendType.Remarks createOnHandBagAmendTypeRemarks() {
        return new OnHandBagAmendType.Remarks();
    }

    /**
     * Create an instance of {@link BagRecordSummaryType.RushBags }
     * 
     */
    public BagRecordSummaryType.RushBags createBagRecordSummaryTypeRushBags() {
        return new BagRecordSummaryType.RushBags();
    }

    /**
     * Create an instance of {@link RecordHistoryType }
     * 
     */
    public RecordHistoryType createRecordHistoryType() {
        return new RecordHistoryType();
    }

    /**
     * Create an instance of {@link WTRAddressAmendType.City }
     * 
     */
    public WTRAddressAmendType.City createWTRAddressAmendTypeCity() {
        return new WTRAddressAmendType.City();
    }

    /**
     * Create an instance of {@link BagAmendType.BagDelivery.Status.Delivered }
     * 
     */
    public BagAmendType.BagDelivery.Status.Delivered createBagAmendTypeBagDeliveryStatusDelivered() {
        return new BagAmendType.BagDelivery.Status.Delivered();
    }

}

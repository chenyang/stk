
package aero.sita.wtr.common._3._0;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * Contains Frequent Flyer airline and number
 * 
 * <p>Java class for FrequentFlyerType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FrequentFlyerType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="AirlineCode" type="{http://www.iata.org/IATA/2007/00}AirlineType" minOccurs="0"/>
 *         &lt;element name="FrequentFlyerID" type="{http://sita.aero/wtr/common/3/0}AlphaNumericStringLength1to25"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FrequentFlyerType", propOrder = {
    "airlineCode",
    "frequentFlyerID"
})
public class FrequentFlyerType {

    @XmlElement(name = "AirlineCode")
    protected String airlineCode;
    @XmlElement(name = "FrequentFlyerID", required = true)
    protected String frequentFlyerID;

    /**
     * Gets the value of the airlineCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAirlineCode() {
        return airlineCode;
    }

    /**
     * Sets the value of the airlineCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAirlineCode(String value) {
        this.airlineCode = value;
    }

    /**
     * Gets the value of the frequentFlyerID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFrequentFlyerID() {
        return frequentFlyerID;
    }

    /**
     * Sets the value of the frequentFlyerID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFrequentFlyerID(String value) {
        this.frequentFlyerID = value;
    }

}

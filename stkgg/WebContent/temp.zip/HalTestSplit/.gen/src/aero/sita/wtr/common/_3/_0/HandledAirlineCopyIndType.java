
package aero.sita.wtr.common._3._0;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for HandledAirlineCopyIndType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="HandledAirlineCopyIndType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="YES"/>
 *     &lt;enumeration value="NO"/>
 *     &lt;enumeration value="REPEAT"/>
 *     &lt;enumeration value="FULL"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "HandledAirlineCopyIndType")
@XmlEnum
public enum HandledAirlineCopyIndType {

    YES,
    NO,
    REPEAT,
    FULL;

    public String value() {
        return name();
    }

    public static HandledAirlineCopyIndType fromValue(String v) {
        return valueOf(v);
    }

}


package aero.sita.wtr.common._3._0;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for HandledPageType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="HandledPageType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Handling" maxOccurs="14" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;attGroup ref="{http://sita.aero/wtr/common/3/0}HandlingAgreementAttributes"/>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *       &lt;attribute name="UpdateDate" type="{http://www.w3.org/2001/XMLSchema}date" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "HandledPageType", propOrder = {
    "handling"
})
public class HandledPageType {

    @XmlElement(name = "Handling")
    protected List<HandledPageType.Handling> handling;
    @XmlAttribute(name = "UpdateDate")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar updateDate;

    /**
     * Gets the value of the handling property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the handling property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getHandling().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link HandledPageType.Handling }
     * 
     * 
     */
    public List<HandledPageType.Handling> getHandling() {
        if (handling == null) {
            handling = new ArrayList<HandledPageType.Handling>();
        }
        return this.handling;
    }

    /**
     * Gets the value of the updateDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getUpdateDate() {
        return updateDate;
    }

    /**
     * Sets the value of the updateDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setUpdateDate(XMLGregorianCalendar value) {
        this.updateDate = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;attGroup ref="{http://sita.aero/wtr/common/3/0}HandlingAgreementAttributes"/>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "")
    public static class Handling {

        @XmlAttribute(name = "Seq")
        protected Short seq;
        @XmlAttribute(name = "Airline")
        protected String airline;
        @XmlAttribute(name = "Trace")
        protected String trace;
        @XmlAttribute(name = "TTY")
        protected String tty;
        @XmlAttribute(name = "MRI")
        protected Boolean mri;
        @XmlAttribute(name = "MRS")
        protected Boolean mrs;
        @XmlAttribute(name = "MSL")
        protected Boolean msl;
        @XmlAttribute(name = "Mandatory")
        protected Boolean mandatory;

        /**
         * Gets the value of the seq property.
         * 
         * @return
         *     possible object is
         *     {@link Short }
         *     
         */
        public Short getSeq() {
            return seq;
        }

        /**
         * Sets the value of the seq property.
         * 
         * @param value
         *     allowed object is
         *     {@link Short }
         *     
         */
        public void setSeq(Short value) {
            this.seq = value;
        }

        /**
         * Gets the value of the airline property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getAirline() {
            return airline;
        }

        /**
         * Sets the value of the airline property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setAirline(String value) {
            this.airline = value;
        }

        /**
         * Gets the value of the trace property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getTrace() {
            return trace;
        }

        /**
         * Sets the value of the trace property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setTrace(String value) {
            this.trace = value;
        }

        /**
         * Gets the value of the tty property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getTTY() {
            return tty;
        }

        /**
         * Sets the value of the tty property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setTTY(String value) {
            this.tty = value;
        }

        /**
         * Gets the value of the mri property.
         * 
         * @return
         *     possible object is
         *     {@link Boolean }
         *     
         */
        public Boolean isMRI() {
            return mri;
        }

        /**
         * Sets the value of the mri property.
         * 
         * @param value
         *     allowed object is
         *     {@link Boolean }
         *     
         */
        public void setMRI(Boolean value) {
            this.mri = value;
        }

        /**
         * Gets the value of the mrs property.
         * 
         * @return
         *     possible object is
         *     {@link Boolean }
         *     
         */
        public Boolean isMRS() {
            return mrs;
        }

        /**
         * Sets the value of the mrs property.
         * 
         * @param value
         *     allowed object is
         *     {@link Boolean }
         *     
         */
        public void setMRS(Boolean value) {
            this.mrs = value;
        }

        /**
         * Gets the value of the msl property.
         * 
         * @return
         *     possible object is
         *     {@link Boolean }
         *     
         */
        public Boolean isMSL() {
            return msl;
        }

        /**
         * Sets the value of the msl property.
         * 
         * @param value
         *     allowed object is
         *     {@link Boolean }
         *     
         */
        public void setMSL(Boolean value) {
            this.msl = value;
        }

        /**
         * Gets the value of the mandatory property.
         * 
         * @return
         *     possible object is
         *     {@link Boolean }
         *     
         */
        public Boolean isMandatory() {
            return mandatory;
        }

        /**
         * Sets the value of the mandatory property.
         * 
         * @param value
         *     allowed object is
         *     {@link Boolean }
         *     
         */
        public void setMandatory(Boolean value) {
            this.mandatory = value;
        }

    }

}


package aero.sita.wtr.common._3._0;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for ContactInfoType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ContactInfoType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="PermanentAddress" type="{http://sita.aero/wtr/common/3/0}WTR_AddressType" minOccurs="0"/>
 *         &lt;element name="TempAddress" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="Address" type="{http://sita.aero/wtr/common/3/0}WTR_AddressType" minOccurs="0"/>
 *                   &lt;element name="ValidityDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="PermPhones" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="Phone" type="{http://sita.aero/wtr/common/3/0}StringLength1to20" maxOccurs="2"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="CellPhones" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="Phone" type="{http://sita.aero/wtr/common/3/0}StringLength1to20" maxOccurs="2"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="TempPhones" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="Phone" type="{http://sita.aero/wtr/common/3/0}StringLength1to20" maxOccurs="2"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="Emails" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="Email" type="{http://sita.aero/wtr/common/3/0}EmailType" maxOccurs="2"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="Faxes" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="Fax" type="{http://sita.aero/wtr/common/3/0}StringLength1to20" maxOccurs="2"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="Country" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;choice>
 *                   &lt;element name="CountryCode" type="{http://www.iata.org/IATA/2007/00}ISO3166"/>
 *                   &lt;element name="CountryName" type="{http://sita.aero/wtr/common/3/0}StringLength1to30"/>
 *                 &lt;/choice>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="State" type="{http://sita.aero/wtr/common/3/0}StringLength0to64" minOccurs="0"/>
 *         &lt;element name="ZipCode" type="{http://sita.aero/wtr/common/3/0}StringLength1to12" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ContactInfoType", propOrder = {
    "permanentAddress",
    "tempAddress",
    "permPhones",
    "cellPhones",
    "tempPhones",
    "emails",
    "faxes",
    "country",
    "state",
    "zipCode"
})
public class ContactInfoType {

    @XmlElement(name = "PermanentAddress")
    protected WTRAddressType permanentAddress;
    @XmlElement(name = "TempAddress")
    protected ContactInfoType.TempAddress tempAddress;
    @XmlElement(name = "PermPhones")
    protected ContactInfoType.PermPhones permPhones;
    @XmlElement(name = "CellPhones")
    protected ContactInfoType.CellPhones cellPhones;
    @XmlElement(name = "TempPhones")
    protected ContactInfoType.TempPhones tempPhones;
    @XmlElement(name = "Emails")
    protected ContactInfoType.Emails emails;
    @XmlElement(name = "Faxes")
    protected ContactInfoType.Faxes faxes;
    @XmlElement(name = "Country")
    protected ContactInfoType.Country country;
    @XmlElement(name = "State")
    protected String state;
    @XmlElement(name = "ZipCode")
    protected String zipCode;

    /**
     * Gets the value of the permanentAddress property.
     * 
     * @return
     *     possible object is
     *     {@link WTRAddressType }
     *     
     */
    public WTRAddressType getPermanentAddress() {
        return permanentAddress;
    }

    /**
     * Sets the value of the permanentAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link WTRAddressType }
     *     
     */
    public void setPermanentAddress(WTRAddressType value) {
        this.permanentAddress = value;
    }

    /**
     * Gets the value of the tempAddress property.
     * 
     * @return
     *     possible object is
     *     {@link ContactInfoType.TempAddress }
     *     
     */
    public ContactInfoType.TempAddress getTempAddress() {
        return tempAddress;
    }

    /**
     * Sets the value of the tempAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link ContactInfoType.TempAddress }
     *     
     */
    public void setTempAddress(ContactInfoType.TempAddress value) {
        this.tempAddress = value;
    }

    /**
     * Gets the value of the permPhones property.
     * 
     * @return
     *     possible object is
     *     {@link ContactInfoType.PermPhones }
     *     
     */
    public ContactInfoType.PermPhones getPermPhones() {
        return permPhones;
    }

    /**
     * Sets the value of the permPhones property.
     * 
     * @param value
     *     allowed object is
     *     {@link ContactInfoType.PermPhones }
     *     
     */
    public void setPermPhones(ContactInfoType.PermPhones value) {
        this.permPhones = value;
    }

    /**
     * Gets the value of the cellPhones property.
     * 
     * @return
     *     possible object is
     *     {@link ContactInfoType.CellPhones }
     *     
     */
    public ContactInfoType.CellPhones getCellPhones() {
        return cellPhones;
    }

    /**
     * Sets the value of the cellPhones property.
     * 
     * @param value
     *     allowed object is
     *     {@link ContactInfoType.CellPhones }
     *     
     */
    public void setCellPhones(ContactInfoType.CellPhones value) {
        this.cellPhones = value;
    }

    /**
     * Gets the value of the tempPhones property.
     * 
     * @return
     *     possible object is
     *     {@link ContactInfoType.TempPhones }
     *     
     */
    public ContactInfoType.TempPhones getTempPhones() {
        return tempPhones;
    }

    /**
     * Sets the value of the tempPhones property.
     * 
     * @param value
     *     allowed object is
     *     {@link ContactInfoType.TempPhones }
     *     
     */
    public void setTempPhones(ContactInfoType.TempPhones value) {
        this.tempPhones = value;
    }

    /**
     * Gets the value of the emails property.
     * 
     * @return
     *     possible object is
     *     {@link ContactInfoType.Emails }
     *     
     */
    public ContactInfoType.Emails getEmails() {
        return emails;
    }

    /**
     * Sets the value of the emails property.
     * 
     * @param value
     *     allowed object is
     *     {@link ContactInfoType.Emails }
     *     
     */
    public void setEmails(ContactInfoType.Emails value) {
        this.emails = value;
    }

    /**
     * Gets the value of the faxes property.
     * 
     * @return
     *     possible object is
     *     {@link ContactInfoType.Faxes }
     *     
     */
    public ContactInfoType.Faxes getFaxes() {
        return faxes;
    }

    /**
     * Sets the value of the faxes property.
     * 
     * @param value
     *     allowed object is
     *     {@link ContactInfoType.Faxes }
     *     
     */
    public void setFaxes(ContactInfoType.Faxes value) {
        this.faxes = value;
    }

    /**
     * Gets the value of the country property.
     * 
     * @return
     *     possible object is
     *     {@link ContactInfoType.Country }
     *     
     */
    public ContactInfoType.Country getCountry() {
        return country;
    }

    /**
     * Sets the value of the country property.
     * 
     * @param value
     *     allowed object is
     *     {@link ContactInfoType.Country }
     *     
     */
    public void setCountry(ContactInfoType.Country value) {
        this.country = value;
    }

    /**
     * Gets the value of the state property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getState() {
        return state;
    }

    /**
     * Sets the value of the state property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setState(String value) {
        this.state = value;
    }

    /**
     * Gets the value of the zipCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getZipCode() {
        return zipCode;
    }

    /**
     * Sets the value of the zipCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setZipCode(String value) {
        this.zipCode = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="Phone" type="{http://sita.aero/wtr/common/3/0}StringLength1to20" maxOccurs="2"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "phone"
    })
    public static class CellPhones {

        @XmlElement(name = "Phone", required = true)
        protected List<String> phone;

        /**
         * Gets the value of the phone property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the phone property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getPhone().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getPhone() {
            if (phone == null) {
                phone = new ArrayList<String>();
            }
            return this.phone;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;choice>
     *         &lt;element name="CountryCode" type="{http://www.iata.org/IATA/2007/00}ISO3166"/>
     *         &lt;element name="CountryName" type="{http://sita.aero/wtr/common/3/0}StringLength1to30"/>
     *       &lt;/choice>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "countryCode",
        "countryName"
    })
    public static class Country {

        @XmlElement(name = "CountryCode")
        protected String countryCode;
        @XmlElement(name = "CountryName")
        protected String countryName;

        /**
         * Gets the value of the countryCode property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getCountryCode() {
            return countryCode;
        }

        /**
         * Sets the value of the countryCode property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setCountryCode(String value) {
            this.countryCode = value;
        }

        /**
         * Gets the value of the countryName property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getCountryName() {
            return countryName;
        }

        /**
         * Sets the value of the countryName property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setCountryName(String value) {
            this.countryName = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="Email" type="{http://sita.aero/wtr/common/3/0}EmailType" maxOccurs="2"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "email"
    })
    public static class Emails {

        @XmlElement(name = "Email", required = true)
        protected List<String> email;

        /**
         * Gets the value of the email property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the email property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getEmail().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getEmail() {
            if (email == null) {
                email = new ArrayList<String>();
            }
            return this.email;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="Fax" type="{http://sita.aero/wtr/common/3/0}StringLength1to20" maxOccurs="2"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "fax"
    })
    public static class Faxes {

        @XmlElement(name = "Fax", required = true)
        protected List<String> fax;

        /**
         * Gets the value of the fax property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the fax property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getFax().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getFax() {
            if (fax == null) {
                fax = new ArrayList<String>();
            }
            return this.fax;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="Phone" type="{http://sita.aero/wtr/common/3/0}StringLength1to20" maxOccurs="2"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "phone"
    })
    public static class PermPhones {

        @XmlElement(name = "Phone", required = true)
        protected List<String> phone;

        /**
         * Gets the value of the phone property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the phone property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getPhone().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getPhone() {
            if (phone == null) {
                phone = new ArrayList<String>();
            }
            return this.phone;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="Address" type="{http://sita.aero/wtr/common/3/0}WTR_AddressType" minOccurs="0"/>
     *         &lt;element name="ValidityDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "address",
        "validityDate"
    })
    public static class TempAddress {

        @XmlElement(name = "Address")
        protected WTRAddressType address;
        @XmlElement(name = "ValidityDate")
        @XmlSchemaType(name = "date")
        protected XMLGregorianCalendar validityDate;

        /**
         * Gets the value of the address property.
         * 
         * @return
         *     possible object is
         *     {@link WTRAddressType }
         *     
         */
        public WTRAddressType getAddress() {
            return address;
        }

        /**
         * Sets the value of the address property.
         * 
         * @param value
         *     allowed object is
         *     {@link WTRAddressType }
         *     
         */
        public void setAddress(WTRAddressType value) {
            this.address = value;
        }

        /**
         * Gets the value of the validityDate property.
         * 
         * @return
         *     possible object is
         *     {@link XMLGregorianCalendar }
         *     
         */
        public XMLGregorianCalendar getValidityDate() {
            return validityDate;
        }

        /**
         * Sets the value of the validityDate property.
         * 
         * @param value
         *     allowed object is
         *     {@link XMLGregorianCalendar }
         *     
         */
        public void setValidityDate(XMLGregorianCalendar value) {
            this.validityDate = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="Phone" type="{http://sita.aero/wtr/common/3/0}StringLength1to20" maxOccurs="2"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "phone"
    })
    public static class TempPhones {

        @XmlElement(name = "Phone", required = true)
        protected List<String> phone;

        /**
         * Gets the value of the phone property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the phone property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getPhone().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getPhone() {
            if (phone == null) {
                phone = new ArrayList<String>();
            }
            return this.phone;
        }

    }

}


package aero.sita.wtr.common._3._0;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * This holds all the information in a rush bag record
 * 
 * <p>Java class for RushBagRecordType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="RushBagRecordType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="RushBagGroup" type="{http://sita.aero/wtr/common/3/0}RushBagGroupType"/>
 *         &lt;element name="ReasonForLossCode" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int">
 *               &lt;minInclusive value="10"/>
 *               &lt;maxInclusive value="99"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="LossComments" type="{http://sita.aero/wtr/common/3/0}StringLength1to58" minOccurs="0"/>
 *         &lt;element name="SupplimentalInfo" type="{http://sita.aero/wtr/common/3/0}StringLength1to58" maxOccurs="2" minOccurs="0"/>
 *         &lt;element name="FaultStationCode" type="{http://www.iata.org/IATA/2007/00}StationType" minOccurs="0"/>
 *         &lt;element name="FaultTerminal" type="{http://sita.aero/wtr/common/3/0}AlphaNumericStringLength1to2" minOccurs="0"/>
 *         &lt;element name="HandledAirlineCopyInd" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RushBagRecordType", propOrder = {
    "rushBagGroup",
    "reasonForLossCode",
    "lossComments",
    "supplimentalInfo",
    "faultStationCode",
    "faultTerminal",
    "handledAirlineCopyInd"
})
public class RushBagRecordType {

    @XmlElement(name = "RushBagGroup", required = true)
    protected RushBagGroupType rushBagGroup;
    @XmlElement(name = "ReasonForLossCode")
    protected Integer reasonForLossCode;
    @XmlElement(name = "LossComments")
    protected String lossComments;
    @XmlElement(name = "SupplimentalInfo")
    protected List<String> supplimentalInfo;
    @XmlElement(name = "FaultStationCode")
    protected String faultStationCode;
    @XmlElement(name = "FaultTerminal")
    protected String faultTerminal;
    @XmlElement(name = "HandledAirlineCopyInd")
    protected Boolean handledAirlineCopyInd;

    /**
     * Gets the value of the rushBagGroup property.
     * 
     * @return
     *     possible object is
     *     {@link RushBagGroupType }
     *     
     */
    public RushBagGroupType getRushBagGroup() {
        return rushBagGroup;
    }

    /**
     * Sets the value of the rushBagGroup property.
     * 
     * @param value
     *     allowed object is
     *     {@link RushBagGroupType }
     *     
     */
    public void setRushBagGroup(RushBagGroupType value) {
        this.rushBagGroup = value;
    }

    /**
     * Gets the value of the reasonForLossCode property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getReasonForLossCode() {
        return reasonForLossCode;
    }

    /**
     * Sets the value of the reasonForLossCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setReasonForLossCode(Integer value) {
        this.reasonForLossCode = value;
    }

    /**
     * Gets the value of the lossComments property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLossComments() {
        return lossComments;
    }

    /**
     * Sets the value of the lossComments property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLossComments(String value) {
        this.lossComments = value;
    }

    /**
     * Gets the value of the supplimentalInfo property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the supplimentalInfo property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSupplimentalInfo().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getSupplimentalInfo() {
        if (supplimentalInfo == null) {
            supplimentalInfo = new ArrayList<String>();
        }
        return this.supplimentalInfo;
    }

    /**
     * Gets the value of the faultStationCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFaultStationCode() {
        return faultStationCode;
    }

    /**
     * Sets the value of the faultStationCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFaultStationCode(String value) {
        this.faultStationCode = value;
    }

    /**
     * Gets the value of the faultTerminal property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFaultTerminal() {
        return faultTerminal;
    }

    /**
     * Sets the value of the faultTerminal property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFaultTerminal(String value) {
        this.faultTerminal = value;
    }

    /**
     * Gets the value of the handledAirlineCopyInd property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isHandledAirlineCopyInd() {
        return handledAirlineCopyInd;
    }

    /**
     * Sets the value of the handledAirlineCopyInd property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setHandledAirlineCopyInd(Boolean value) {
        this.handledAirlineCopyInd = value;
    }

}


package aero.sita.wtr.common._3._0;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for InboxAreaType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="InboxAreaType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}NMTOKEN">
 *     &lt;enumeration value="AA"/>
 *     &lt;enumeration value="AP"/>
 *     &lt;enumeration value="BC"/>
 *     &lt;enumeration value="CM"/>
 *     &lt;enumeration value="EC"/>
 *     &lt;enumeration value="EM"/>
 *     &lt;enumeration value="FW"/>
 *     &lt;enumeration value="HQ"/>
 *     &lt;enumeration value="IN"/>
 *     &lt;enumeration value="LM"/>
 *     &lt;enumeration value="PR"/>
 *     &lt;enumeration value="SP"/>
 *     &lt;enumeration value="WM"/>
 *     &lt;enumeration value="XX"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "InboxAreaType")
@XmlEnum
public enum InboxAreaType {

    AA,
    AP,
    BC,
    CM,
    EC,
    EM,
    FW,
    HQ,
    IN,
    LM,
    PR,
    SP,
    WM,
    XX;

    public String value() {
        return name();
    }

    public static InboxAreaType fromValue(String v) {
        return valueOf(v);
    }

}

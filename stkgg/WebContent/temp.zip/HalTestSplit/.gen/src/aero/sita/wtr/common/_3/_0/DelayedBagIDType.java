
package aero.sita.wtr.common._3._0;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * This identifies a Delayed record in the WorldTracer System and the sequence number(s) to associate to the Damaged bag being created.
 * 
 * <p>Java class for DelayedBagIDType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DelayedBagIDType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="RecordReference" type="{http://sita.aero/wtr/common/3/0}RecordReferenceType"/>
 *         &lt;element name="BagID" maxOccurs="10">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;attribute name="Seq">
 *                   &lt;simpleType>
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}short">
 *                       &lt;minInclusive value="1"/>
 *                       &lt;maxInclusive value="10"/>
 *                     &lt;/restriction>
 *                   &lt;/simpleType>
 *                 &lt;/attribute>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DelayedBagIDType", propOrder = {
    "recordReference",
    "bagID"
})
public class DelayedBagIDType {

    @XmlElement(name = "RecordReference", required = true)
    protected RecordReferenceType recordReference;
    @XmlElement(name = "BagID", required = true)
    protected List<DelayedBagIDType.BagID> bagID;

    /**
     * Gets the value of the recordReference property.
     * 
     * @return
     *     possible object is
     *     {@link RecordReferenceType }
     *     
     */
    public RecordReferenceType getRecordReference() {
        return recordReference;
    }

    /**
     * Sets the value of the recordReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link RecordReferenceType }
     *     
     */
    public void setRecordReference(RecordReferenceType value) {
        this.recordReference = value;
    }

    /**
     * Gets the value of the bagID property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the bagID property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getBagID().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DelayedBagIDType.BagID }
     * 
     * 
     */
    public List<DelayedBagIDType.BagID> getBagID() {
        if (bagID == null) {
            bagID = new ArrayList<DelayedBagIDType.BagID>();
        }
        return this.bagID;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;attribute name="Seq">
     *         &lt;simpleType>
     *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}short">
     *             &lt;minInclusive value="1"/>
     *             &lt;maxInclusive value="10"/>
     *           &lt;/restriction>
     *         &lt;/simpleType>
     *       &lt;/attribute>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "")
    public static class BagID {

        @XmlAttribute(name = "Seq")
        protected Short seq;

        /**
         * Gets the value of the seq property.
         * 
         * @return
         *     possible object is
         *     {@link Short }
         *     
         */
        public Short getSeq() {
            return seq;
        }

        /**
         * Sets the value of the seq property.
         * 
         * @param value
         *     allowed object is
         *     {@link Short }
         *     
         */
        public void setSeq(Short value) {
            this.seq = value;
        }

    }

}


package aero.sita.wtr.common._3._0;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for FlightSegmentOrARNKType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FlightSegmentOrARNKType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;choice>
 *         &lt;element name="FlightSegment" type="{http://sita.aero/wtr/common/3/0}FlightSegmentType"/>
 *         &lt;element name="ARNK" type="{http://sita.aero/wtr/common/3/0}ARNK_SegmentType"/>
 *       &lt;/choice>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FlightSegmentOrARNKType", propOrder = {
    "flightSegment",
    "arnk"
})
public class FlightSegmentOrARNKType {

    @XmlElement(name = "FlightSegment")
    protected FlightSegmentType flightSegment;
    @XmlElement(name = "ARNK")
    protected ARNKSegmentType arnk;

    /**
     * Gets the value of the flightSegment property.
     * 
     * @return
     *     possible object is
     *     {@link FlightSegmentType }
     *     
     */
    public FlightSegmentType getFlightSegment() {
        return flightSegment;
    }

    /**
     * Sets the value of the flightSegment property.
     * 
     * @param value
     *     allowed object is
     *     {@link FlightSegmentType }
     *     
     */
    public void setFlightSegment(FlightSegmentType value) {
        this.flightSegment = value;
    }

    /**
     * Gets the value of the arnk property.
     * 
     * @return
     *     possible object is
     *     {@link ARNKSegmentType }
     *     
     */
    public ARNKSegmentType getARNK() {
        return arnk;
    }

    /**
     * Sets the value of the arnk property.
     * 
     * @param value
     *     allowed object is
     *     {@link ARNKSegmentType }
     *     
     */
    public void setARNK(ARNKSegmentType value) {
        this.arnk = value;
    }

}


package aero.sita.wtr.common._3._0;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;


/**
 * TD - Type of damage
 * 
 * <p>Java class for DamageTypeType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DamageTypeType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;attribute name="Location" type="{http://sita.aero/wtr/common/3/0}DamageLocationType" />
 *       &lt;attribute name="Type" type="{http://www.iata.org/IATA/2007/00}IATA_CodeType" />
 *       &lt;attribute name="Amount" type="{http://sita.aero/wtr/common/3/0}DamageAmountType" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DamageTypeType")
public class DamageTypeType {

    @XmlAttribute(name = "Location")
    protected DamageLocationType location;
    @XmlAttribute(name = "Type")
    protected String type;
    @XmlAttribute(name = "Amount")
    protected DamageAmountType amount;

    /**
     * Gets the value of the location property.
     * 
     * @return
     *     possible object is
     *     {@link DamageLocationType }
     *     
     */
    public DamageLocationType getLocation() {
        return location;
    }

    /**
     * Sets the value of the location property.
     * 
     * @param value
     *     allowed object is
     *     {@link DamageLocationType }
     *     
     */
    public void setLocation(DamageLocationType value) {
        this.location = value;
    }

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setType(String value) {
        this.type = value;
    }

    /**
     * Gets the value of the amount property.
     * 
     * @return
     *     possible object is
     *     {@link DamageAmountType }
     *     
     */
    public DamageAmountType getAmount() {
        return amount;
    }

    /**
     * Sets the value of the amount property.
     * 
     * @param value
     *     allowed object is
     *     {@link DamageAmountType }
     *     
     */
    public void setAmount(DamageAmountType value) {
        this.amount = value;
    }

}


package aero.sita.wtr.common._3._0;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for RecordType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="RecordType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="DELAYED"/>
 *     &lt;enumeration value="ON-HAND"/>
 *     &lt;enumeration value="RUSH"/>
 *     &lt;enumeration value="DAMAGED"/>
 *     &lt;enumeration value="RUSH-DELAYED"/>
 *     &lt;enumeration value="RUSH-ONHAND"/>
 *     &lt;enumeration value="RUSH-LZ"/>
 *     &lt;enumeration value="QUICK-ONHAND"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "RecordType")
@XmlEnum
public enum RecordType {

    DELAYED("DELAYED"),
    @XmlEnumValue("ON-HAND")
    ON_HAND("ON-HAND"),
    RUSH("RUSH"),
    DAMAGED("DAMAGED"),
    @XmlEnumValue("RUSH-DELAYED")
    RUSH_DELAYED("RUSH-DELAYED"),
    @XmlEnumValue("RUSH-ONHAND")
    RUSH_ONHAND("RUSH-ONHAND"),
    @XmlEnumValue("RUSH-LZ")
    RUSH_LZ("RUSH-LZ"),
    @XmlEnumValue("QUICK-ONHAND")
    QUICK_ONHAND("QUICK-ONHAND");
    private final String value;

    RecordType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static RecordType fromValue(String v) {
        for (RecordType c: RecordType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}

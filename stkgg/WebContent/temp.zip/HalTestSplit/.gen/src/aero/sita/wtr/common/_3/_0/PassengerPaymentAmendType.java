
package aero.sita.wtr.common._3._0;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * Payment paid to passenger
 * 
 * <p>Java class for PassengerPaymentAmendType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PassengerPaymentAmendType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence minOccurs="0">
 *         &lt;element name="Type" type="{http://sita.aero/wtr/common/3/0}CostType"/>
 *         &lt;element name="Amount" type="{http://sita.aero/wtr/common/3/0}AmountType"/>
 *       &lt;/sequence>
 *       &lt;attGroup ref="{http://sita.aero/wtr/common/3/0}AmendGroup"/>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PassengerPaymentAmendType", propOrder = {
    "type",
    "amount"
})
public class PassengerPaymentAmendType {

    @XmlElement(name = "Type")
    protected CostType type;
    @XmlElement(name = "Amount")
    protected AmountType amount;
    @XmlAttribute(name = "Seq", required = true)
    protected int seq;
    @XmlAttribute(name = "Delete")
    protected Boolean delete;

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link CostType }
     *     
     */
    public CostType getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link CostType }
     *     
     */
    public void setType(CostType value) {
        this.type = value;
    }

    /**
     * Gets the value of the amount property.
     * 
     * @return
     *     possible object is
     *     {@link AmountType }
     *     
     */
    public AmountType getAmount() {
        return amount;
    }

    /**
     * Sets the value of the amount property.
     * 
     * @param value
     *     allowed object is
     *     {@link AmountType }
     *     
     */
    public void setAmount(AmountType value) {
        this.amount = value;
    }

    /**
     * Gets the value of the seq property.
     * 
     */
    public int getSeq() {
        return seq;
    }

    /**
     * Sets the value of the seq property.
     * 
     */
    public void setSeq(int value) {
        this.seq = value;
    }

    /**
     * Gets the value of the delete property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public boolean isDelete() {
        if (delete == null) {
            return false;
        } else {
            return delete;
        }
    }

    /**
     * Sets the value of the delete property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setDelete(Boolean value) {
        this.delete = value;
    }

}

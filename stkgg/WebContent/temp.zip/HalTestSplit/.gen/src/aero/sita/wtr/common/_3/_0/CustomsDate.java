
package aero.sita.wtr.common._3._0;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * Used for customs date for bags
 * 
 * <p>Java class for CustomsDate complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CustomsDate">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="BagDate" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="TimeZone" type="{http://sita.aero/wtr/common/3/0}AlphaLength2to3" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CustomsDate", propOrder = {
    "bagDate",
    "timeZone"
})
@XmlSeeAlso({
    aero.sita.wtr.common._3._0.BagAmendType.BagSentToCustoms.class,
    aero.sita.wtr.common._3._0.BagAmendType.BagReceivedFromCustoms.class
})
public class CustomsDate {

    @XmlElement(name = "BagDate", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar bagDate;
    @XmlElement(name = "TimeZone")
    protected String timeZone;

    /**
     * Gets the value of the bagDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getBagDate() {
        return bagDate;
    }

    /**
     * Sets the value of the bagDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setBagDate(XMLGregorianCalendar value) {
        this.bagDate = value;
    }

    /**
     * Gets the value of the timeZone property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTimeZone() {
        return timeZone;
    }

    /**
     * Sets the value of the timeZone property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTimeZone(String value) {
        this.timeZone = value;
    }

}

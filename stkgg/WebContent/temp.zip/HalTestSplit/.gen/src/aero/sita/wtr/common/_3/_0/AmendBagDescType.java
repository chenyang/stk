
package aero.sita.wtr.common._3._0;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * Maximum of the total elements should be 3. 1 MtrlElement + 2 OtherElement or 3 OtherElement
 * 
 * <p>Java class for AmendBagDescType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AmendBagDescType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="MtrlElement" type="{http://sita.aero/wtr/common/3/0}AmendBagMatrlType" minOccurs="0"/>
 *         &lt;element name="OtherElement" type="{http://sita.aero/wtr/common/3/0}AmendBagElmsType" maxOccurs="3" minOccurs="2"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AmendBagDescType", propOrder = {
    "mtrlElement",
    "otherElement"
})
public class AmendBagDescType {

    @XmlElement(name = "MtrlElement")
    protected String mtrlElement;
    @XmlElement(name = "OtherElement", required = true)
    protected List<String> otherElement;

    /**
     * Gets the value of the mtrlElement property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMtrlElement() {
        return mtrlElement;
    }

    /**
     * Sets the value of the mtrlElement property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMtrlElement(String value) {
        this.mtrlElement = value;
    }

    /**
     * Gets the value of the otherElement property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the otherElement property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getOtherElement().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getOtherElement() {
        if (otherElement == null) {
            otherElement = new ArrayList<String>();
        }
        return this.otherElement;
    }

}

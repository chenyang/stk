
package aero.sita.wtr.common._3._0;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for SearchTypeType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="SearchTypeType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}NMTOKEN">
 *     &lt;enumeration value="SIMPLE"/>
 *     &lt;enumeration value="ADVANCED"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "SearchTypeType")
@XmlEnum
public enum SearchTypeType {

    SIMPLE,
    ADVANCED;

    public String value() {
        return name();
    }

    public static SearchTypeType fromValue(String v) {
        return valueOf(v);
    }

}

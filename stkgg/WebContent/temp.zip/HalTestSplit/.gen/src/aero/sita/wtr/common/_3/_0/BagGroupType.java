
package aero.sita.wtr.common._3._0;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for BagGroupType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BagGroupType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="BagAddress" type="{http://sita.aero/wtr/common/3/0}WTR_AddressType" minOccurs="0"/>
 *         &lt;element name="BaggageWeight" type="{http://sita.aero/wtr/common/3/0}StringLength1to58" minOccurs="0"/>
 *         &lt;element name="ContentsGender" type="{http://sita.aero/wtr/common/3/0}GenderType" minOccurs="0"/>
 *         &lt;element name="Delivery" type="{http://sita.aero/wtr/common/3/0}DeliveryType" minOccurs="0"/>
 *         &lt;element name="BagPhones" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="Phone" type="{http://sita.aero/wtr/common/3/0}StringLength0to20" maxOccurs="2"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BagGroupType", propOrder = {
    "bagAddress",
    "baggageWeight",
    "contentsGender",
    "delivery",
    "bagPhones"
})
@XmlSeeAlso({
    DelayedBagGroupType.class,
    DamagedBagGroupType.class
})
public class BagGroupType {

    @XmlElement(name = "BagAddress")
    protected WTRAddressType bagAddress;
    @XmlElement(name = "BaggageWeight")
    protected String baggageWeight;
    @XmlElement(name = "ContentsGender")
    protected GenderType contentsGender;
    @XmlElement(name = "Delivery")
    protected DeliveryType delivery;
    @XmlElement(name = "BagPhones")
    protected BagGroupType.BagPhones bagPhones;

    /**
     * Gets the value of the bagAddress property.
     * 
     * @return
     *     possible object is
     *     {@link WTRAddressType }
     *     
     */
    public WTRAddressType getBagAddress() {
        return bagAddress;
    }

    /**
     * Sets the value of the bagAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link WTRAddressType }
     *     
     */
    public void setBagAddress(WTRAddressType value) {
        this.bagAddress = value;
    }

    /**
     * Gets the value of the baggageWeight property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBaggageWeight() {
        return baggageWeight;
    }

    /**
     * Sets the value of the baggageWeight property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBaggageWeight(String value) {
        this.baggageWeight = value;
    }

    /**
     * Gets the value of the contentsGender property.
     * 
     * @return
     *     possible object is
     *     {@link GenderType }
     *     
     */
    public GenderType getContentsGender() {
        return contentsGender;
    }

    /**
     * Sets the value of the contentsGender property.
     * 
     * @param value
     *     allowed object is
     *     {@link GenderType }
     *     
     */
    public void setContentsGender(GenderType value) {
        this.contentsGender = value;
    }

    /**
     * Gets the value of the delivery property.
     * 
     * @return
     *     possible object is
     *     {@link DeliveryType }
     *     
     */
    public DeliveryType getDelivery() {
        return delivery;
    }

    /**
     * Sets the value of the delivery property.
     * 
     * @param value
     *     allowed object is
     *     {@link DeliveryType }
     *     
     */
    public void setDelivery(DeliveryType value) {
        this.delivery = value;
    }

    /**
     * Gets the value of the bagPhones property.
     * 
     * @return
     *     possible object is
     *     {@link BagGroupType.BagPhones }
     *     
     */
    public BagGroupType.BagPhones getBagPhones() {
        return bagPhones;
    }

    /**
     * Sets the value of the bagPhones property.
     * 
     * @param value
     *     allowed object is
     *     {@link BagGroupType.BagPhones }
     *     
     */
    public void setBagPhones(BagGroupType.BagPhones value) {
        this.bagPhones = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="Phone" type="{http://sita.aero/wtr/common/3/0}StringLength0to20" maxOccurs="2"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "phone"
    })
    public static class BagPhones {

        @XmlElement(name = "Phone", required = true)
        protected List<String> phone;

        /**
         * Gets the value of the phone property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the phone property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getPhone().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getPhone() {
            if (phone == null) {
                phone = new ArrayList<String>();
            }
            return this.phone;
        }

    }

}

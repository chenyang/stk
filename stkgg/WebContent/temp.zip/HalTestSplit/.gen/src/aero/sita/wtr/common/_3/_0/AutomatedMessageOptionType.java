
package aero.sita.wtr.common._3._0;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AutomatedMessageOptionType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="AutomatedMessageOptionType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}NMTOKEN">
 *     &lt;enumeration value="SMS"/>
 *     &lt;enumeration value="EMAIL"/>
 *     &lt;enumeration value="SMS_AND_EMAIL"/>
 *     &lt;enumeration value="NO_MESSAGE"/>
 *     &lt;enumeration value="MANUAL"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "AutomatedMessageOptionType")
@XmlEnum
public enum AutomatedMessageOptionType {

    SMS,
    EMAIL,
    SMS_AND_EMAIL,
    NO_MESSAGE,
    MANUAL;

    public String value() {
        return name();
    }

    public static AutomatedMessageOptionType fromValue(String v) {
        return valueOf(v);
    }

}

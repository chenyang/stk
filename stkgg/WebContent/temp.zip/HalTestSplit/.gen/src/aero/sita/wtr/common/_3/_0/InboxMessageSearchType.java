
package aero.sita.wtr.common._3._0;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for InboxMessageSearchType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="InboxMessageSearchType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence minOccurs="0">
 *         &lt;element name="MessageRange" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="Range" maxOccurs="10">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;attribute name="Start" use="required" type="{http://www.w3.org/2001/XMLSchema}int" />
 *                           &lt;attribute name="End" type="{http://www.w3.org/2001/XMLSchema}int" />
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="DelayedBagRef" type="{http://sita.aero/wtr/common/3/0}RecordReferenceType" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attGroup ref="{http://sita.aero/wtr/common/3/0}InboxAreaAddressAttributes"/>
 *       &lt;attribute name="Day">
 *         &lt;simpleType>
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int">
 *             &lt;minInclusive value="1"/>
 *             &lt;maxInclusive value="7"/>
 *           &lt;/restriction>
 *         &lt;/simpleType>
 *       &lt;/attribute>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "InboxMessageSearchType", propOrder = {
    "messageRange",
    "delayedBagRef"
})
public class InboxMessageSearchType {

    @XmlElement(name = "MessageRange")
    protected InboxMessageSearchType.MessageRange messageRange;
    @XmlElement(name = "DelayedBagRef")
    protected RecordReferenceType delayedBagRef;
    @XmlAttribute(name = "Day")
    protected Integer day;
    @XmlAttribute(name = "StationCode", required = true)
    protected String stationCode;
    @XmlAttribute(name = "AirlineCode", required = true)
    protected String airlineCode;
    @XmlAttribute(name = "AreaType", required = true)
    protected InboxAreaType areaType;
    @XmlAttribute(name = "Seq")
    protected String seq;

    /**
     * Gets the value of the messageRange property.
     * 
     * @return
     *     possible object is
     *     {@link InboxMessageSearchType.MessageRange }
     *     
     */
    public InboxMessageSearchType.MessageRange getMessageRange() {
        return messageRange;
    }

    /**
     * Sets the value of the messageRange property.
     * 
     * @param value
     *     allowed object is
     *     {@link InboxMessageSearchType.MessageRange }
     *     
     */
    public void setMessageRange(InboxMessageSearchType.MessageRange value) {
        this.messageRange = value;
    }

    /**
     * Gets the value of the delayedBagRef property.
     * 
     * @return
     *     possible object is
     *     {@link RecordReferenceType }
     *     
     */
    public RecordReferenceType getDelayedBagRef() {
        return delayedBagRef;
    }

    /**
     * Sets the value of the delayedBagRef property.
     * 
     * @param value
     *     allowed object is
     *     {@link RecordReferenceType }
     *     
     */
    public void setDelayedBagRef(RecordReferenceType value) {
        this.delayedBagRef = value;
    }

    /**
     * Gets the value of the day property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getDay() {
        return day;
    }

    /**
     * Sets the value of the day property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setDay(Integer value) {
        this.day = value;
    }

    /**
     * Gets the value of the stationCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStationCode() {
        return stationCode;
    }

    /**
     * Sets the value of the stationCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStationCode(String value) {
        this.stationCode = value;
    }

    /**
     * Gets the value of the airlineCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAirlineCode() {
        return airlineCode;
    }

    /**
     * Sets the value of the airlineCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAirlineCode(String value) {
        this.airlineCode = value;
    }

    /**
     * Gets the value of the areaType property.
     * 
     * @return
     *     possible object is
     *     {@link InboxAreaType }
     *     
     */
    public InboxAreaType getAreaType() {
        return areaType;
    }

    /**
     * Sets the value of the areaType property.
     * 
     * @param value
     *     allowed object is
     *     {@link InboxAreaType }
     *     
     */
    public void setAreaType(InboxAreaType value) {
        this.areaType = value;
    }

    /**
     * Gets the value of the seq property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSeq() {
        return seq;
    }

    /**
     * Sets the value of the seq property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSeq(String value) {
        this.seq = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="Range" maxOccurs="10">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;attribute name="Start" use="required" type="{http://www.w3.org/2001/XMLSchema}int" />
     *                 &lt;attribute name="End" type="{http://www.w3.org/2001/XMLSchema}int" />
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "range"
    })
    public static class MessageRange {

        @XmlElement(name = "Range", required = true)
        protected List<InboxMessageSearchType.MessageRange.Range> range;

        /**
         * Gets the value of the range property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the range property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getRange().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link InboxMessageSearchType.MessageRange.Range }
         * 
         * 
         */
        public List<InboxMessageSearchType.MessageRange.Range> getRange() {
            if (range == null) {
                range = new ArrayList<InboxMessageSearchType.MessageRange.Range>();
            }
            return this.range;
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;attribute name="Start" use="required" type="{http://www.w3.org/2001/XMLSchema}int" />
         *       &lt;attribute name="End" type="{http://www.w3.org/2001/XMLSchema}int" />
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "")
        public static class Range {

            @XmlAttribute(name = "Start", required = true)
            protected int start;
            @XmlAttribute(name = "End")
            protected Integer end;

            /**
             * Gets the value of the start property.
             * 
             */
            public int getStart() {
                return start;
            }

            /**
             * Sets the value of the start property.
             * 
             */
            public void setStart(int value) {
                this.start = value;
            }

            /**
             * Gets the value of the end property.
             * 
             * @return
             *     possible object is
             *     {@link Integer }
             *     
             */
            public Integer getEnd() {
                return end;
            }

            /**
             * Sets the value of the end property.
             * 
             * @param value
             *     allowed object is
             *     {@link Integer }
             *     
             */
            public void setEnd(Integer value) {
                this.end = value;
            }

        }

    }

}


package aero.sita.wtr.common._3._0;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * Contains details of a passenger like name, address etc
 * 
 * <p>Java class for PassengerItineraryType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PassengerItineraryType">
 *   &lt;complexContent>
 *     &lt;extension base="{http://sita.aero/wtr/common/3/0}PassengerType">
 *       &lt;sequence>
 *         &lt;element name="Itinerary" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="FlightSegments">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="FlightSegmentOrARNK" type="{http://sita.aero/wtr/common/3/0}FlightSegmentOrARNKType" maxOccurs="5"/>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                   &lt;element name="AdditionalRoutes" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="Route" type="{http://www.iata.org/IATA/2007/00}StationType" maxOccurs="13"/>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="Status" type="{http://sita.aero/wtr/common/3/0}StringLength1to58" minOccurs="0"/>
 *         &lt;element name="PooledTktNumber" type="{http://sita.aero/wtr/common/3/0}AlphaNumericStringLength1to15" minOccurs="0"/>
 *         &lt;element name="FareBasis" type="{http://sita.aero/wtr/common/3/0}AlphaNumericStringLength1to7" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PassengerItineraryType", propOrder = {
    "itinerary",
    "status",
    "pooledTktNumber",
    "fareBasis"
})
public class PassengerItineraryType
    extends PassengerType
{

    @XmlElement(name = "Itinerary")
    protected PassengerItineraryType.Itinerary itinerary;
    @XmlElement(name = "Status")
    protected String status;
    @XmlElement(name = "PooledTktNumber")
    protected String pooledTktNumber;
    @XmlElement(name = "FareBasis")
    protected String fareBasis;

    /**
     * Gets the value of the itinerary property.
     * 
     * @return
     *     possible object is
     *     {@link PassengerItineraryType.Itinerary }
     *     
     */
    public PassengerItineraryType.Itinerary getItinerary() {
        return itinerary;
    }

    /**
     * Sets the value of the itinerary property.
     * 
     * @param value
     *     allowed object is
     *     {@link PassengerItineraryType.Itinerary }
     *     
     */
    public void setItinerary(PassengerItineraryType.Itinerary value) {
        this.itinerary = value;
    }

    /**
     * Gets the value of the status property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatus(String value) {
        this.status = value;
    }

    /**
     * Gets the value of the pooledTktNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPooledTktNumber() {
        return pooledTktNumber;
    }

    /**
     * Sets the value of the pooledTktNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPooledTktNumber(String value) {
        this.pooledTktNumber = value;
    }

    /**
     * Gets the value of the fareBasis property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFareBasis() {
        return fareBasis;
    }

    /**
     * Sets the value of the fareBasis property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFareBasis(String value) {
        this.fareBasis = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="FlightSegments">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="FlightSegmentOrARNK" type="{http://sita.aero/wtr/common/3/0}FlightSegmentOrARNKType" maxOccurs="5"/>
     *                 &lt;/sequence>
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *         &lt;element name="AdditionalRoutes" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="Route" type="{http://www.iata.org/IATA/2007/00}StationType" maxOccurs="13"/>
     *                 &lt;/sequence>
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "flightSegments",
        "additionalRoutes"
    })
    public static class Itinerary {

        @XmlElement(name = "FlightSegments", required = true)
        protected PassengerItineraryType.Itinerary.FlightSegments flightSegments;
        @XmlElement(name = "AdditionalRoutes")
        protected PassengerItineraryType.Itinerary.AdditionalRoutes additionalRoutes;

        /**
         * Gets the value of the flightSegments property.
         * 
         * @return
         *     possible object is
         *     {@link PassengerItineraryType.Itinerary.FlightSegments }
         *     
         */
        public PassengerItineraryType.Itinerary.FlightSegments getFlightSegments() {
            return flightSegments;
        }

        /**
         * Sets the value of the flightSegments property.
         * 
         * @param value
         *     allowed object is
         *     {@link PassengerItineraryType.Itinerary.FlightSegments }
         *     
         */
        public void setFlightSegments(PassengerItineraryType.Itinerary.FlightSegments value) {
            this.flightSegments = value;
        }

        /**
         * Gets the value of the additionalRoutes property.
         * 
         * @return
         *     possible object is
         *     {@link PassengerItineraryType.Itinerary.AdditionalRoutes }
         *     
         */
        public PassengerItineraryType.Itinerary.AdditionalRoutes getAdditionalRoutes() {
            return additionalRoutes;
        }

        /**
         * Sets the value of the additionalRoutes property.
         * 
         * @param value
         *     allowed object is
         *     {@link PassengerItineraryType.Itinerary.AdditionalRoutes }
         *     
         */
        public void setAdditionalRoutes(PassengerItineraryType.Itinerary.AdditionalRoutes value) {
            this.additionalRoutes = value;
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="Route" type="{http://www.iata.org/IATA/2007/00}StationType" maxOccurs="13"/>
         *       &lt;/sequence>
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "route"
        })
        public static class AdditionalRoutes {

            @XmlElement(name = "Route", required = true)
            protected List<String> route;

            /**
             * Gets the value of the route property.
             * 
             * <p>
             * This accessor method returns a reference to the live list,
             * not a snapshot. Therefore any modification you make to the
             * returned list will be present inside the JAXB object.
             * This is why there is not a <CODE>set</CODE> method for the route property.
             * 
             * <p>
             * For example, to add a new item, do as follows:
             * <pre>
             *    getRoute().add(newItem);
             * </pre>
             * 
             * 
             * <p>
             * Objects of the following type(s) are allowed in the list
             * {@link String }
             * 
             * 
             */
            public List<String> getRoute() {
                if (route == null) {
                    route = new ArrayList<String>();
                }
                return this.route;
            }

        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="FlightSegmentOrARNK" type="{http://sita.aero/wtr/common/3/0}FlightSegmentOrARNKType" maxOccurs="5"/>
         *       &lt;/sequence>
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "flightSegmentOrARNK"
        })
        public static class FlightSegments {

            @XmlElement(name = "FlightSegmentOrARNK", required = true)
            protected List<FlightSegmentOrARNKType> flightSegmentOrARNK;

            /**
             * Gets the value of the flightSegmentOrARNK property.
             * 
             * <p>
             * This accessor method returns a reference to the live list,
             * not a snapshot. Therefore any modification you make to the
             * returned list will be present inside the JAXB object.
             * This is why there is not a <CODE>set</CODE> method for the flightSegmentOrARNK property.
             * 
             * <p>
             * For example, to add a new item, do as follows:
             * <pre>
             *    getFlightSegmentOrARNK().add(newItem);
             * </pre>
             * 
             * 
             * <p>
             * Objects of the following type(s) are allowed in the list
             * {@link FlightSegmentOrARNKType }
             * 
             * 
             */
            public List<FlightSegmentOrARNKType> getFlightSegmentOrARNK() {
                if (flightSegmentOrARNK == null) {
                    flightSegmentOrARNK = new ArrayList<FlightSegmentOrARNKType>();
                }
                return this.flightSegmentOrARNK;
            }

        }

    }

}

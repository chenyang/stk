
package aero.sita.wtr.common._3._0;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PassengerType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PassengerType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Names" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="Name" type="{http://sita.aero/wtr/common/3/0}AlphaLength2to16" maxOccurs="3"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="Initials" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="Intial" type="{http://sita.aero/wtr/common/3/0}InitialType" maxOccurs="3"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="Title" type="{http://sita.aero/wtr/common/3/0}StringLength1to25" minOccurs="0"/>
 *         &lt;element name="ContactInfo" type="{http://sita.aero/wtr/common/3/0}ContactInfoType" minOccurs="0"/>
 *         &lt;element name="FrequentFlyerID" type="{http://sita.aero/wtr/common/3/0}StringLength1to25" minOccurs="0"/>
 *         &lt;element name="Language" type="{http://sita.aero/wtr/common/3/0}StringLength1to25" minOccurs="0"/>
 *         &lt;element name="TicketNumber" type="{http://sita.aero/wtr/common/3/0}StringLength1to58" minOccurs="0"/>
 *         &lt;element name="PNR" type="{http://sita.aero/wtr/common/3/0}AlphaNumericStringLength1to12" minOccurs="0"/>
 *         &lt;element name="NoOfPassengers" type="{http://sita.aero/wtr/common/3/0}StringLength1to58" minOccurs="0"/>
 *         &lt;element name="AutoMsgOption" type="{http://sita.aero/wtr/common/3/0}AutomatedMessageOptionType" minOccurs="0"/>
 *         &lt;element name="PassportInfo" type="{http://sita.aero/wtr/common/3/0}StringLength1to58" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PassengerType", propOrder = {
    "names",
    "initials",
    "title",
    "contactInfo",
    "frequentFlyerID",
    "language",
    "ticketNumber",
    "pnr",
    "noOfPassengers",
    "autoMsgOption",
    "passportInfo"
})
@XmlSeeAlso({
    PassengerItineraryType.class
})
public class PassengerType {

    @XmlElement(name = "Names")
    protected PassengerType.Names names;
    @XmlElement(name = "Initials")
    protected PassengerType.Initials initials;
    @XmlElement(name = "Title")
    protected String title;
    @XmlElement(name = "ContactInfo")
    protected ContactInfoType contactInfo;
    @XmlElement(name = "FrequentFlyerID")
    protected String frequentFlyerID;
    @XmlElement(name = "Language")
    protected String language;
    @XmlElement(name = "TicketNumber")
    protected String ticketNumber;
    @XmlElement(name = "PNR")
    protected String pnr;
    @XmlElement(name = "NoOfPassengers")
    protected String noOfPassengers;
    @XmlElement(name = "AutoMsgOption")
    protected AutomatedMessageOptionType autoMsgOption;
    @XmlElement(name = "PassportInfo")
    protected String passportInfo;

    /**
     * Gets the value of the names property.
     * 
     * @return
     *     possible object is
     *     {@link PassengerType.Names }
     *     
     */
    public PassengerType.Names getNames() {
        return names;
    }

    /**
     * Sets the value of the names property.
     * 
     * @param value
     *     allowed object is
     *     {@link PassengerType.Names }
     *     
     */
    public void setNames(PassengerType.Names value) {
        this.names = value;
    }

    /**
     * Gets the value of the initials property.
     * 
     * @return
     *     possible object is
     *     {@link PassengerType.Initials }
     *     
     */
    public PassengerType.Initials getInitials() {
        return initials;
    }

    /**
     * Sets the value of the initials property.
     * 
     * @param value
     *     allowed object is
     *     {@link PassengerType.Initials }
     *     
     */
    public void setInitials(PassengerType.Initials value) {
        this.initials = value;
    }

    /**
     * Gets the value of the title property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTitle() {
        return title;
    }

    /**
     * Sets the value of the title property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTitle(String value) {
        this.title = value;
    }

    /**
     * Gets the value of the contactInfo property.
     * 
     * @return
     *     possible object is
     *     {@link ContactInfoType }
     *     
     */
    public ContactInfoType getContactInfo() {
        return contactInfo;
    }

    /**
     * Sets the value of the contactInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link ContactInfoType }
     *     
     */
    public void setContactInfo(ContactInfoType value) {
        this.contactInfo = value;
    }

    /**
     * Gets the value of the frequentFlyerID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFrequentFlyerID() {
        return frequentFlyerID;
    }

    /**
     * Sets the value of the frequentFlyerID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFrequentFlyerID(String value) {
        this.frequentFlyerID = value;
    }

    /**
     * Gets the value of the language property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLanguage() {
        return language;
    }

    /**
     * Sets the value of the language property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLanguage(String value) {
        this.language = value;
    }

    /**
     * Gets the value of the ticketNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTicketNumber() {
        return ticketNumber;
    }

    /**
     * Sets the value of the ticketNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTicketNumber(String value) {
        this.ticketNumber = value;
    }

    /**
     * Gets the value of the pnr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPNR() {
        return pnr;
    }

    /**
     * Sets the value of the pnr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPNR(String value) {
        this.pnr = value;
    }

    /**
     * Gets the value of the noOfPassengers property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNoOfPassengers() {
        return noOfPassengers;
    }

    /**
     * Sets the value of the noOfPassengers property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNoOfPassengers(String value) {
        this.noOfPassengers = value;
    }

    /**
     * Gets the value of the autoMsgOption property.
     * 
     * @return
     *     possible object is
     *     {@link AutomatedMessageOptionType }
     *     
     */
    public AutomatedMessageOptionType getAutoMsgOption() {
        return autoMsgOption;
    }

    /**
     * Sets the value of the autoMsgOption property.
     * 
     * @param value
     *     allowed object is
     *     {@link AutomatedMessageOptionType }
     *     
     */
    public void setAutoMsgOption(AutomatedMessageOptionType value) {
        this.autoMsgOption = value;
    }

    /**
     * Gets the value of the passportInfo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPassportInfo() {
        return passportInfo;
    }

    /**
     * Sets the value of the passportInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPassportInfo(String value) {
        this.passportInfo = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="Intial" type="{http://sita.aero/wtr/common/3/0}InitialType" maxOccurs="3"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "intial"
    })
    public static class Initials {

        @XmlElement(name = "Intial", required = true)
        protected List<InitialType> intial;

        /**
         * Gets the value of the intial property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the intial property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getIntial().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link InitialType }
         * 
         * 
         */
        public List<InitialType> getIntial() {
            if (intial == null) {
                intial = new ArrayList<InitialType>();
            }
            return this.intial;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="Name" type="{http://sita.aero/wtr/common/3/0}AlphaLength2to16" maxOccurs="3"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "name"
    })
    public static class Names {

        @XmlElement(name = "Name", required = true)
        protected List<String> name;

        /**
         * Gets the value of the name property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the name property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getName().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getName() {
            if (name == null) {
                name = new ArrayList<String>();
            }
            return this.name;
        }

    }

}

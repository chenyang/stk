
package aero.sita.wtr.common._3._0;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * FD - Contians Flight date or ARNK
 * 
 * <p>Java class for FlightDateOrARNKType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FlightDateOrARNKType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;choice>
 *         &lt;element name="FlightDate" type="{http://sita.aero/wtr/common/3/0}FlightDateType"/>
 *         &lt;element name="ARNK" type="{http://sita.aero/wtr/common/3/0}ARNK_Type"/>
 *       &lt;/choice>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FlightDateOrARNKType", propOrder = {
    "flightDate",
    "arnk"
})
public class FlightDateOrARNKType {

    @XmlElement(name = "FlightDate")
    protected FlightDateType flightDate;
    @XmlElement(name = "ARNK")
    protected String arnk;

    /**
     * Gets the value of the flightDate property.
     * 
     * @return
     *     possible object is
     *     {@link FlightDateType }
     *     
     */
    public FlightDateType getFlightDate() {
        return flightDate;
    }

    /**
     * Sets the value of the flightDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link FlightDateType }
     *     
     */
    public void setFlightDate(FlightDateType value) {
        this.flightDate = value;
    }

    /**
     * Gets the value of the arnk property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getARNK() {
        return arnk;
    }

    /**
     * Sets the value of the arnk property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setARNK(String value) {
        this.arnk = value;
    }

}

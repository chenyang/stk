
package aero.sita.wtr.common._3._0;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DamagedBagType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DamagedBagType">
 *   &lt;complexContent>
 *     &lt;extension base="{http://sita.aero/wtr/common/3/0}BagType">
 *       &lt;sequence>
 *         &lt;element name="BagDetails" type="{http://sita.aero/wtr/common/3/0}StringLength1to58" minOccurs="0"/>
 *         &lt;element name="AssociatedRecord" type="{http://sita.aero/wtr/common/3/0}RecordIdentifierType" minOccurs="0"/>
 *         &lt;element name="DamageTypes" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="DamageType" type="{http://sita.aero/wtr/common/3/0}DamageTypeType" maxOccurs="2"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DamagedBagType", propOrder = {
    "bagDetails",
    "associatedRecord",
    "damageTypes"
})
public class DamagedBagType
    extends BagType
{

    @XmlElement(name = "BagDetails")
    protected String bagDetails;
    @XmlElement(name = "AssociatedRecord")
    protected RecordIdentifierType associatedRecord;
    @XmlElement(name = "DamageTypes")
    protected DamagedBagType.DamageTypes damageTypes;

    /**
     * Gets the value of the bagDetails property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBagDetails() {
        return bagDetails;
    }

    /**
     * Sets the value of the bagDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBagDetails(String value) {
        this.bagDetails = value;
    }

    /**
     * Gets the value of the associatedRecord property.
     * 
     * @return
     *     possible object is
     *     {@link RecordIdentifierType }
     *     
     */
    public RecordIdentifierType getAssociatedRecord() {
        return associatedRecord;
    }

    /**
     * Sets the value of the associatedRecord property.
     * 
     * @param value
     *     allowed object is
     *     {@link RecordIdentifierType }
     *     
     */
    public void setAssociatedRecord(RecordIdentifierType value) {
        this.associatedRecord = value;
    }

    /**
     * Gets the value of the damageTypes property.
     * 
     * @return
     *     possible object is
     *     {@link DamagedBagType.DamageTypes }
     *     
     */
    public DamagedBagType.DamageTypes getDamageTypes() {
        return damageTypes;
    }

    /**
     * Sets the value of the damageTypes property.
     * 
     * @param value
     *     allowed object is
     *     {@link DamagedBagType.DamageTypes }
     *     
     */
    public void setDamageTypes(DamagedBagType.DamageTypes value) {
        this.damageTypes = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="DamageType" type="{http://sita.aero/wtr/common/3/0}DamageTypeType" maxOccurs="2"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "damageType"
    })
    public static class DamageTypes {

        @XmlElement(name = "DamageType", required = true)
        protected List<DamageTypeType> damageType;

        /**
         * Gets the value of the damageType property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the damageType property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getDamageType().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link DamageTypeType }
         * 
         * 
         */
        public List<DamageTypeType> getDamageType() {
            if (damageType == null) {
                damageType = new ArrayList<DamageTypeType>();
            }
            return this.damageType;
        }

    }

}


package aero.sita.wtr.common._3._0;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * Contains information about the delivery of a particular bag
 * 
 * <p>Java class for BagDeliveryType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BagDeliveryType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="DeliveredTime" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="Status" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="OutForDelivery" type="{http://sita.aero/wtr/common/3/0}StringLength0to58" minOccurs="0"/>
 *                   &lt;element name="Delivered" type="{http://sita.aero/wtr/common/3/0}StringLength0to58" minOccurs="0"/>
 *                   &lt;element name="UnableToDeliver" type="{http://sita.aero/wtr/common/3/0}StringLength0to58" minOccurs="0"/>
 *                   &lt;element name="TrackingUpdate" type="{http://sita.aero/wtr/common/3/0}StringLength0to58" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="BagReceivedDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="BagReceived" type="{http://sita.aero/wtr/common/3/0}BagReceivedType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BagDeliveryType", propOrder = {
    "deliveredTime",
    "status",
    "bagReceivedDate",
    "bagReceived"
})
public class BagDeliveryType {

    @XmlElement(name = "DeliveredTime")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar deliveredTime;
    @XmlElement(name = "Status")
    protected BagDeliveryType.Status status;
    @XmlElement(name = "BagReceivedDate")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar bagReceivedDate;
    @XmlElement(name = "BagReceived")
    protected BagReceivedType bagReceived;

    /**
     * Gets the value of the deliveredTime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDeliveredTime() {
        return deliveredTime;
    }

    /**
     * Sets the value of the deliveredTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDeliveredTime(XMLGregorianCalendar value) {
        this.deliveredTime = value;
    }

    /**
     * Gets the value of the status property.
     * 
     * @return
     *     possible object is
     *     {@link BagDeliveryType.Status }
     *     
     */
    public BagDeliveryType.Status getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link BagDeliveryType.Status }
     *     
     */
    public void setStatus(BagDeliveryType.Status value) {
        this.status = value;
    }

    /**
     * Gets the value of the bagReceivedDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getBagReceivedDate() {
        return bagReceivedDate;
    }

    /**
     * Sets the value of the bagReceivedDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setBagReceivedDate(XMLGregorianCalendar value) {
        this.bagReceivedDate = value;
    }

    /**
     * Gets the value of the bagReceived property.
     * 
     * @return
     *     possible object is
     *     {@link BagReceivedType }
     *     
     */
    public BagReceivedType getBagReceived() {
        return bagReceived;
    }

    /**
     * Sets the value of the bagReceived property.
     * 
     * @param value
     *     allowed object is
     *     {@link BagReceivedType }
     *     
     */
    public void setBagReceived(BagReceivedType value) {
        this.bagReceived = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="OutForDelivery" type="{http://sita.aero/wtr/common/3/0}StringLength0to58" minOccurs="0"/>
     *         &lt;element name="Delivered" type="{http://sita.aero/wtr/common/3/0}StringLength0to58" minOccurs="0"/>
     *         &lt;element name="UnableToDeliver" type="{http://sita.aero/wtr/common/3/0}StringLength0to58" minOccurs="0"/>
     *         &lt;element name="TrackingUpdate" type="{http://sita.aero/wtr/common/3/0}StringLength0to58" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "outForDelivery",
        "delivered",
        "unableToDeliver",
        "trackingUpdate"
    })
    public static class Status {

        @XmlElement(name = "OutForDelivery")
        protected String outForDelivery;
        @XmlElement(name = "Delivered")
        protected String delivered;
        @XmlElement(name = "UnableToDeliver")
        protected String unableToDeliver;
        @XmlElement(name = "TrackingUpdate")
        protected String trackingUpdate;

        /**
         * Gets the value of the outForDelivery property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getOutForDelivery() {
            return outForDelivery;
        }

        /**
         * Sets the value of the outForDelivery property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setOutForDelivery(String value) {
            this.outForDelivery = value;
        }

        /**
         * Gets the value of the delivered property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getDelivered() {
            return delivered;
        }

        /**
         * Sets the value of the delivered property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setDelivered(String value) {
            this.delivered = value;
        }

        /**
         * Gets the value of the unableToDeliver property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getUnableToDeliver() {
            return unableToDeliver;
        }

        /**
         * Sets the value of the unableToDeliver property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setUnableToDeliver(String value) {
            this.unableToDeliver = value;
        }

        /**
         * Gets the value of the trackingUpdate property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getTrackingUpdate() {
            return trackingUpdate;
        }

        /**
         * Sets the value of the trackingUpdate property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setTrackingUpdate(String value) {
            this.trackingUpdate = value;
        }

    }

}

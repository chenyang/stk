
package aero.sita.wtr.common._3._0;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for RecordStatus.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="RecordStatus">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}NMTOKEN">
 *     &lt;enumeration value="ACTIVE"/>
 *     &lt;enumeration value="CLOSED"/>
 *     &lt;enumeration value="SUSPENDED"/>
 *     &lt;enumeration value="NON-TRACING"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "RecordStatus")
@XmlEnum
public enum RecordStatus {

    ACTIVE("ACTIVE"),
    CLOSED("CLOSED"),
    SUSPENDED("SUSPENDED"),
    @XmlEnumValue("NON-TRACING")
    NON_TRACING("NON-TRACING");
    private final String value;

    RecordStatus(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static RecordStatus fromValue(String v) {
        for (RecordStatus c: RecordStatus.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}


package aero.sita.wtr.common._3._0;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * Contians summary of a bag
 * 
 * <p>Java class for BagSummaryType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BagSummaryType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="BagTag" type="{http://sita.aero/wtr/common/3/0}BagTagType" minOccurs="0"/>
 *         &lt;element name="ColorType" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;attribute name="ColorCode" type="{http://sita.aero/wtr/common/3/0}ColorCodeType" />
 *                 &lt;attribute name="TypeCode" type="{http://sita.aero/wtr/common/3/0}BagTypeCodeType" />
 *                 &lt;attribute name="Suspended" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="FlightDateOrARNK" type="{http://sita.aero/wtr/common/3/0}FlightDateOrARNKType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BagSummaryType", propOrder = {
    "bagTag",
    "colorType",
    "flightDateOrARNK"
})
public class BagSummaryType {

    @XmlElement(name = "BagTag")
    protected BagTagType bagTag;
    @XmlElement(name = "ColorType")
    protected BagSummaryType.ColorType colorType;
    @XmlElement(name = "FlightDateOrARNK")
    protected FlightDateOrARNKType flightDateOrARNK;

    /**
     * Gets the value of the bagTag property.
     * 
     * @return
     *     possible object is
     *     {@link BagTagType }
     *     
     */
    public BagTagType getBagTag() {
        return bagTag;
    }

    /**
     * Sets the value of the bagTag property.
     * 
     * @param value
     *     allowed object is
     *     {@link BagTagType }
     *     
     */
    public void setBagTag(BagTagType value) {
        this.bagTag = value;
    }

    /**
     * Gets the value of the colorType property.
     * 
     * @return
     *     possible object is
     *     {@link BagSummaryType.ColorType }
     *     
     */
    public BagSummaryType.ColorType getColorType() {
        return colorType;
    }

    /**
     * Sets the value of the colorType property.
     * 
     * @param value
     *     allowed object is
     *     {@link BagSummaryType.ColorType }
     *     
     */
    public void setColorType(BagSummaryType.ColorType value) {
        this.colorType = value;
    }

    /**
     * Gets the value of the flightDateOrARNK property.
     * 
     * @return
     *     possible object is
     *     {@link FlightDateOrARNKType }
     *     
     */
    public FlightDateOrARNKType getFlightDateOrARNK() {
        return flightDateOrARNK;
    }

    /**
     * Sets the value of the flightDateOrARNK property.
     * 
     * @param value
     *     allowed object is
     *     {@link FlightDateOrARNKType }
     *     
     */
    public void setFlightDateOrARNK(FlightDateOrARNKType value) {
        this.flightDateOrARNK = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;attribute name="ColorCode" type="{http://sita.aero/wtr/common/3/0}ColorCodeType" />
     *       &lt;attribute name="TypeCode" type="{http://sita.aero/wtr/common/3/0}BagTypeCodeType" />
     *       &lt;attribute name="Suspended" type="{http://www.w3.org/2001/XMLSchema}boolean" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "")
    public static class ColorType {

        @XmlAttribute(name = "ColorCode")
        protected ColorCodeType colorCode;
        @XmlAttribute(name = "TypeCode")
        protected Integer typeCode;
        @XmlAttribute(name = "Suspended")
        protected Boolean suspended;

        /**
         * Gets the value of the colorCode property.
         * 
         * @return
         *     possible object is
         *     {@link ColorCodeType }
         *     
         */
        public ColorCodeType getColorCode() {
            return colorCode;
        }

        /**
         * Sets the value of the colorCode property.
         * 
         * @param value
         *     allowed object is
         *     {@link ColorCodeType }
         *     
         */
        public void setColorCode(ColorCodeType value) {
            this.colorCode = value;
        }

        /**
         * Gets the value of the typeCode property.
         * 
         * @return
         *     possible object is
         *     {@link Integer }
         *     
         */
        public Integer getTypeCode() {
            return typeCode;
        }

        /**
         * Sets the value of the typeCode property.
         * 
         * @param value
         *     allowed object is
         *     {@link Integer }
         *     
         */
        public void setTypeCode(Integer value) {
            this.typeCode = value;
        }

        /**
         * Gets the value of the suspended property.
         * 
         * @return
         *     possible object is
         *     {@link Boolean }
         *     
         */
        public Boolean isSuspended() {
            return suspended;
        }

        /**
         * Sets the value of the suspended property.
         * 
         * @param value
         *     allowed object is
         *     {@link Boolean }
         *     
         */
        public void setSuspended(Boolean value) {
            this.suspended = value;
        }

    }

}

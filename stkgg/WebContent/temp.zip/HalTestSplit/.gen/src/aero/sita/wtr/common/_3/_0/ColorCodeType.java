
package aero.sita.wtr.common._3._0;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ColorCodeType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="ColorCodeType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="WT"/>
 *     &lt;enumeration value="BK"/>
 *     &lt;enumeration value="GY"/>
 *     &lt;enumeration value="BU"/>
 *     &lt;enumeration value="RD"/>
 *     &lt;enumeration value="YW"/>
 *     &lt;enumeration value="BE"/>
 *     &lt;enumeration value="BN"/>
 *     &lt;enumeration value="GN"/>
 *     &lt;enumeration value="MC"/>
 *     &lt;enumeration value="PU"/>
 *     &lt;enumeration value="PR"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "ColorCodeType")
@XmlEnum
public enum ColorCodeType {

    WT,
    BK,
    GY,
    BU,
    RD,
    YW,
    BE,
    BN,
    GN,
    MC,
    PU,
    PR;

    public String value() {
        return name();
    }

    public static ColorCodeType fromValue(String v) {
        return valueOf(v);
    }

}

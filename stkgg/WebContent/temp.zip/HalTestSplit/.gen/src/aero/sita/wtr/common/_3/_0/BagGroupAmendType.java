
package aero.sita.wtr.common._3._0;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;


/**
 * <p>Java class for BagGroupAmendType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BagGroupAmendType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="BagAddress" type="{http://sita.aero/wtr/common/3/0}WTR_AddressAmendType" minOccurs="0"/>
 *         &lt;element name="BaggageWeight" minOccurs="0">
 *           &lt;complexType>
 *             &lt;simpleContent>
 *               &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>StringLength0to58">
 *                 &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
 *               &lt;/extension>
 *             &lt;/simpleContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="ContentsGender" minOccurs="0">
 *           &lt;complexType>
 *             &lt;simpleContent>
 *               &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>GenderType">
 *                 &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
 *               &lt;/extension>
 *             &lt;/simpleContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="Delivery" type="{http://sita.aero/wtr/common/3/0}DeliveryAmendType" minOccurs="0"/>
 *         &lt;element name="BagPhones" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="Phone" type="{http://sita.aero/wtr/common/3/0}PhoneAmendType" maxOccurs="2"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BagGroupAmendType", propOrder = {
    "bagAddress",
    "baggageWeight",
    "contentsGender",
    "delivery",
    "bagPhones"
})
@XmlSeeAlso({
    DelayedBagGroupAmendType.class,
    DamagedBagGroupAmendType.class
})
public class BagGroupAmendType {

    @XmlElement(name = "BagAddress")
    protected WTRAddressAmendType bagAddress;
    @XmlElement(name = "BaggageWeight")
    protected BagGroupAmendType.BaggageWeight baggageWeight;
    @XmlElement(name = "ContentsGender")
    protected BagGroupAmendType.ContentsGender contentsGender;
    @XmlElement(name = "Delivery")
    protected DeliveryAmendType delivery;
    @XmlElement(name = "BagPhones")
    protected BagGroupAmendType.BagPhones bagPhones;

    /**
     * Gets the value of the bagAddress property.
     * 
     * @return
     *     possible object is
     *     {@link WTRAddressAmendType }
     *     
     */
    public WTRAddressAmendType getBagAddress() {
        return bagAddress;
    }

    /**
     * Sets the value of the bagAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link WTRAddressAmendType }
     *     
     */
    public void setBagAddress(WTRAddressAmendType value) {
        this.bagAddress = value;
    }

    /**
     * Gets the value of the baggageWeight property.
     * 
     * @return
     *     possible object is
     *     {@link BagGroupAmendType.BaggageWeight }
     *     
     */
    public BagGroupAmendType.BaggageWeight getBaggageWeight() {
        return baggageWeight;
    }

    /**
     * Sets the value of the baggageWeight property.
     * 
     * @param value
     *     allowed object is
     *     {@link BagGroupAmendType.BaggageWeight }
     *     
     */
    public void setBaggageWeight(BagGroupAmendType.BaggageWeight value) {
        this.baggageWeight = value;
    }

    /**
     * Gets the value of the contentsGender property.
     * 
     * @return
     *     possible object is
     *     {@link BagGroupAmendType.ContentsGender }
     *     
     */
    public BagGroupAmendType.ContentsGender getContentsGender() {
        return contentsGender;
    }

    /**
     * Sets the value of the contentsGender property.
     * 
     * @param value
     *     allowed object is
     *     {@link BagGroupAmendType.ContentsGender }
     *     
     */
    public void setContentsGender(BagGroupAmendType.ContentsGender value) {
        this.contentsGender = value;
    }

    /**
     * Gets the value of the delivery property.
     * 
     * @return
     *     possible object is
     *     {@link DeliveryAmendType }
     *     
     */
    public DeliveryAmendType getDelivery() {
        return delivery;
    }

    /**
     * Sets the value of the delivery property.
     * 
     * @param value
     *     allowed object is
     *     {@link DeliveryAmendType }
     *     
     */
    public void setDelivery(DeliveryAmendType value) {
        this.delivery = value;
    }

    /**
     * Gets the value of the bagPhones property.
     * 
     * @return
     *     possible object is
     *     {@link BagGroupAmendType.BagPhones }
     *     
     */
    public BagGroupAmendType.BagPhones getBagPhones() {
        return bagPhones;
    }

    /**
     * Sets the value of the bagPhones property.
     * 
     * @param value
     *     allowed object is
     *     {@link BagGroupAmendType.BagPhones }
     *     
     */
    public void setBagPhones(BagGroupAmendType.BagPhones value) {
        this.bagPhones = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="Phone" type="{http://sita.aero/wtr/common/3/0}PhoneAmendType" maxOccurs="2"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "phone"
    })
    public static class BagPhones {

        @XmlElement(name = "Phone", required = true)
        protected List<PhoneAmendType> phone;

        /**
         * Gets the value of the phone property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the phone property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getPhone().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link PhoneAmendType }
         * 
         * 
         */
        public List<PhoneAmendType> getPhone() {
            if (phone == null) {
                phone = new ArrayList<PhoneAmendType>();
            }
            return this.phone;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;simpleContent>
     *     &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>StringLength0to58">
     *       &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
     *     &lt;/extension>
     *   &lt;/simpleContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class BaggageWeight {

        @XmlValue
        protected String value;
        @XmlAttribute(name = "Delete")
        protected Boolean delete;

        /**
         * Used for Character Strings, length 0 to 58
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setValue(String value) {
            this.value = value;
        }

        /**
         * Gets the value of the delete property.
         * 
         * @return
         *     possible object is
         *     {@link Boolean }
         *     
         */
        public boolean isDelete() {
            if (delete == null) {
                return false;
            } else {
                return delete;
            }
        }

        /**
         * Sets the value of the delete property.
         * 
         * @param value
         *     allowed object is
         *     {@link Boolean }
         *     
         */
        public void setDelete(Boolean value) {
            this.delete = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;simpleContent>
     *     &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>GenderType">
     *       &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
     *     &lt;/extension>
     *   &lt;/simpleContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class ContentsGender {

        @XmlValue
        protected GenderType value;
        @XmlAttribute(name = "Delete")
        protected Boolean delete;

        /**
         * Indicate M for male or F for female
         * 
         * @return
         *     possible object is
         *     {@link GenderType }
         *     
         */
        public GenderType getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link GenderType }
         *     
         */
        public void setValue(GenderType value) {
            this.value = value;
        }

        /**
         * Gets the value of the delete property.
         * 
         * @return
         *     possible object is
         *     {@link Boolean }
         *     
         */
        public boolean isDelete() {
            if (delete == null) {
                return false;
            } else {
                return delete;
            }
        }

        /**
         * Sets the value of the delete property.
         * 
         * @param value
         *     allowed object is
         *     {@link Boolean }
         *     
         */
        public void setDelete(Boolean value) {
            this.delete = value;
        }

    }

}

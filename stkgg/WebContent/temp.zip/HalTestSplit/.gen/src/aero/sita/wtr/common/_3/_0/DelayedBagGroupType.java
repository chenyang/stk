
package aero.sita.wtr.common._3._0;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DelayedBagGroupType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DelayedBagGroupType">
 *   &lt;complexContent>
 *     &lt;extension base="{http://sita.aero/wtr/common/3/0}BagGroupType">
 *       &lt;sequence>
 *         &lt;element name="DelayedBags">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="DelayedBag" type="{http://sita.aero/wtr/common/3/0}DelayedBagType" maxOccurs="10"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="BagLastSeen" type="{http://www.iata.org/IATA/2007/00}StationType" minOccurs="0"/>
 *         &lt;element name="BaggageItinerary" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="FlightDateOrARNK" type="{http://sita.aero/wtr/common/3/0}FlightDateOrARNKType" maxOccurs="5"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="ExcessBaggage" type="{http://sita.aero/wtr/common/3/0}AlphaNumericStringLength1to15" minOccurs="0"/>
 *         &lt;element name="BagTagDestinations" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="Station" type="{http://www.iata.org/IATA/2007/00}StationType" maxOccurs="2"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="KeysCollected" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="MissingWeight" type="{http://sita.aero/wtr/common/3/0}StringLength1to9" minOccurs="0"/>
 *         &lt;element name="MatchWindow" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int">
 *               &lt;minInclusive value="1"/>
 *               &lt;maxInclusive value="99"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DelayedBagGroupType", propOrder = {
    "delayedBags",
    "bagLastSeen",
    "baggageItinerary",
    "excessBaggage",
    "bagTagDestinations",
    "keysCollected",
    "missingWeight",
    "matchWindow"
})
public class DelayedBagGroupType
    extends BagGroupType
{

    @XmlElement(name = "DelayedBags", required = true)
    protected DelayedBagGroupType.DelayedBags delayedBags;
    @XmlElement(name = "BagLastSeen")
    protected String bagLastSeen;
    @XmlElement(name = "BaggageItinerary")
    protected DelayedBagGroupType.BaggageItinerary baggageItinerary;
    @XmlElement(name = "ExcessBaggage")
    protected String excessBaggage;
    @XmlElement(name = "BagTagDestinations")
    protected DelayedBagGroupType.BagTagDestinations bagTagDestinations;
    @XmlElement(name = "KeysCollected")
    protected Boolean keysCollected;
    @XmlElement(name = "MissingWeight")
    protected String missingWeight;
    @XmlElement(name = "MatchWindow")
    protected Integer matchWindow;

    /**
     * Gets the value of the delayedBags property.
     * 
     * @return
     *     possible object is
     *     {@link DelayedBagGroupType.DelayedBags }
     *     
     */
    public DelayedBagGroupType.DelayedBags getDelayedBags() {
        return delayedBags;
    }

    /**
     * Sets the value of the delayedBags property.
     * 
     * @param value
     *     allowed object is
     *     {@link DelayedBagGroupType.DelayedBags }
     *     
     */
    public void setDelayedBags(DelayedBagGroupType.DelayedBags value) {
        this.delayedBags = value;
    }

    /**
     * Gets the value of the bagLastSeen property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBagLastSeen() {
        return bagLastSeen;
    }

    /**
     * Sets the value of the bagLastSeen property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBagLastSeen(String value) {
        this.bagLastSeen = value;
    }

    /**
     * Gets the value of the baggageItinerary property.
     * 
     * @return
     *     possible object is
     *     {@link DelayedBagGroupType.BaggageItinerary }
     *     
     */
    public DelayedBagGroupType.BaggageItinerary getBaggageItinerary() {
        return baggageItinerary;
    }

    /**
     * Sets the value of the baggageItinerary property.
     * 
     * @param value
     *     allowed object is
     *     {@link DelayedBagGroupType.BaggageItinerary }
     *     
     */
    public void setBaggageItinerary(DelayedBagGroupType.BaggageItinerary value) {
        this.baggageItinerary = value;
    }

    /**
     * Gets the value of the excessBaggage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExcessBaggage() {
        return excessBaggage;
    }

    /**
     * Sets the value of the excessBaggage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExcessBaggage(String value) {
        this.excessBaggage = value;
    }

    /**
     * Gets the value of the bagTagDestinations property.
     * 
     * @return
     *     possible object is
     *     {@link DelayedBagGroupType.BagTagDestinations }
     *     
     */
    public DelayedBagGroupType.BagTagDestinations getBagTagDestinations() {
        return bagTagDestinations;
    }

    /**
     * Sets the value of the bagTagDestinations property.
     * 
     * @param value
     *     allowed object is
     *     {@link DelayedBagGroupType.BagTagDestinations }
     *     
     */
    public void setBagTagDestinations(DelayedBagGroupType.BagTagDestinations value) {
        this.bagTagDestinations = value;
    }

    /**
     * Gets the value of the keysCollected property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isKeysCollected() {
        return keysCollected;
    }

    /**
     * Sets the value of the keysCollected property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setKeysCollected(Boolean value) {
        this.keysCollected = value;
    }

    /**
     * Gets the value of the missingWeight property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMissingWeight() {
        return missingWeight;
    }

    /**
     * Sets the value of the missingWeight property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMissingWeight(String value) {
        this.missingWeight = value;
    }

    /**
     * Gets the value of the matchWindow property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getMatchWindow() {
        return matchWindow;
    }

    /**
     * Sets the value of the matchWindow property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setMatchWindow(Integer value) {
        this.matchWindow = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="Station" type="{http://www.iata.org/IATA/2007/00}StationType" maxOccurs="2"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "station"
    })
    public static class BagTagDestinations {

        @XmlElement(name = "Station", required = true)
        protected List<String> station;

        /**
         * Gets the value of the station property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the station property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getStation().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getStation() {
            if (station == null) {
                station = new ArrayList<String>();
            }
            return this.station;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="FlightDateOrARNK" type="{http://sita.aero/wtr/common/3/0}FlightDateOrARNKType" maxOccurs="5"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "flightDateOrARNK"
    })
    public static class BaggageItinerary {

        @XmlElement(name = "FlightDateOrARNK", required = true)
        protected List<FlightDateOrARNKType> flightDateOrARNK;

        /**
         * Gets the value of the flightDateOrARNK property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the flightDateOrARNK property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getFlightDateOrARNK().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link FlightDateOrARNKType }
         * 
         * 
         */
        public List<FlightDateOrARNKType> getFlightDateOrARNK() {
            if (flightDateOrARNK == null) {
                flightDateOrARNK = new ArrayList<FlightDateOrARNKType>();
            }
            return this.flightDateOrARNK;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="DelayedBag" type="{http://sita.aero/wtr/common/3/0}DelayedBagType" maxOccurs="10"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "delayedBag"
    })
    public static class DelayedBags {

        @XmlElement(name = "DelayedBag", required = true)
        protected List<DelayedBagType> delayedBag;

        /**
         * Gets the value of the delayedBag property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the delayedBag property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getDelayedBag().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link DelayedBagType }
         * 
         * 
         */
        public List<DelayedBagType> getDelayedBag() {
            if (delayedBag == null) {
                delayedBag = new ArrayList<DelayedBagType>();
            }
            return this.delayedBag;
        }

    }

}

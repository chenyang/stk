
package aero.sita.wtr.common._3._0;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;


/**
 * This holds information about the damaged bag group for amends
 * 
 * <p>Java class for DamagedBagGroupAmendType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DamagedBagGroupAmendType">
 *   &lt;complexContent>
 *     &lt;extension base="{http://sita.aero/wtr/common/3/0}BagGroupAmendType">
 *       &lt;sequence>
 *         &lt;element name="DamagedBags" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="DamagedBag" maxOccurs="10">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;extension base="{http://sita.aero/wtr/common/3/0}DamagedBagAmendType">
 *                           &lt;attribute name="Seq" use="required" type="{http://www.w3.org/2001/XMLSchema}int" />
 *                         &lt;/extension>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="BaggageItinerary" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence minOccurs="0">
 *                   &lt;element name="FlightDateOrARNK" type="{http://sita.aero/wtr/common/3/0}FlightDateOrARNKType" maxOccurs="5"/>
 *                 &lt;/sequence>
 *                 &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="ExcessBaggage" minOccurs="0">
 *           &lt;complexType>
 *             &lt;simpleContent>
 *               &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>AlphaNumericStringLength0to15">
 *                 &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
 *               &lt;/extension>
 *             &lt;/simpleContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="MissingWeight" minOccurs="0">
 *           &lt;complexType>
 *             &lt;simpleContent>
 *               &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>StringLength0to9">
 *                 &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
 *               &lt;/extension>
 *             &lt;/simpleContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="LostContents" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="Content" type="{http://sita.aero/wtr/common/3/0}StringLength0to58AmendType" maxOccurs="2"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="ContentsDamageDesc" minOccurs="0">
 *           &lt;complexType>
 *             &lt;simpleContent>
 *               &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>StringLength0to58">
 *                 &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
 *               &lt;/extension>
 *             &lt;/simpleContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DamagedBagGroupAmendType", propOrder = {
    "damagedBags",
    "baggageItinerary",
    "excessBaggage",
    "missingWeight",
    "lostContents",
    "contentsDamageDesc"
})
public class DamagedBagGroupAmendType
    extends BagGroupAmendType
{

    @XmlElement(name = "DamagedBags")
    protected DamagedBagGroupAmendType.DamagedBags damagedBags;
    @XmlElement(name = "BaggageItinerary")
    protected DamagedBagGroupAmendType.BaggageItinerary baggageItinerary;
    @XmlElement(name = "ExcessBaggage")
    protected DamagedBagGroupAmendType.ExcessBaggage excessBaggage;
    @XmlElement(name = "MissingWeight")
    protected DamagedBagGroupAmendType.MissingWeight missingWeight;
    @XmlElement(name = "LostContents")
    protected DamagedBagGroupAmendType.LostContents lostContents;
    @XmlElement(name = "ContentsDamageDesc")
    protected DamagedBagGroupAmendType.ContentsDamageDesc contentsDamageDesc;

    /**
     * Gets the value of the damagedBags property.
     * 
     * @return
     *     possible object is
     *     {@link DamagedBagGroupAmendType.DamagedBags }
     *     
     */
    public DamagedBagGroupAmendType.DamagedBags getDamagedBags() {
        return damagedBags;
    }

    /**
     * Sets the value of the damagedBags property.
     * 
     * @param value
     *     allowed object is
     *     {@link DamagedBagGroupAmendType.DamagedBags }
     *     
     */
    public void setDamagedBags(DamagedBagGroupAmendType.DamagedBags value) {
        this.damagedBags = value;
    }

    /**
     * Gets the value of the baggageItinerary property.
     * 
     * @return
     *     possible object is
     *     {@link DamagedBagGroupAmendType.BaggageItinerary }
     *     
     */
    public DamagedBagGroupAmendType.BaggageItinerary getBaggageItinerary() {
        return baggageItinerary;
    }

    /**
     * Sets the value of the baggageItinerary property.
     * 
     * @param value
     *     allowed object is
     *     {@link DamagedBagGroupAmendType.BaggageItinerary }
     *     
     */
    public void setBaggageItinerary(DamagedBagGroupAmendType.BaggageItinerary value) {
        this.baggageItinerary = value;
    }

    /**
     * Gets the value of the excessBaggage property.
     * 
     * @return
     *     possible object is
     *     {@link DamagedBagGroupAmendType.ExcessBaggage }
     *     
     */
    public DamagedBagGroupAmendType.ExcessBaggage getExcessBaggage() {
        return excessBaggage;
    }

    /**
     * Sets the value of the excessBaggage property.
     * 
     * @param value
     *     allowed object is
     *     {@link DamagedBagGroupAmendType.ExcessBaggage }
     *     
     */
    public void setExcessBaggage(DamagedBagGroupAmendType.ExcessBaggage value) {
        this.excessBaggage = value;
    }

    /**
     * Gets the value of the missingWeight property.
     * 
     * @return
     *     possible object is
     *     {@link DamagedBagGroupAmendType.MissingWeight }
     *     
     */
    public DamagedBagGroupAmendType.MissingWeight getMissingWeight() {
        return missingWeight;
    }

    /**
     * Sets the value of the missingWeight property.
     * 
     * @param value
     *     allowed object is
     *     {@link DamagedBagGroupAmendType.MissingWeight }
     *     
     */
    public void setMissingWeight(DamagedBagGroupAmendType.MissingWeight value) {
        this.missingWeight = value;
    }

    /**
     * Gets the value of the lostContents property.
     * 
     * @return
     *     possible object is
     *     {@link DamagedBagGroupAmendType.LostContents }
     *     
     */
    public DamagedBagGroupAmendType.LostContents getLostContents() {
        return lostContents;
    }

    /**
     * Sets the value of the lostContents property.
     * 
     * @param value
     *     allowed object is
     *     {@link DamagedBagGroupAmendType.LostContents }
     *     
     */
    public void setLostContents(DamagedBagGroupAmendType.LostContents value) {
        this.lostContents = value;
    }

    /**
     * Gets the value of the contentsDamageDesc property.
     * 
     * @return
     *     possible object is
     *     {@link DamagedBagGroupAmendType.ContentsDamageDesc }
     *     
     */
    public DamagedBagGroupAmendType.ContentsDamageDesc getContentsDamageDesc() {
        return contentsDamageDesc;
    }

    /**
     * Sets the value of the contentsDamageDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link DamagedBagGroupAmendType.ContentsDamageDesc }
     *     
     */
    public void setContentsDamageDesc(DamagedBagGroupAmendType.ContentsDamageDesc value) {
        this.contentsDamageDesc = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence minOccurs="0">
     *         &lt;element name="FlightDateOrARNK" type="{http://sita.aero/wtr/common/3/0}FlightDateOrARNKType" maxOccurs="5"/>
     *       &lt;/sequence>
     *       &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "flightDateOrARNK"
    })
    public static class BaggageItinerary {

        @XmlElement(name = "FlightDateOrARNK")
        protected List<FlightDateOrARNKType> flightDateOrARNK;
        @XmlAttribute(name = "Delete")
        protected Boolean delete;

        /**
         * Gets the value of the flightDateOrARNK property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the flightDateOrARNK property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getFlightDateOrARNK().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link FlightDateOrARNKType }
         * 
         * 
         */
        public List<FlightDateOrARNKType> getFlightDateOrARNK() {
            if (flightDateOrARNK == null) {
                flightDateOrARNK = new ArrayList<FlightDateOrARNKType>();
            }
            return this.flightDateOrARNK;
        }

        /**
         * Gets the value of the delete property.
         * 
         * @return
         *     possible object is
         *     {@link Boolean }
         *     
         */
        public boolean isDelete() {
            if (delete == null) {
                return false;
            } else {
                return delete;
            }
        }

        /**
         * Sets the value of the delete property.
         * 
         * @param value
         *     allowed object is
         *     {@link Boolean }
         *     
         */
        public void setDelete(Boolean value) {
            this.delete = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;simpleContent>
     *     &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>StringLength0to58">
     *       &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
     *     &lt;/extension>
     *   &lt;/simpleContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class ContentsDamageDesc {

        @XmlValue
        protected String value;
        @XmlAttribute(name = "Delete")
        protected Boolean delete;

        /**
         * Used for Character Strings, length 0 to 58
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setValue(String value) {
            this.value = value;
        }

        /**
         * Gets the value of the delete property.
         * 
         * @return
         *     possible object is
         *     {@link Boolean }
         *     
         */
        public boolean isDelete() {
            if (delete == null) {
                return false;
            } else {
                return delete;
            }
        }

        /**
         * Sets the value of the delete property.
         * 
         * @param value
         *     allowed object is
         *     {@link Boolean }
         *     
         */
        public void setDelete(Boolean value) {
            this.delete = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="DamagedBag" maxOccurs="10">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;extension base="{http://sita.aero/wtr/common/3/0}DamagedBagAmendType">
     *                 &lt;attribute name="Seq" use="required" type="{http://www.w3.org/2001/XMLSchema}int" />
     *               &lt;/extension>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "damagedBag"
    })
    public static class DamagedBags {

        @XmlElement(name = "DamagedBag", required = true)
        protected List<DamagedBagGroupAmendType.DamagedBags.DamagedBag> damagedBag;

        /**
         * Gets the value of the damagedBag property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the damagedBag property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getDamagedBag().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link DamagedBagGroupAmendType.DamagedBags.DamagedBag }
         * 
         * 
         */
        public List<DamagedBagGroupAmendType.DamagedBags.DamagedBag> getDamagedBag() {
            if (damagedBag == null) {
                damagedBag = new ArrayList<DamagedBagGroupAmendType.DamagedBags.DamagedBag>();
            }
            return this.damagedBag;
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;extension base="{http://sita.aero/wtr/common/3/0}DamagedBagAmendType">
         *       &lt;attribute name="Seq" use="required" type="{http://www.w3.org/2001/XMLSchema}int" />
         *     &lt;/extension>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "")
        public static class DamagedBag
            extends DamagedBagAmendType
        {

            @XmlAttribute(name = "Seq", required = true)
            protected int seq;

            /**
             * Gets the value of the seq property.
             * 
             */
            public int getSeq() {
                return seq;
            }

            /**
             * Sets the value of the seq property.
             * 
             */
            public void setSeq(int value) {
                this.seq = value;
            }

        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;simpleContent>
     *     &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>AlphaNumericStringLength0to15">
     *       &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
     *     &lt;/extension>
     *   &lt;/simpleContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class ExcessBaggage {

        @XmlValue
        protected String value;
        @XmlAttribute(name = "Delete")
        protected Boolean delete;

        /**
         * Used for Alpha Numeric Strings, length 0 and 15
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setValue(String value) {
            this.value = value;
        }

        /**
         * Gets the value of the delete property.
         * 
         * @return
         *     possible object is
         *     {@link Boolean }
         *     
         */
        public boolean isDelete() {
            if (delete == null) {
                return false;
            } else {
                return delete;
            }
        }

        /**
         * Sets the value of the delete property.
         * 
         * @param value
         *     allowed object is
         *     {@link Boolean }
         *     
         */
        public void setDelete(Boolean value) {
            this.delete = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="Content" type="{http://sita.aero/wtr/common/3/0}StringLength0to58AmendType" maxOccurs="2"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "content"
    })
    public static class LostContents {

        @XmlElement(name = "Content", required = true)
        protected List<StringLength0To58AmendType> content;

        /**
         * Gets the value of the content property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the content property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getContent().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link StringLength0To58AmendType }
         * 
         * 
         */
        public List<StringLength0To58AmendType> getContent() {
            if (content == null) {
                content = new ArrayList<StringLength0To58AmendType>();
            }
            return this.content;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;simpleContent>
     *     &lt;extension base="&lt;http://sita.aero/wtr/common/3/0>StringLength0to9">
     *       &lt;attribute name="Delete" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
     *     &lt;/extension>
     *   &lt;/simpleContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class MissingWeight {

        @XmlValue
        protected String value;
        @XmlAttribute(name = "Delete")
        protected Boolean delete;

        /**
         * Used for Character Strings, length 0 to 9
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setValue(String value) {
            this.value = value;
        }

        /**
         * Gets the value of the delete property.
         * 
         * @return
         *     possible object is
         *     {@link Boolean }
         *     
         */
        public boolean isDelete() {
            if (delete == null) {
                return false;
            } else {
                return delete;
            }
        }

        /**
         * Sets the value of the delete property.
         * 
         * @param value
         *     allowed object is
         *     {@link Boolean }
         *     
         */
        public void setDelete(Boolean value) {
            this.delete = value;
        }

    }

}

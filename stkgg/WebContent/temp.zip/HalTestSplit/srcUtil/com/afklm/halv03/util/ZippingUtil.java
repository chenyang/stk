package com.afklm.halv03.util;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Iterator;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;

public class ZippingUtil {

	private static final String outputPath = "output/soarepo";
	private static Logger logger = Logger.getLogger(ZippingUtil.class);

	//Singleton
	private static ZippingUtil instance;
	private ZippingUtil(){};
	public static ZippingUtil getInstance(){
		instance = new ZippingUtil();
		return instance;
	}
	
	protected void zipFolders(boolean zipFolder){
		logger.info("==================================================================");
		logger.info("start zipping/regrouping folders, please wait.. "+"(with 'zip' option: "+zipFolder+")");
		
		if(Files.exists(Paths.get(outputPath))){
			//splitting and regrouping all related xsd files
			String [] extentions = {"wsdl"};//We just treat .wsdl file
			Iterator<File> files = FileUtils.iterateFiles(new File(outputPath), extentions, false);
			while(files.hasNext()){
				File file = files.next();
				String expectedWsdl = file.getName();
				try {
					RecursiveFindingUtil.getInstance().setInitialWsdl(expectedWsdl);
					RecursiveFindingUtil.getInstance().recursiveFinding(RecursiveFindingUtil.getInstance().getInitialWsdl());
				} catch (Exception e) {
					//We know ending of recursive finding
					logger.debug("finally will put in folder "+expectedWsdl+" following files:");	
					for(String s: RecursiveFindingUtil.getInstance().getVisitedNodeSet()){
						logger.debug(s);
					}
					try {
						RecursiveFindingUtil.getInstance().splitAndZipWS(RecursiveFindingUtil.getInstance().getVisitedNodeSet(), RecursiveFindingUtil.getInstance().getRootNode(), zipFolder);
					} catch (IOException e1) {
						e1.printStackTrace();
					}
				}	
			}
			logger.info("zipping/grouping all folders finished.");
		}else{
			logger.info("'"+outputPath+"' not exists");
		}
	}
}

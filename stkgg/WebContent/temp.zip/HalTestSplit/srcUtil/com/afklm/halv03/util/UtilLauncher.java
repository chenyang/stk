package com.afklm.halv03.util;

public class UtilLauncher {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//Automatically generate Java stub from SITA xsd and hal.wsdl release
		//GenerationUtil.getInstance().generateJavaStub();
		
		//recursive finding dependencies and zip files
		//RecursiveFindingUtil.getInstance().getAvailableChildrensOfNode("WTR_DamagedBagsCreateRQ.wsdl");
		//RecursiveFindingUtil.getInstance().getAvailableChildrensOfNode("WTR_BagTypes.xsd");
		
		//WTR_DamagedBagsCreateRQ.wsdl
		//WTR_DelayedBagsCreateRQ.wsdl
		try {
			RecursiveFindingUtil.getInstance().recursiveFinding("WTR_DelayedBagsCreateRQ.wsdl");
		} catch (Exception e) {
			//We know ending of recursive finding
			System.out.println("finally, we have: ");	
			for(String s: RecursiveFindingUtil.getInstance().getVisitedNodeSet()){
				System.out.println(s);
			}
		}	
	}
}


package com.afklm.halv03.util;

import org.apache.log4j.Logger;


public class UtilLauncher {

	/**
	 * @param args
	 */
	private static Logger logger = Logger.getLogger(UtilLauncher.class);
	
	public static void main(String[] args) {
		//Automatically generate Java stub from SITA xsd and hal.wsdl release
		GenerationUtil.getInstance().generateJavaStub();
		
		//zip files: boolean. Else will just create folders
		ZippingUtil.getInstance().zipFolders(true);
		
		logger.info("SYSTEM EXITS");
	}
}


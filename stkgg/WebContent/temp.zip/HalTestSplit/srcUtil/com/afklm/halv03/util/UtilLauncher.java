package com.afklm.halv03.util;

public class UtilLauncher {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//Automatically generate Java stub from SITA xsd and hal.wsdl release
		GenerationUtil.getInstance().generateJavaStub();
		
		//recursive finding dependencies and zip files
		//RecursiveFindingUtil.getInstance().getAvailableChildrensOfNode("output/soarepo/WTR_DamagedBagsCreateRQ.wsdl");
		//RecursiveFindingUtil.getInstance().getAvailableChildrensOfNode("output/soarepo/xsd/WTR_BagTypes.xsd");

	}
}


package com.afklm.halv03.util;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;

public class UtilLauncher {

	private static Logger logger = Logger.getLogger(UtilLauncher.class);

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//Automatically generate Java stub from SITA xsd and hal.wsdl release
		GenerationUtil.getInstance().generateJavaStub();

		//eg: WTR_DelayedBagsCreateRQ.wsdl
		//splitting and regrouping all related xsd files
		String outputPath = "output/soarepo";
		String [] extentions = {"wsdl"};//We just treat .wsdl file
		Iterator<File> files = FileUtils.iterateFiles(new File(outputPath), extentions, false);
		while(files.hasNext()){
			File file = files.next();
			String expectedWsdl = file.getName();
			try {
				RecursiveFindingUtil.getInstance().setInitialWsdl(expectedWsdl);
				RecursiveFindingUtil.getInstance().recursiveFinding(RecursiveFindingUtil.getInstance().getInitialWsdl());
			} catch (Exception e) {
				//We know ending of recursive finding
				logger.debug("finally will put in folder "+expectedWsdl+" following files:");	
				for(String s: RecursiveFindingUtil.getInstance().getVisitedNodeSet()){
					logger.debug(s);
				}
				try {
					RecursiveFindingUtil.getInstance().splitAndZipWS(RecursiveFindingUtil.getInstance().getVisitedNodeSet(), RecursiveFindingUtil.getInstance().getRootNode(), true);
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}	
		}
	}
}


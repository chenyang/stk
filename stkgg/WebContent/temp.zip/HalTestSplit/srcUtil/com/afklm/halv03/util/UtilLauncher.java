package com.afklm.halv03.util;

import java.io.IOException;

import org.apache.log4j.Logger;

public class UtilLauncher {

	private static Logger logger = Logger.getLogger(UtilLauncher.class);
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//Automatically generate Java stub from SITA xsd and hal.wsdl release
		GenerationUtil.getInstance().generateJavaStub();
		
		//WTR_DamagedBagsCreateRQ.wsdl
		//WTR_DelayedBagsCreateRQ.wsdl
		String expectedWsdl = "WTR_DelayedBagsCreateRQ.wsdl";
		try {
			RecursiveFindingUtil.getInstance().setInitialWsdl("WTR_DelayedBagsCreateRQ.wsdl");
			RecursiveFindingUtil.getInstance().recursiveFinding(RecursiveFindingUtil.getInstance().getInitialWsdl());
		} catch (Exception e) {
			//We know ending of recursive finding
			logger.debug("finally will put in folder "+expectedWsdl+" following files:");	
			for(String s: RecursiveFindingUtil.getInstance().getVisitedNodeSet()){
				logger.debug(s);
			}
			try {
				RecursiveFindingUtil.getInstance().splitAndZipWS(RecursiveFindingUtil.getInstance().getVisitedNodeSet(), RecursiveFindingUtil.getInstance().getRootNode());
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}	
	}
}


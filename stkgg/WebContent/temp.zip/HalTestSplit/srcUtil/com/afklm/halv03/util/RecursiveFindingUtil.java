package com.afklm.halv03.util;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.Stack;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.FileUtils;

public class RecursiveFindingUtil {

	private Set<String> visitedNodeSet;
	private Stack<String> rootNodeStack;
	private String rootNode;
	private static String commonPathXsd = "output/soarepo/xsd/";
	private static String commonPathWsdl = "output/soarepo/";

	private static RecursiveFindingUtil instance;
	private RecursiveFindingUtil (){
		visitedNodeSet = new HashSet<String>();
		rootNodeStack = new Stack<String>();
		rootNode = null;
	}
	public static RecursiveFindingUtil getInstance(){
		if(instance==null)
			instance = new RecursiveFindingUtil();
		return instance;
	}

	private String retriveFileName(String fileRelativePath){
		return fileRelativePath.substring(fileRelativePath.lastIndexOf("/")+1);
	}

	public List<String> getAvailableChildrensOfNode(String fileNode){
		//regex raw: 
		//	<xsd:import namespace="([^"]+)"([^<]*)schemaLocation="([^"]+)"/>
		//	<xs:import namespace="([^"]+)"([^<]*)schemaLocation="([^"]+)"/>
		//	<xs:include([^<]*)schemaLocation="([^"]+)"/>
		File file = null;
		if(fileNode.contains(".wsdl")){
			file = new File(commonPathWsdl+fileNode);
		}else if (fileNode.contains(".xsd")){
			file = new File(commonPathXsd+fileNode);
		}

		List<String> result = new ArrayList<String>();
		if(file!=null){
			String fileStr = null;
			try {
				fileStr = FileUtils.readFileToString(file, "UTF-8");
				//case1:
				Pattern p1 = Pattern.compile("<xsd:import namespace=\"([^\"]+)\"([^<]*)schemaLocation=\"([^\"]+)\"/>");
				Matcher m1 = null;
				m1 = p1.matcher(fileStr);
				while(m1.find()){
					result.add(retriveFileName(m1.group(3)));
				}
				//case2:
				Pattern p2 = Pattern.compile("<xs:import namespace=\"([^\"]+)\"([^<]*)schemaLocation=\"([^\"]+)\"/>");
				Matcher m2 = null;
				m2 = p2.matcher(fileStr);
				while(m2.find()){
					result.add(retriveFileName(m2.group(3)));
				}
				//case3: 
				Pattern p3 = Pattern.compile("<xs:include([^<]*)schemaLocation=\"([^\"]+)\"/>");
				Matcher m3 = null;
				m3 = p3.matcher(fileStr);
				while(m3.find()){
					result.add(retriveFileName(m3.group(2)));
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}	

		//remove duplicated ones from visitedNodes
		List<String> finalResult = new ArrayList<String>();
		for(String r: result){
			if(visitedNodeSet.contains(r)){
				continue;
			}else{
				finalResult.add(r);
			}
		}
		return finalResult;
	}

	public void recursiveFinding(String fileNode){
		if(fileNode!=null){
			System.out.println("---recursiveFinding("+fileNode+")");
			System.out.println("==stack has:"+rootNodeStack.toString());
			/*
			 * if this file has available childrens
			 * means: all imported/included(xs:import, xsd:import, xs:include, xsd:include) filenames 
			 * and at least one of these filenames not exists in visitedNodeSet
			 */
			if(getAvailableChildrensOfNode(fileNode).size()>0){
				//comment
				System.out.println("getAvailableChildrensOfNode("+fileNode+"), we have children:");
				for(String r :this.getAvailableChildrensOfNode(fileNode)){
					System.out.println(r);
				}
				//set current rootFileName
				rootNode = fileNode;
				//push in rootNodestack
				rootNodeStack.push(fileNode);
				//for each child in current fileNode
				List<String> availableChildrenFilesInCurrentNode = getAvailableChildrensOfNode(fileNode);
				for(String childFile: availableChildrenFilesInCurrentNode){
					recursiveFinding(childFile);
				}
			}else{ 
				System.out.println(fileNode+" has no available child");
				//If current node (file) has no available children
				//add this node in SetVisited
				visitedNodeSet.add(fileNode);
				//set rootNode file = head of rootNodeStack
				if(!rootNodeStack.empty()){
					rootNode = rootNodeStack.pop();
					System.out.println("pop root Node. New RootNode is :"+rootNode);
					//recursive current fileNode
					recursiveFinding(rootNode);
				}else{
					recursiveFinding(null);
					this.setVisitedNodeSet(visitedNodeSet);
				}
			}
		}
	}
	
	public Set<String> getVisitedNodeSet() {
		return visitedNodeSet;
	}
	public void setVisitedNodeSet(Set<String> visitedNodeSet) {
		this.visitedNodeSet = visitedNodeSet;
	}
}

package com.afklm.halv03.util;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.Stack;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.FileUtils;

public class RecursiveFindingUtil {

	private Set<String> visitedNodeSet;
	private Stack<String> rootNodeStack;
	private String rootNode;

	private static RecursiveFindingUtil instance;
	private RecursiveFindingUtil (){
		visitedNodeSet = new HashSet<String>();
		rootNodeStack = new Stack<String>();
		rootNode = null;
	}
	public static RecursiveFindingUtil getInstance(){
		instance = new RecursiveFindingUtil();
		return instance;
	}

	private boolean isNodeHasAvailableChildren(String fileNode){
		/*
		 * if this file has available childrens
		 * means: in this file, contains imported/included(keyword xs:import, xs:include) filenames 
		 * and these filenames not exists in visitedNodeSet
		 */

		//TODO

		return true;

	}

	private String retriveFileName(String fileRelativePath){
		return fileRelativePath.substring(fileRelativePath.lastIndexOf("/")+1);
	}

	public List<String> getAvailableChildrensOfNode(String fileNode){
		//TODO
		//regex raw: 
		//	<xsd:import namespace="([^"]+)"([^<]*)schemaLocation="([^"]+)"/>
		//	<xs:import namespace="([^"]+)"([^<]*)schemaLocation="([^"]+)"/>
		//	<xs:include([^<]*)schemaLocation="([^"]+)"/>
		
		List<String> result = new ArrayList<String>();
		File file = new File(fileNode);
		if(file!=null){
			System.out.println("file exists");
			String fileStr = null;
			try {
				fileStr = FileUtils.readFileToString(file, "UTF-8");
				//case1:
				Pattern p1 = Pattern.compile("<xsd:import namespace=\"([^\"]+)\"([^<]*)schemaLocation=\"([^\"]+)\"/>");
				Matcher m1 = null;
				m1 = p1.matcher(fileStr);
				while(m1.find()){
					System.out.println(retriveFileName(fileNode)+" has child: "+retriveFileName(m1.group(3)));
					result.add(retriveFileName(m1.group(3)));
				}

				//case2:
				Pattern p2 = Pattern.compile("<xs:import namespace=\"([^\"]+)\"([^<]*)schemaLocation=\"([^\"]+)\"/>");
				Matcher m2 = null;
				m2 = p2.matcher(fileStr);
				while(m2.find()){
					System.out.println(retriveFileName(fileNode)+" has child: "+retriveFileName(m2.group(3)));
					result.add(retriveFileName(m2.group(3)));
				}

				//case3: 
				Pattern p3 = Pattern.compile("<xs:include([^<]*)schemaLocation=\"([^\"]+)\"/>");
				Matcher m3 = null;
				m3 = p3.matcher(fileStr);
				while(m3.find()){
					System.out.println(retriveFileName(fileNode)+" has child: "+retriveFileName(m3.group(2)));
					result.add(retriveFileName(m3.group(2)));
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}	
		return result;
	}

	public void recursiveFinding(String fileNode){
		/*
		 * if this file has available childrens
		 * means: all imported/included(xs:import, xsd:import, xs:include, xsd:include) filenames 
		 * and these filenames not exists in visitedNodeSet
		 */
		if(isNodeHasAvailableChildren(fileNode)){
			//set current rootFileName
			rootNode = fileNode;
			//push in rootNodestack
			rootNodeStack.push(fileNode);
			//for each child in current fileNode
			List<String> availableChildrenFilesInCurrentNode = getAvailableChildrensOfNode(fileNode);
			for(String childFile: availableChildrenFilesInCurrentNode){
				recursiveFinding(childFile);
			}

		}else{ //If current node (file) has no available children
			//add this node in SetVisited
			visitedNodeSet.add(fileNode);
			//get rootNode file == head of rootNodeStack
			rootNode = rootNodeStack.pop();
			//recursive current fileNode
			if(!rootNodeStack.empty()){ //==>means returned to initial file
				recursiveFinding(fileNode);
			}
		}
	}

}

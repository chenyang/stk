package com.afklm.halv03.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import net.sf.saxon.Transform;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;

public class GenerationUtil {

	private static final String originalXsdFolderPath = "resource/xsd";
	private static final String originalWsdlFilePath = "resource/hal.wsdl";
	private static final String splitXslFilePath = "resource/split_sita.xsl";
	private static final String xsdFolderPathForSchema = "soarepo/xsd/";
	private static final String modifiedWsdlFilePath = "output/hal_modified.wsdl"; //modified wsdl file with AF regular
	private static final String outputXsdFolderPath = "output/soarepo/xsd";
	private static final String outputFakeSplittedWsdlPath = "output/soarepo/splittedWsdl";
	
	private File originalWsdlFile;
	private File modifiedWsdlFile;
	private File splitXslFile;
	private File originalXsdFolder;
	private File outputXsdFolder;
	private File outputSplittedWsdlFolder;
	
	private Logger logger = Logger.getLogger(getClass().getName());

	//Singleton
	private static GenerationUtil instance;
	private GenerationUtil(){};
	public static GenerationUtil getInstance(){
		instance = new GenerationUtil();
		return instance;
	}
	
	/**
	 * Main method
	 */
	public void generateJavaStub(){
		if(originalWsdlFile == null){
			originalWsdlFile = new File(originalWsdlFilePath);
		}
		if(modifiedWsdlFile == null){
			modifiedWsdlFile = new File(modifiedWsdlFilePath);
		}
		if(splitXslFile == null){
			splitXslFile = new File(splitXslFilePath);
		}
		if(originalXsdFolder == null){
			originalXsdFolder = new File(originalXsdFolderPath);
		}
		if(outputXsdFolder == null){
			outputXsdFolder = new File(outputXsdFolderPath);
		}
		if(outputSplittedWsdlFolder == null){
			outputSplittedWsdlFolder = new File(outputFakeSplittedWsdlPath);
		}
		
		/**
		 * 0. Verify if resource folder is present. If "hal.wsdl" file and "xsd" folder is present
		 */
		if(Files.isDirectory(Paths.get("resource/xsd"))&&Files.exists(Paths.get(originalWsdlFilePath))&&Files.exists(Paths.get(splitXslFilePath))){
			logger.info("Requested files and folders OK and ready for run..");
			if(Files.exists(Paths.get(outputXsdFolderPath))){
				logger.warn("Folder 'output/xsd' exits, will not redo the scenario. System exists.");
				System.exit(1);
			}
			/**
			 * 1. Apply AF regular: a)add soapAction for each operation 
			 * 						b)delete "id" attribute in all xsd files
			 * 
			 * Consequently, copies all xsd files without duplication in output folder
			 */
				this.modifyOriginalWSDLWithAFReg();
			
			/**
			 * 2. Change hal.wsdl with "schemaLocation=" in order to adapt to new xsd structure
			 */
				this.adaptWsdlFile();
				
			/**
			 * 3. Use saxon to split wsdl file	
			 */
				this.saxonSplit();
			
		}else{
				logger.error("requested wsdl, xsd foler or split xsl file not presented");
				System.exit(1);
		}
	}

	/**
	 * Modify original wsdl file with AF regular
	 * @param originalWsdlFile
	 * @return
	 */
	private void modifyOriginalWSDLWithAFReg(){
		logger.info("Applying AF regular for header 'soapAction' in wsdl and 'id' in xsd..");
		try{
			
			//A. add 'soapAction' for each operation in wsdl file
			//replace wsdl file in all , by order with REGEX
			/**
			 * Pattern matching string is: '<operation name=\"([^\"]+)\">([^<]*)<soap:operation style=\"document\"/>', has 2 groups
			 * Pattern mathcing outuput string is : '<operation name="\1===group1">\2===group 2<soap:operation soapAction="http://sita.aero/hal/HalService-v3/\1===group1" style="document"/>'
			 * will replace all with matcher group
			 */
			if(originalWsdlFile!=null){
				String outputStr = "";
				String wsdlFileStr = FileUtils.readFileToString(originalWsdlFile, "utf-8");
				Pattern p = Pattern.compile("<operation name=\"([^\"]+)\">([^<]*)<soap:operation style=\"document\"/>");
				Matcher m = null;
				m = p.matcher(wsdlFileStr);
				
				StringBuffer sb = new StringBuffer();
				while(m.find()){
					m.appendReplacement(sb, Matcher.quoteReplacement("<operation name=\""+m.group(1)+"\">"+m.group(2)+"<soap:operation soapAction=\"http://sita.aero/hal/HalService-v3/"+m.group(1)+"\" style=\"document\"/>"));
				}
				m.appendTail(sb);
				outputStr = sb.toString();
				//write replaced lines to output file
				FileUtils.writeStringToFile(modifiedWsdlFile, outputStr, "utf-8");
			}
		
			//B. delete "id" attribute in all xsd files and create them in output folder
			Iterator<File> files = FileUtils.iterateFiles(originalXsdFolder, null, true);
			while(files.hasNext()){
				File xsdFile = files.next();
				if(xsdFile.getName().contains("wsdl")){
					continue; //bypass wsdl file
				}
				FileInputStream fis = new FileInputStream(xsdFile);
				String xsdContent = IOUtils.toString(fis, "UTF-8");
				xsdContent = xsdContent.replaceAll("id=\"[^\"]+\"", "");
				File outputXsdFile = new File(outputXsdFolderPath+"/"+xsdFile.getName());
				FileUtils.writeStringToFile(outputXsdFile, xsdContent);
			}
		}catch (FileNotFoundException e) {
			e.printStackTrace();
			System.exit(1);
		}catch (IOException e) {
			e.printStackTrace();
			System.exit(1);
		}catch(Exception e){
			e.printStackTrace();
			System.exit(1);
		}finally{
			logger.info("Applying AF regular finished.");
		}
	}
	
	/**
	 * adapt modified wsdl file (with AF regular) with "schemaLocation=" in order to adapt to new xsd structure 
	 */
	private void adaptWsdlFile(){
		logger.info("Replacing hal.wsdl file with new 'schemaLocation'...");
		try {
			FileInputStream inS = new FileInputStream(modifiedWsdlFile);
			String wsdlContent = IOUtils.toString(inS, "UTF-8");
			wsdlContent = wsdlContent.replaceAll("xsd/([0-9]|[0-9][0-9])/dev/client_interfaces/xsd/wtr/", xsdFolderPathForSchema);
			FileUtils.writeStringToFile(modifiedWsdlFile, wsdlContent);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			System.exit(1);
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(1);
		}finally{
			logger.info("New 'schemaLocation' replace finished.");
		}
	}

	/**
	 * saxon splitting wsdl
	 */
	private void saxonSplit(){
		logger.info("Saxon is splitting..");
		Transform transform = new Transform();
		String [] args = {"-s:"+modifiedWsdlFilePath, "-xsl:"+splitXslFilePath, "-o:"+outputFakeSplittedWsdlPath};
		transform.doTransform(args, "");
		logger.info("Saxon finished splitting");
		//delete generated useless 'outputFakeSplittedWsdlPath' file
		FileUtils.deleteQuietly(new File(outputFakeSplittedWsdlPath));
	}
	
}
